(module $exp_experiment.wasm
 (type $0 (func (param i32 i32)))
 (type $1 (func (param f64) (result f64)))
 (type $2 (func (param i32 i32) (result i32)))
 (type $3 (func (param i32 i32 i32) (result i32)))
 (type $4 (func (param i32)))
 (type $5 (func (param i32 i32 i32)))
 (type $6 (func (param i32 i32 i32 i32 i32)))
 (type $7 (func (param i32 i32 i32 i32) (result i32)))
 (type $8 (func))
 (type $9 (func (param i32) (result i32)))
 (type $10 (func (result f64)))
 (type $11 (func (param f64 i64 i64)))
 (type $12 (func (param i32 i32 i64) (result i64)))
 (type $13 (func (param i32 i32 i32 i32 i32 i32)))
 (import "env" "clock_ms" (func $_RNvNtCslyLwehSP5cz_14exp_experiment3abi8clock_ms (result f64)))
 (import "env" "report" (func $_RNvNtCslyLwehSP5cz_14exp_experiment3abi6report (param f64 i64 i64)))
 (global $__stack_pointer (mut i32) (i32.const 1048576))
 (memory $0 17)
 (data $.rodata (i32.const 1048576) "\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\80\00\00\00\00\00\00\f0\7f\00\00\00\00\00\00\f0\ff\00\00\00\00\00\00\f8\7f\01\00\00\00\00\00\f0\7f\ff\ff\ff\ff\ff\ff\ef\7f\ff\ff\ff\ff\ff\ff\ef\ff\00\00\00\00\08\00\00\00\04\00\00\00\05\00\00\00\06\00\00\00\07\00\00\00\08\00\00\00\t\00\00\00\10\00\00\00\04\00\00\00\n\00\00\00\0b\00\00\00\0c\00\00\00\r\00\00\00\\\f6\e9_\dc\02\f6\b9\f1\c1pl\f2a\c1$\b6j\01\f5\f5f\efq\e7@\b2v\de\831\10\0e\00\00\00\0c\00\00\00\04\00\00\00\0f\00\00\00\10\00\00\00\11\00\00\00\c0\00/private/tmp/libm-exp-sysroots/candidate/library/std/src/sys/sync/rwlock/no_threads.rs\00/private/tmp/libm-exp-sysroots/candidate/library/alloc/src/raw_vec/mod.rs\00/Users/fangluo/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/dlmalloc-0.2.14/src/dlmalloc.rs\00assertion failed: psize >= size + min_overhead\00\00\00S\01\10\00c\00\00\00\e9\04\00\00\t\00\00\00assertion failed: psize <= size + max_overhead\00\00S\01\10\00c\00\00\00\ef\04\00\00\r\00\00\00S\01\10\00c\00\00\00M\05\00\00\1e\00\00\00rwlock overflowed read locks\b2\00\10\00V\00\00\00\1e\00\00\00,\00\00\00\00\00\00\00\08\00\00\00\04\00\00\00\12\00\00\00\0e\00\00\00\0c\00\00\00\04\00\00\00\13\00\00\00rwlock has not been locked for reading\00\00\b2\00\10\00V\00\00\00G\00\00\00\t\00\00\00capacity overflow\00\00\00\t\01\10\00I\00\00\00\1d\00\00\00\05\00\00\00attempt to divide by zero\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\f0?n\bf\88\1aO;\9b<53\fb\a9=\f6\ef?]\dc\d8\9c\13`q\bca\80w>\9a\ec\ef?\d1f\87\10z^\90\bc\85\7fn\e8\15\e3\ef?\13\f6g5R\d2\8c<t\85\15\d3\b0\d9\ef?\fa\8e\f9#\80\ce\8b\bc\de\f6\dd)k\d0\ef?a\c8\e6aN\f7`<\c8\9bu\18E\c7\ef?\99\d33[\e4\a3\90<\83\f3\c6\ca>\be\ef?m{\83]\a6\9a\97<\0f\89\f9lX\b5\ef?\fc\ef\fd\92\1a\b5\8e<\f7Gr+\92\ac\ef?\d1\9c/p=\be><\a2\d1\d32\ec\a3\ef?\0bn\90\894\03j\bc\1b\d3\fe\aff\9b\ef?\0e\bd/*RV\95\bcQ[\12\d0\01\93\ef?U\eaN\8c\ef\80P\bc\cc1l\c0\bd\8a\ef?\16\f4\d5\b9#\c9\91\bc\e0-\a9\ae\9a\82\ef?\afU\\\e9\e3\d3\80<Q\8e\a5\c8\98z\ef?H\93\a5\ea\15\1b\80\bc{Q}<\b8r\ef?=2\deU\f0\1f\8f\bc\ea\8d\8c8\f9j\ef?\bfS\13?\8c\89\8b<u\cbo\eb[c\ef?&\eb\11v\9c\d9\96\bc\d4\\\04\84\e0[\ef?`/:>\f7\ec\9a<\aa\b9h1\87T\ef?\9d8\86\cb\82\e7\8f\bc\1d\d9\fc\"PM\ef?\8d\c3\a6DAo\8a<\d6\8cb\88;F\ef?}\04\e4\b0\05z\80<\96\dc}\91I?\ef?\94\a8\a8\e3\fd\8e\96<8bunz8\ef?}Ht\f2\18^\87<?\a6\b2O\ce1\ef?\f2\e7\1f\98+G\80<\dd|\e2eE+\ef?^\08q?{\b8\96\bc\81c\f5\e1\df$\ef?1\ab\tm\e1\f7\82<\e1\de\1f\f5\9d\1e\ef?\fa\bfo\1a\9b!=\bc\90\d9\da\d0\7f\18\ef?\b4\n\0cr\827\8b<\0b\03\e4\a6\85\12\ef?\8f\cb\ce\89\92\14n<V/>\a9\af\0c\ef?\b6\ab\b0MuM\83<\15\b71\n\fe\06\ef?Lt\ac\e2\01B\86<1\d8L\fcp\01\ef?J\f8\d3]9\dd\8f<\ff\16d\b2\08\fc\ee?\04[\8e;\80\a3\86\bc\f1\9f\92_\c5\f6\ee?hPK\cc\edJ\92\bc\cb\a9:7\a7\f1\ee?\8e-Q\1b\f8\07\99\bcf\d8\05m\ae\ec\ee?\d26\94>\e8\d1q\bc\f7\9f\e54\db\e7\ee?\15\1b\ce\b3\19\19\99\bc\e5\a8\13\c3-\e3\ee?mL*\a7H\9f\85<\"4\12L\a6\de\ee?\8ai(z`\12\93\bc\1c\80\ac\04E\da\ee?[\89\17H\8f\a7X\bc*.\f7!\n\d6\ee?\1b\9aIg\9b,|\bc\97\a8P\d9\f5\d1\ee?\11\ac\c2`\edcC<-\89a`\08\ce\ee?\efd\06;\tf\96<W\00\1d\edA\ca\ee?y\03\a1\da\e1\ccn<\d0<\c1\b5\a2\c6\ee?0\12\0f?\8e\ff\93<\de\d3\d7\f0*\c3\ee?\b0\afz\bb\ce\90v<\'*6\d5\da\bf\ee?w\e0T\eb\bd\1d\93<\r\dd\fd\99\b2\bc\ee?\8e\a3q\004\94\8f\bc\a7,\9dv\b2\b9\ee?I\a3\93\dc\cc\de\87\bcBf\cf\a2\da\b6\ee?_8\0f\bd\c6\dex\bc\82O\9dV+\b4\ee?\f6\\{\ecF\12\86\bc\0f\92]\ca\a4\b1\ee?\8e\d7\fd\18\055\93<\da\'\b56G\af\ee?\05\9b\8a/\b7\98{<\fd\c7\97\d4\12\ad\ee?\tT\1c\e2\e1c\90<)TH\dd\07\ab\ee?\ea\c6\19P\85\c74<\b7FY\8a&\a9\ee?5\c0d+\e62\94<H!\ad\15o\a7\ee?\9fv\99aJ\e4\8c\bc\t\dcv\b9\e1\a5\ee?\a8M\ef;\c53\8c\bc\85U:\b0~\a4\ee?\ae\e9+\89xS\84\bc \c3\cc4F\a3\ee?XXVx\dd\ce\93\bc%\"U\828\a2\ee?d\19~\80\aa\10W<s\a9L\d4U\a1\ee?(\"^\bf\ef\b3\93\bc\cd;\7ff\9e\a0\ee?\82\b94\87\ad\12j\bc\bf\da\0bu\12\a0\ee?\ee\a9m\b8\efgc\bc/\1ae<\b2\9f\ee?Q\88\e0T=\dc\80\bc\84\94Q\f9}\9f\ee?\cf>Z~d\1fx\bct_\ec\e8u\9f\ee?\b0}\8b\c0J\ee\86\bct\81\a5H\9a\9f\ee?\8a\e6U\1e2\19\86\bc\c9gBV\eb\9f\ee?\d3\d4\t^\cb\9c\90<?]\deOi\a0\ee?\1d\a5M\b9\dc2{\bc\87\01\ebs\14\a1\ee?k\c0gT\fd\ec\94<2\c10\01\ed\a1\ee?Ul\d6\ab\e1\ebe<bN\cf6\f3\a2\ee?B\cf\b3/\c5\a1\88\bc\12\1a>T\'\a4\ee?47;\f1\b6i\93\bc\13\ceL\99\89\a5\ee?\1e\ff\19:\84^\80\bc\ad\c7#F\1a\a7\ee?nWr\d8P\d4\94\bc\ed\92D\9b\d9\a8\ee?\00\8a\0e[g\ad\90<\99f\8a\d9\c7\aa\ee?\b4\ea\f0\c1/\b7\8d<\db\a0*B\e5\ac\ee?\ff\e7\c5\9c`\b6e\bc\8cD\b5\162\af\ee?D_\f3Y\83\f6{<6w\15\99\ae\b1\ee?\83=\1e\a7\1f\t\93\bc\c6\ff\91\0b[\b4\ee?)\1el\8b\b8\a9]\bc\e5\c5\cd\b07\b7\ee?Y\b9\90|\f9#l\bc\0fR\c8\cbD\ba\ee?\aa\f9\f4\"CC\92\bcPN\de\9f\82\bd\ee?K\8ef\d7l\ca\85\bc\ba\07\cap\f1\c0\ee?\'\ce\91+\fc\afq<\90\f0\a3\82\91\c4\ee?\bbs\n\e15\d2m<##\e3\19c\c8\ee?c\"b\"\04\c5\87\bce\e5]{f\cc\ee?\d51\e2\e3\86\1c\8b<3-J\ec\9b\d0\ee?\15\bb\bc\d3\d1\bb\91\bc]%>\b2\03\d5\ee?\d21\ee\9c1\cc\90<X\b30\13\9e\d9\ee?\b3Zsn\84i\84<\bf\fdyUk\de\ee?\b4\9d\8e\97\cd\df\82\bcz\f3\d3\bfk\e3\ee?\873\cb\92w\1a\8c<\ad\d3Z\99\9f\e8\ee?\fa\d9\d1J\8f{\90\bcf\b6\8d)\07\ee\ee?\ba\ae\dcV\d9\c3U\bc\fb\15O\b8\a2\f3\ee?@\f6\a6=\0e\a4\90\bc:Y\e5\8dr\f9\ee?4\93\ad8\f4\d6h\bcG^\fb\f2v\ff\ee?5\8aXk\e2\ee\91\bcJ\06\a10\b0\05\ef?\cd\dd_\n\d7\fft<\d2\c1K\90\1e\0c\ef?\ac\98\92\fa\fb\bd\91\bc\t\1e\d7[\c2\12\ef?\b3\0c\af0\aens<\9cR\85\dd\9b\19\ef?\94\fd\9f\\2\e3\8e<z\d0\ff_\ab \ef?\acY\t\d1\8f\e0\84<K\d1W.\f1\'\ef?g\1aN8\af\cdc<\b5\e7\06\94m/\ef?h\19\92l,kg<i\90\ef\dc 7\ef?\d2\b5\cc\83\18\8a\80\bc\fa\c3]U\0b?\ef?o\fa\ff?]\ad\8f\bc|\89\07J-G\ef?I\a9u8\ae\r\90\bc\f2\89\r\08\87O\ef?\a7\07=\a6\85\a3t<\87\a4\fb\dc\18X\ef?\0f\"@ \9e\91\82\bc\98\83\c9\16\e3`\ef?\ac\92\c1\d5PZ\8e<\852\db\03\e6i\ef?Kk\01\acY:\84<`\b4\01\f3!s\ef?\1f>\b4\07!\d5\82\bc_\9b{3\97|\ef?\c9\rG;\b9*\89\bc)\a1\f5\14F\86\ef?\d3\88:`\04\b6t<\f6?\8b\e7.\90\ef?qr\9dQ\ec\c5\83<\83L\c7\fbQ\9a\ef?\f0\91\d3\8f\12\f7\8f\bc\da\90\a4\a2\af\a4\ef?}t#\e2\98\ae\8d\bc\f1g\8e-H\af\ef?\08 \aaA\bc\c3\8e<\'Za\ee\1b\ba\ef?2\eb\a9\c3\94+\84<\97\bak7+\c5\ef?\ee\85\d11\a9d\8a<@En[v\d0\ef?\ed\e3;\e4\ba7\8e\bc\14\be\9c\ad\fd\db\ef?\9d\cd\91M;\89w<\d8\90\9e\81\c1\e7\ef?\89\cc`A\c1\05S<\f1q\8f+\c2\f3\ef?")
 (data $.data (i32.const 1051408) "\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\ff\0f\00\00")
 (table $0 21 21 funcref)
 (elem $0 (i32.const 1) $_RNvNtCslyLwehSP5cz_14exp_experiment6kernel7control $_RNvNtCslyLwehSP5cz_14exp_experiment6kernel12standard_exp $_RNvNtCslyLwehSP5cz_14exp_experiment6kernel13standard_exp2 $_RNvNtCs4ma0AJv6Sxl_3std5alloc24default_alloc_error_hook $_RNvXs2_NvNtCs4ma0AJv6Sxl_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCskCpoLMRBwWe_4core3fmt7Display3fmt $_RNvXs1_NvNtCs4ma0AJv6Sxl_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCs1eLRiQ1QTaf_5alloc9panicking12PanicPayload8take_box $_RNvXs1_NvNtCs4ma0AJv6Sxl_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCs1eLRiQ1QTaf_5alloc9panicking12PanicPayload3get $_RNvXs1_NvNtCs4ma0AJv6Sxl_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCs1eLRiQ1QTaf_5alloc9panicking12PanicPayload6as_str $_RINvNtCskCpoLMRBwWe_4core3ptr9drop_glueNtNvNtCs4ma0AJv6Sxl_3std9panicking13panic_handler19FormatStringPayloadEBH_ $_RNvXs0_NvNtCs4ma0AJv6Sxl_3std9panicking13panic_handlerNtB5_19FormatStringPayloadNtNtCskCpoLMRBwWe_4core3fmt7Display3fmt $_RNvXs_NvNtCs4ma0AJv6Sxl_3std9panicking13panic_handlerNtB4_19FormatStringPayloadNtNtCs1eLRiQ1QTaf_5alloc9panicking12PanicPayload8take_box $_RNvXs_NvNtCs4ma0AJv6Sxl_3std9panicking13panic_handlerNtB4_19FormatStringPayloadNtNtCs1eLRiQ1QTaf_5alloc9panicking12PanicPayload3get $_RNvYINtNvNtCs4ma0AJv6Sxl_3std9panicking11begin_panic7PayloadReENtNtCs1eLRiQ1QTaf_5alloc9panicking12PanicPayload6as_strB9_ $_RINvNtCskCpoLMRBwWe_4core3ptr9drop_glueNtNtCs1eLRiQ1QTaf_5alloc6string6StringECs4ma0AJv6Sxl_3std $_RNvXs15_NtCs1eLRiQ1QTaf_5alloc6stringNtB6_6StringNtNtCskCpoLMRBwWe_4core3fmt5Write9write_str $_RNvXs15_NtCs1eLRiQ1QTaf_5alloc6stringNtB6_6StringNtNtCskCpoLMRBwWe_4core3fmt5Write10write_char $_RNvYNtNtCs1eLRiQ1QTaf_5alloc6string6StringNtNtCskCpoLMRBwWe_4core3fmt5Write9write_fmtCs4ma0AJv6Sxl_3std $_RNvXNtCskCpoLMRBwWe_4core3anyReNtB2_3Any7type_idCs4ma0AJv6Sxl_3std $_RNvXNtCskCpoLMRBwWe_4core3anyNtNtCs1eLRiQ1QTaf_5alloc6string6StringNtB2_3Any7type_idCs4ma0AJv6Sxl_3std $_RNvXs1i_NtCskCpoLMRBwWe_4core3fmtReNtB6_7Display3fmtB8_)
 (export "memory" (memory $0))
 (export "run_bench" (func $run_bench))
 (export "unary_bits" (func $unary_bits))
 (func $_RNvNtCslyLwehSP5cz_14exp_experiment6kernel12standard_exp (param $0 f64) (result f64)
  (call $exp
   (local.get $0)
  )
 )
 (func $_RNvNtCslyLwehSP5cz_14exp_experiment6kernel13standard_exp2 (param $0 f64) (result f64)
  (call $exp2
   (local.get $0)
  )
 )
 (func $_RNvNtCslyLwehSP5cz_14exp_experiment6kernel7control (param $0 f64) (result f64)
  (f64.add
   (local.get $0)
   (f64.const 1)
  )
 )
 (func $run_bench (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 f64)
  (local $8 i32)
  (local $9 i64)
  (local $10 i32)
  (local $11 i32)
  (local $12 f64)
  (local $13 f64)
  (local $14 i64)
  (local $15 i64)
  (local $16 i64)
  (local $17 f64)
  (global.set $__stack_pointer
   (local.tee $5
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (call $_RNvCs9VHGBS8Gq78_7___rustc35___rust_no_alloc_shim_is_unstable_v2)
  (block $block13
   (block $block11
    (block $block
     (br_if $block
      (i32.eqz
       (local.tee $6
        (call $_RNvCs9VHGBS8Gq78_7___rustc12___rust_alloc
         (i32.const 131072)
         (i32.const 8)
        )
       )
      )
     )
     (local.set $7
      (select
       (f64.const 1)
       (f64.const 0.6931471805599453)
       (local.get $0)
      )
     )
     (local.set $8
      (i32.const 0)
     )
     (local.set $9
      (i64.const 20261030)
     )
     (local.set $10
      (i32.add
       (local.get $3)
       (i32.const -1)
      )
     )
     (local.set $11
      (local.get $6)
     )
     (loop $label
      (local.set $12
       (f64.mul
        (f64.convert_i64_u
         (i64.shr_u
          (local.tee $9
           (i64.add
            (i64.mul
             (local.get $9)
             (i64.const 6364136223846793005)
            )
            (i64.const 1442695040888963407)
           )
          )
          (i64.const 11)
         )
        )
        (f64.const 1.1102230246251565e-16)
       )
      )
      (block $block7
       (block $block5
        (block $block4
         (block $block3
          (block $block2
           (block $block1
            (block $block6
             (br_table $block1 $block2 $block3 $block4 $block5 $block6
              (local.get $10)
             )
            )
            (local.set $12
             (f64.mul
              (local.get $7)
              (f64.add
               (f64.mul
                (local.get $12)
                (f64.const 32)
               )
               (f64.const -16)
              )
             )
            )
            (br $block7)
           )
           (local.set $12
            (f64.mul
             (f64.add
              (local.get $12)
              (f64.const -0.5)
             )
             (f64.const 1e-08)
            )
           )
           (br $block7)
          )
          (local.set $12
           (f64.reinterpret_i64
            (i64.or
             (i64.or
              (i64.and
               (local.get $9)
               (i64.const 4503599627370494)
              )
              (i64.shl
               (local.get $9)
               (i64.const 63)
              )
             )
             (i64.const 1)
            )
           )
          )
          (br $block7)
         )
         (local.set $12
          (f64.mul
           (local.get $7)
           (f64.add
            (f64.mul
             (local.get $12)
             (f64.const 54)
            )
            (f64.const -1075.5)
           )
          )
         )
         (br $block7)
        )
        (local.set $12
         (f64.mul
          (local.get $7)
          (f64.add
           (select
            (f64.const -1075)
            (f64.const 1024)
            (i32.and
             (local.get $8)
             (i32.const 1)
            )
           )
           (f64.mul
            (f64.add
             (local.get $12)
             (f64.const -0.5)
            )
            (f64.const 1e-09)
           )
          )
         )
        )
        (br $block7)
       )
       (local.set $12
        (f64.load offset=1048576
         (i32.shl
          (i32.and
           (local.get $8)
           (i32.const 7)
          )
          (i32.const 3)
         )
        )
       )
      )
      (f64.store
       (local.get $11)
       (local.get $12)
      )
      (local.set $11
       (i32.add
        (local.get $11)
        (i32.const 8)
       )
      )
      (br_if $label
       (i32.ne
        (local.tee $8
         (i32.add
          (local.get $8)
          (i32.const 1)
         )
        )
        (i32.const 16384)
       )
      )
     )
     (local.set $11
      (i32.const 1)
     )
     (block $block10
      (block $block9
       (block $block8
        (br_table $block8 $block9 $block10
         (local.get $0)
        )
       )
       (local.set $11
        (select
         (select
          (i32.const 2)
          (i32.const 1)
          (i32.eq
           (local.get $1)
           (i32.const 1)
          )
         )
         (i32.const 2)
         (local.get $1)
        )
       )
       (br $block10)
      )
      (local.set $11
       (select
        (select
         (i32.const 3)
         (i32.const 1)
         (i32.eq
          (local.get $1)
          (i32.const 1)
         )
        )
        (i32.const 3)
        (local.get $1)
       )
      )
     )
     (local.set $13
      (call $_RNvNtCslyLwehSP5cz_14exp_experiment3abi8clock_ms)
     )
     (br_if $block11
      (local.get $2)
     )
     (block $block12
      (br_if $block12
       (local.get $4)
      )
      (local.set $9
       (i64.const 0)
      )
      (br $block13)
     )
     (local.set $1
      (i32.const 0)
     )
     (local.set $9
      (i64.const 0)
     )
     (local.set $14
      (i64.const 0)
     )
     (local.set $15
      (i64.const 0)
     )
     (local.set $16
      (i64.const 0)
     )
     (loop $label2
      (local.set $0
       (i32.const 0)
      )
      (loop $label1
       (f64.store offset=8
        (local.get $5)
        (f64.load
         (local.tee $10
          (i32.add
           (local.get $6)
           (local.get $0)
          )
         )
        )
       )
       (local.set $8
        (i32.add
         (local.get $5)
         (i32.const 8)
        )
       )
       (local.set $12
        (call_indirect $0 (type $1)
         (f64.load offset=8
          (local.get $5)
         )
         (local.get $11)
        )
       )
       (f64.store offset=8
        (local.get $5)
        (f64.load
         (i32.add
          (local.get $10)
          (i32.const 8)
         )
        )
       )
       (local.set $7
        (call_indirect $0 (type $1)
         (f64.load offset=8
          (local.get $5)
         )
         (local.get $11)
        )
       )
       (f64.store offset=8
        (local.get $5)
        (f64.load
         (i32.add
          (local.get $10)
          (i32.const 16)
         )
        )
       )
       (local.set $17
        (call_indirect $0 (type $1)
         (f64.load offset=8
          (local.get $5)
         )
         (local.get $11)
        )
       )
       (f64.store offset=8
        (local.get $5)
        (f64.load
         (i32.add
          (local.get $10)
          (i32.const 24)
         )
        )
       )
       (local.set $9
        (i64.add
         (local.get $9)
         (i64.reinterpret_f64
          (local.get $12)
         )
        )
       )
       (local.set $14
        (i64.add
         (local.get $14)
         (i64.reinterpret_f64
          (local.get $7)
         )
        )
       )
       (local.set $15
        (i64.add
         (local.get $15)
         (i64.reinterpret_f64
          (local.get $17)
         )
        )
       )
       (local.set $16
        (i64.add
         (local.get $16)
         (i64.reinterpret_f64
          (call_indirect $0 (type $1)
           (f64.load offset=8
            (local.get $5)
           )
           (local.get $11)
          )
         )
        )
       )
       (br_if $label1
        (i32.ne
         (local.tee $0
          (i32.add
           (local.get $0)
           (i32.const 32)
          )
         )
         (i32.const 131072)
        )
       )
      )
      (br_if $label2
       (i32.ne
        (local.tee $1
         (i32.add
          (local.get $1)
          (i32.const 1)
         )
        )
        (local.get $4)
       )
      )
     )
     (local.set $9
      (i64.add
       (i64.add
        (i64.add
         (local.get $14)
         (local.get $9)
        )
        (local.get $15)
       )
       (local.get $16)
      )
     )
     (br $block13)
    )
    (call $_RNvNtCs1eLRiQ1QTaf_5alloc7raw_vec12handle_error
     (i32.const 8)
     (i32.const 131072)
    )
    (unreachable)
   )
   (block $block14
    (br_if $block14
     (local.get $4)
    )
    (local.set $9
     (i64.const 0)
    )
    (br $block13)
   )
   (block $block16
    (block $block15
     (br_if $block15
      (i32.eq
       (local.get $3)
       (i32.const 5)
      )
     )
     (local.set $1
      (i32.const 0)
     )
     (local.set $9
      (i64.const 0)
     )
     (local.set $14
      (i64.const 0)
     )
     (br $block16)
    )
    (local.set $1
     (i32.const 0)
    )
    (local.set $9
     (i64.const 0)
    )
    (local.set $14
     (i64.const 0)
    )
    (loop $label4
     (local.set $10
      (i32.const 131072)
     )
     (local.set $8
      (i32.const 0)
     )
     (loop $label3
      (i64.store offset=8
       (local.get $5)
       (i64.load
        (i32.add
         (local.get $6)
         (i32.shl
          (i32.and
           (i32.add
            (local.get $8)
            (i32.and
             (i32.wrap_i64
              (i64.shr_u
               (local.get $14)
               (i64.const 52)
              )
             )
             (i32.const 15)
            )
           )
           (i32.const 16383)
          )
          (i32.const 3)
         )
        )
       )
      )
      (local.set $0
       (i32.add
        (local.get $5)
        (i32.const 8)
       )
      )
      (local.set $8
       (i32.add
        (local.get $8)
        (i32.const 1)
       )
      )
      (local.set $9
       (i64.add
        (local.get $9)
        (local.tee $14
         (i64.reinterpret_f64
          (call_indirect $0 (type $1)
           (f64.load offset=8
            (local.get $5)
           )
           (local.get $11)
          )
         )
        )
       )
      )
      (br_if $label3
       (local.tee $10
        (i32.add
         (local.get $10)
         (i32.const -8)
        )
       )
      )
     )
     (br_if $label4
      (i32.ne
       (local.tee $1
        (i32.add
         (local.get $1)
         (i32.const 1)
        )
       )
       (local.get $4)
      )
     )
     (br $block13)
    )
   )
   (loop $label6
    (local.set $8
     (i32.const 0)
    )
    (loop $label5
     (i64.store offset=8
      (local.get $5)
      (i64.xor
       (i64.load
        (local.tee $0
         (i32.add
          (local.get $6)
          (local.get $8)
         )
        )
       )
       (i64.and
        (local.get $14)
        (i64.const 255)
       )
      )
     )
     (local.set $10
      (i32.add
       (local.get $5)
       (i32.const 8)
      )
     )
     (local.set $12
      (call_indirect $0 (type $1)
       (f64.load offset=8
        (local.get $5)
       )
       (local.get $11)
      )
     )
     (i64.store offset=8
      (local.get $5)
      (i64.xor
       (i64.load
        (i32.add
         (local.get $0)
         (i32.const 8)
        )
       )
       (i64.and
        (local.tee $14
         (i64.reinterpret_f64
          (local.get $12)
         )
        )
        (i64.const 255)
       )
      )
     )
     (local.set $9
      (i64.add
       (i64.add
        (local.get $9)
        (local.get $14)
       )
       (local.tee $14
        (i64.reinterpret_f64
         (call_indirect $0 (type $1)
          (f64.load offset=8
           (local.get $5)
          )
          (local.get $11)
         )
        )
       )
      )
     )
     (br_if $label5
      (i32.ne
       (local.tee $8
        (i32.add
         (local.get $8)
         (i32.const 16)
        )
       )
       (i32.const 131072)
      )
     )
    )
    (br_if $label6
     (i32.ne
      (local.tee $1
       (i32.add
        (local.get $1)
        (i32.const 1)
       )
      )
      (local.get $4)
     )
    )
   )
  )
  (local.set $12
   (call $_RNvNtCslyLwehSP5cz_14exp_experiment3abi8clock_ms)
  )
  (i64.store offset=8
   (local.get $5)
   (local.get $9)
  )
  (local.set $11
   (i32.add
    (local.get $5)
    (i32.const 8)
   )
  )
  (local.set $9
   (i64.load offset=8
    (local.get $5)
   )
  )
  (call $_RNvCs9VHGBS8Gq78_7___rustc14___rust_dealloc
   (local.get $6)
   (i32.const 131072)
   (i32.const 8)
  )
  (call $_RNvNtCslyLwehSP5cz_14exp_experiment3abi6report
   (f64.mul
    (f64.sub
     (local.get $12)
     (local.get $13)
    )
    (f64.const 1e6)
   )
   (local.get $9)
   (i64.shl
    (i64.extend_i32_u
     (local.get $4)
    )
    (i64.const 14)
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $5)
    (i32.const 16)
   )
  )
 )
 (func $unary_bits (param $0 i32) (param $1 i32) (param $2 i64) (result i64)
  (local $3 i32)
  (local.set $3
   (i32.const 1)
  )
  (block $block2
   (block $block1
    (block $block
     (br_table $block $block1 $block2
      (local.get $0)
     )
    )
    (local.set $3
     (select
      (select
       (i32.const 2)
       (i32.const 1)
       (i32.eq
        (local.get $1)
        (i32.const 1)
       )
      )
      (i32.const 2)
      (local.get $1)
     )
    )
    (br $block2)
   )
   (local.set $3
    (select
     (select
      (i32.const 3)
      (i32.const 1)
      (i32.eq
       (local.get $1)
       (i32.const 1)
      )
     )
     (i32.const 3)
     (local.get $1)
    )
   )
  )
  (i64.reinterpret_f64
   (call_indirect $0 (type $1)
    (f64.reinterpret_i64
     (local.get $2)
    )
    (local.get $3)
   )
  )
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc12___rust_alloc (param $0 i32) (param $1 i32) (result i32)
  (return
   (call $_RNvCs9VHGBS8Gq78_7___rustc11___rdl_alloc
    (local.get $0)
    (local.get $1)
   )
  )
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc14___rust_dealloc (param $0 i32) (param $1 i32) (param $2 i32)
  (call $_RNvCs9VHGBS8Gq78_7___rustc13___rdl_dealloc
   (local.get $0)
   (local.get $1)
   (local.get $2)
  )
  (return)
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc14___rust_realloc (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (result i32)
  (return
   (call $_RNvCs9VHGBS8Gq78_7___rustc13___rdl_realloc
    (local.get $0)
    (local.get $1)
    (local.get $2)
    (local.get $3)
   )
  )
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc35___rust_no_alloc_shim_is_unstable_v2
  (return)
 )
 (func $_RINvNvMs5_NtCs1eLRiQ1QTaf_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs4ma0AJv6Sxl_3std (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i32)
  (local $5 i32)
  (local $6 i32)
  (global.set $__stack_pointer
   (local.tee $5
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (block $block
   (br_if $block
    (i32.ge_u
     (local.tee $1
      (i32.add
       (local.get $2)
       (local.get $1)
      )
     )
     (local.get $2)
    )
   )
   (call $_RNvNtCs1eLRiQ1QTaf_5alloc7raw_vec12handle_error
    (i32.const 0)
    (i32.const 0)
   )
   (unreachable)
  )
  (call $_RNvMs8_NtCs1eLRiQ1QTaf_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs4ma0AJv6Sxl_3std
   (i32.add
    (local.get $5)
    (i32.const 4)
   )
   (local.tee $2
    (i32.load
     (local.get $0)
    )
   )
   (i32.load offset=4
    (local.get $0)
   )
   (local.tee $2
    (select
     (local.tee $6
      (select
       (i32.const 8)
       (i32.const 4)
       (i32.eq
        (local.get $4)
        (i32.const 1)
       )
      )
     )
     (local.tee $2
      (select
       (local.tee $2
        (i32.shl
         (local.get $2)
         (i32.const 1)
        )
       )
       (local.get $1)
       (i32.gt_u
        (local.get $2)
        (local.get $1)
       )
      )
     )
     (i32.gt_u
      (local.get $6)
      (local.get $2)
     )
    )
   )
   (local.get $3)
   (local.get $4)
  )
  (block $block1
   (br_if $block1
    (i32.ne
     (i32.load offset=4
      (local.get $5)
     )
     (i32.const 1)
    )
   )
   (call $_RNvNtCs1eLRiQ1QTaf_5alloc7raw_vec12handle_error
    (i32.load offset=8
     (local.get $5)
    )
    (i32.load offset=12
     (local.get $5)
    )
   )
   (unreachable)
  )
  (local.set $4
   (i32.load offset=8
    (local.get $5)
   )
  )
  (i32.store
   (local.get $0)
   (local.get $2)
  )
  (i32.store offset=4
   (local.get $0)
   (local.get $4)
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $5)
    (i32.const 16)
   )
  )
 )
 (func $_RINvNtCskCpoLMRBwWe_4core3ptr9drop_glueNtNtCs1eLRiQ1QTaf_5alloc6string6StringECs4ma0AJv6Sxl_3std (param $0 i32)
  (local $1 i32)
  (block $block
   (br_if $block
    (i32.eqz
     (local.tee $1
      (i32.load
       (local.get $0)
      )
     )
    )
   )
   (call $_RNvCs9VHGBS8Gq78_7___rustc14___rust_dealloc
    (i32.load offset=4
     (local.get $0)
    )
    (local.get $1)
    (i32.const 1)
   )
  )
 )
 (func $_RINvNtCskCpoLMRBwWe_4core3ptr9drop_glueNtNvNtCs4ma0AJv6Sxl_3std9panicking13panic_handler19FormatStringPayloadEBH_ (param $0 i32)
  (local $1 i32)
  (block $block
   (br_if $block
    (i32.lt_s
     (local.tee $1
      (i32.load
       (local.get $0)
      )
     )
     (i32.const 1)
    )
   )
   (call $_RNvCs9VHGBS8Gq78_7___rustc14___rust_dealloc
    (i32.load offset=4
     (local.get $0)
    )
    (local.get $1)
    (i32.const 1)
   )
  )
 )
 (func $_RINvNtNtCs4ma0AJv6Sxl_3std3sys9backtrace26___rust_end_short_backtraceNCNvNtB6_5alloc8rust_oom0zEB6_ (param $0 i32)
  (call $_RNCNvNtCs4ma0AJv6Sxl_3std5alloc8rust_oom0B5_
   (local.get $0)
  )
  (unreachable)
 )
 (func $_RNCNvNtCs4ma0AJv6Sxl_3std5alloc8rust_oom0B5_ (param $0 i32)
  (call_indirect $0 (type $0)
   (i32.load
    (local.get $0)
   )
   (i32.load offset=4
    (local.get $0)
   )
   (select
    (local.tee $0
     (i32.load offset=1051876
      (i32.const 0)
     )
    )
    (i32.const 4)
    (local.get $0)
   )
  )
  (unreachable)
 )
 (func $_RINvNtNtCs4ma0AJv6Sxl_3std3sys9backtrace26___rust_end_short_backtraceNCNvNtB6_9panicking13panic_handler0zEB6_ (param $0 i32)
  (call $_RNCNvNtCs4ma0AJv6Sxl_3std9panicking13panic_handler0B5_
   (local.get $0)
  )
  (unreachable)
 )
 (func $_RNCNvNtCs4ma0AJv6Sxl_3std9panicking13panic_handler0B5_ (param $0 i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (global.set $__stack_pointer
   (local.tee $1
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (block $block
   (br_if $block
    (i32.eqz
     (i32.and
      (local.tee $3
       (i32.load offset=4
        (local.tee $2
         (i32.load
          (local.get $0)
         )
        )
       )
      )
      (i32.const 1)
     )
    )
   )
   (local.set $2
    (i32.load
     (local.get $2)
    )
   )
   (i32.store offset=4
    (local.get $1)
    (i32.shr_u
     (local.get $3)
     (i32.const 1)
    )
   )
   (i32.store
    (local.get $1)
    (local.get $2)
   )
   (call $_RNvNtCs4ma0AJv6Sxl_3std9panicking15panic_with_hook
    (local.get $1)
    (i32.const 1048640)
    (i32.load offset=4
     (local.get $0)
    )
    (i32.load8_u offset=8
     (local.tee $0
      (i32.load offset=8
       (local.get $0)
      )
     )
    )
    (i32.load8_u offset=9
     (local.get $0)
    )
   )
   (unreachable)
  )
  (i32.store
   (local.get $1)
   (i32.const -1)
  )
  (i32.store offset=12
   (local.get $1)
   (local.get $0)
  )
  (call $_RNvNtCs4ma0AJv6Sxl_3std9panicking15panic_with_hook
   (local.get $1)
   (i32.const 1048668)
   (i32.load offset=4
    (local.get $0)
   )
   (i32.load8_u offset=8
    (local.tee $0
     (i32.load offset=8
      (local.get $0)
     )
    )
   )
   (i32.load8_u offset=9
    (local.get $0)
   )
  )
  (unreachable)
 )
 (func $_RNvMs8_NtCs1eLRiQ1QTaf_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs4ma0AJv6Sxl_3std (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i32) (param $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i64)
  (local.set $6
   (i32.const 1)
  )
  (local.set $7
   (i32.const 4)
  )
  (block $block1
   (block $block
    (br_if $block
     (i32.eqz
      (i32.wrap_i64
       (i64.shr_u
        (local.tee $8
         (i64.mul
          (i64.extend_i32_u
           (local.get $5)
          )
          (i64.extend_i32_u
           (local.get $3)
          )
         )
        )
        (i64.const 32)
       )
      )
     )
    )
    (local.set $3
     (i32.const 0)
    )
    (br $block1)
   )
   (block $block2
    (br_if $block2
     (i32.le_u
      (local.tee $3
       (i32.wrap_i64
        (local.get $8)
       )
      )
      (i32.sub
       (i32.const -2147483648)
       (local.get $4)
      )
     )
    )
    (local.set $3
     (i32.const 0)
    )
    (br $block1)
   )
   (block $block7
    (block $block6
     (block $block4
      (block $block3
       (br_if $block3
        (i32.eqz
         (local.get $1)
        )
       )
       (local.set $7
        (call $_RNvCs9VHGBS8Gq78_7___rustc14___rust_realloc
         (local.get $2)
         (i32.mul
          (local.get $5)
          (local.get $1)
         )
         (local.get $4)
         (local.get $3)
        )
       )
       (br $block4)
      )
      (block $block5
       (br_if $block5
        (local.get $3)
       )
       (local.set $7
        (local.get $4)
       )
       (br $block6)
      )
      (call $_RNvCs9VHGBS8Gq78_7___rustc35___rust_no_alloc_shim_is_unstable_v2)
      (local.set $7
       (call $_RNvCs9VHGBS8Gq78_7___rustc12___rust_alloc
        (local.get $3)
        (local.get $4)
       )
      )
     )
     (br_if $block6
      (local.get $7)
     )
     (i32.store offset=4
      (local.get $0)
      (local.get $4)
     )
     (br $block7)
    )
    (i32.store offset=4
     (local.get $0)
     (local.get $7)
    )
    (local.set $6
     (i32.const 0)
    )
   )
   (local.set $7
    (i32.const 8)
   )
  )
  (i32.store
   (i32.add
    (local.get $0)
    (local.get $7)
   )
   (local.get $3)
  )
  (i32.store
   (local.get $0)
   (local.get $6)
  )
 )
 (func $_RNvNtCs4ma0AJv6Sxl_3std9panicking15panic_with_hook (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (global.set $__stack_pointer
   (local.tee $5
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (block $block7
   (block $block6
    (block $block3
     (block $block
      (block $block5
       (block $block4
        (block $block1
         (block $block2
          (br_table $block $block1 $block2 $block1
           (i32.and
            (call $_RNvNtNtCs4ma0AJv6Sxl_3std9panicking11panic_count8increase
             (i32.const 1)
            )
            (i32.const 255)
           )
          )
         )
         (br_if $block
          (i32.le_s
           (local.tee $6
            (i32.load offset=1051880
             (i32.const 0)
            )
           )
           (i32.const -1)
          )
         )
         (br_if $block3
          (i32.lt_s
           (local.tee $7
            (i32.add
             (local.get $6)
             (i32.const 1)
            )
           )
           (local.get $6)
          )
         )
         (i32.store offset=1051880
          (i32.const 0)
          (local.get $7)
         )
         (br_if $block4
          (i32.load offset=1051884
           (i32.const 0)
          )
         )
         (i32.store offset=1051880
          (i32.const 0)
          (i32.add
           (local.get $7)
           (i32.const -1)
          )
         )
         (br $block5)
        )
        (call_indirect $0 (type $0)
         (local.get $5)
         (local.get $0)
         (i32.load offset=24
          (local.get $1)
         )
        )
        (unreachable)
       )
       (call_indirect $0 (type $0)
        (i32.add
         (local.get $5)
         (i32.const 8)
        )
        (local.get $0)
        (i32.load offset=20
         (local.get $1)
        )
       )
       (i32.store8 offset=29
        (local.get $5)
        (local.get $4)
       )
       (i32.store8 offset=28
        (local.get $5)
        (local.get $3)
       )
       (i32.store offset=24
        (local.get $5)
        (local.get $2)
       )
       (i64.store offset=16 align=4
        (local.get $5)
        (i64.load offset=8
         (local.get $5)
        )
       )
       (call_indirect $0 (type $0)
        (i32.load offset=1051884
         (i32.const 0)
        )
        (i32.add
         (local.get $5)
         (i32.const 16)
        )
        (i32.load offset=20
         (i32.load offset=1051888
          (i32.const 0)
         )
        )
       )
       (i32.store offset=1051880
        (i32.const 0)
        (i32.add
         (local.tee $5
          (i32.load offset=1051880
           (i32.const 0)
          )
         )
         (i32.const -1)
        )
       )
       (br_if $block6
        (i32.le_s
         (local.get $5)
         (i32.const 0)
        )
       )
      )
      (i32.store8 offset=1051872
       (i32.const 0)
       (i32.const 0)
      )
      (br_if $block7
       (local.get $3)
      )
     )
     (unreachable)
    )
    (call $_RNvNtCskCpoLMRBwWe_4core6option13expect_failed
     (i32.const 1049160)
     (i32.const 28)
     (i32.const 1049188)
    )
    (unreachable)
   )
   (call $_RNvNtCskCpoLMRBwWe_4core9panicking9panic_fmt
    (i32.const 1049236)
    (i32.const 77)
    (i32.const 1049276)
   )
   (unreachable)
  )
  (call $_RNvCs9VHGBS8Gq78_7___rustc10rust_panic
   (local.get $0)
   (local.get $1)
  )
  (unreachable)
 )
 (func $_RNvNtCs4ma0AJv6Sxl_3std5alloc24default_alloc_error_hook (param $0 i32) (param $1 i32)
  (i32.store8 offset=1051896
   (i32.const 0)
   (i32.const 1)
  )
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc10rust_panic (param $0 i32) (param $1 i32)
  (drop
   (call $_RNvCs9VHGBS8Gq78_7___rustc18___rust_start_panic
    (local.get $0)
    (local.get $1)
   )
  )
  (unreachable)
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc11___rdl_alloc (param $0 i32) (param $1 i32) (result i32)
  (block $block
   (br_if $block
    (i32.lt_u
     (local.get $1)
     (i32.const 9)
    )
   )
   (return
    (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE8memalignCs4ma0AJv6Sxl_3std
     (local.get $1)
     (local.get $0)
    )
   )
  )
  (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE6mallocCs4ma0AJv6Sxl_3std
   (local.get $0)
  )
 )
 (func $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE8memalignCs4ma0AJv6Sxl_3std (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local.set $2
   (i32.const 0)
  )
  (block $block
   (br_if $block
    (i32.ge_u
     (local.get $1)
     (i32.sub
      (select
       (local.tee $3
        (i32.add
         (i32.and
          (i32.sub
           (i32.const -48)
           (i32.load offset=1051860
            (i32.const 0)
           )
          )
          (i32.const -9)
         )
         (i32.const -3)
        )
       )
       (i32.const -64)
       (i32.lt_u
        (local.get $3)
        (i32.const -64)
       )
      )
      (local.tee $0
       (select
        (local.get $0)
        (i32.const 16)
        (i32.gt_u
         (local.get $0)
         (i32.const 16)
        )
       )
      )
     )
    )
   )
   (br_if $block
    (i32.eqz
     (local.tee $1
      (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE6mallocCs4ma0AJv6Sxl_3std
       (i32.add
        (i32.add
         (local.get $0)
         (local.tee $3
          (select
           (i32.const 16)
           (i32.and
            (i32.add
             (local.get $1)
             (i32.const 11)
            )
            (i32.const -8)
           )
           (i32.lt_u
            (local.get $1)
            (i32.const 11)
           )
          )
         )
        )
        (i32.const 12)
       )
      )
     )
    )
   )
   (local.set $2
    (i32.add
     (local.get $1)
     (i32.const -8)
    )
   )
   (block $block2
    (block $block1
     (br_if $block1
      (i32.and
       (local.tee $4
        (i32.add
         (local.get $0)
         (i32.const -1)
        )
       )
       (local.get $1)
      )
     )
     (local.set $0
      (local.get $2)
     )
     (br $block2)
    )
    (local.set $4
     (i32.sub
      (i32.and
       (local.tee $6
        (i32.load
         (local.tee $5
          (i32.add
           (local.get $1)
           (i32.const -4)
          )
         )
        )
       )
       (i32.const -8)
      )
      (local.tee $1
       (i32.sub
        (local.tee $0
         (i32.add
          (local.tee $1
           (i32.add
            (i32.and
             (i32.add
              (local.get $4)
              (local.get $1)
             )
             (i32.sub
              (i32.const 0)
              (local.get $0)
             )
            )
            (i32.const -8)
           )
          )
          (select
           (i32.const 0)
           (local.get $0)
           (i32.gt_u
            (i32.sub
             (local.get $1)
             (local.get $2)
            )
            (i32.const 16)
           )
          )
         )
        )
        (local.get $2)
       )
      )
     )
    )
    (block $block3
     (br_if $block3
      (i32.eqz
       (i32.and
        (local.get $6)
        (i32.const 3)
       )
      )
     )
     (i32.store offset=4
      (local.get $0)
      (i32.or
       (i32.or
        (local.get $4)
        (i32.and
         (i32.load offset=4
          (local.get $0)
         )
         (i32.const 1)
        )
       )
       (i32.const 2)
      )
     )
     (i32.store offset=4
      (local.tee $4
       (i32.add
        (local.get $0)
        (local.get $4)
       )
      )
      (i32.or
       (i32.load offset=4
        (local.get $4)
       )
       (i32.const 1)
      )
     )
     (i32.store
      (local.get $5)
      (i32.or
       (i32.or
        (local.get $1)
        (i32.and
         (i32.load
          (local.get $5)
         )
         (i32.const 1)
        )
       )
       (i32.const 2)
      )
     )
     (i32.store offset=4
      (local.tee $4
       (i32.add
        (local.get $2)
        (local.get $1)
       )
      )
      (i32.or
       (i32.load offset=4
        (local.get $4)
       )
       (i32.const 1)
      )
     )
     (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE13dispose_chunkCs4ma0AJv6Sxl_3std
      (local.get $2)
      (local.get $1)
     )
     (br $block2)
    )
    (local.set $2
     (i32.load
      (local.get $2)
     )
    )
    (i32.store offset=4
     (local.get $0)
     (local.get $4)
    )
    (i32.store
     (local.get $0)
     (i32.add
      (local.get $2)
      (local.get $1)
     )
    )
   )
   (block $block4
    (br_if $block4
     (i32.eqz
      (i32.and
       (local.tee $1
        (i32.load offset=4
         (local.get $0)
        )
       )
       (i32.const 3)
      )
     )
    )
    (br_if $block4
     (i32.le_u
      (local.tee $2
       (i32.and
        (local.get $1)
        (i32.const -8)
       )
      )
      (i32.add
       (local.get $3)
       (i32.const 16)
      )
     )
    )
    (i32.store offset=4
     (local.get $0)
     (i32.or
      (i32.or
       (local.get $3)
       (i32.and
        (local.get $1)
        (i32.const 1)
       )
      )
      (i32.const 2)
     )
    )
    (i32.store offset=4
     (local.tee $1
      (i32.add
       (local.get $0)
       (local.get $3)
      )
     )
     (i32.or
      (local.tee $3
       (i32.sub
        (local.get $2)
        (local.get $3)
       )
      )
      (i32.const 3)
     )
    )
    (i32.store offset=4
     (local.tee $2
      (i32.add
       (local.get $0)
       (local.get $2)
      )
     )
     (i32.or
      (i32.load offset=4
       (local.get $2)
      )
      (i32.const 1)
     )
    )
    (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE13dispose_chunkCs4ma0AJv6Sxl_3std
     (local.get $1)
     (local.get $3)
    )
   )
   (local.set $2
    (i32.add
     (local.get $0)
     (i32.const 8)
    )
   )
  )
  (local.get $2)
 )
 (func $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE6mallocCs4ma0AJv6Sxl_3std (param $0 i32) (result i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i64)
  (global.set $__stack_pointer
   (local.tee $1
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (block $block1
   (block $block2
    (block $block3
     (block $block
      (br_if $block
       (i32.lt_u
        (local.get $0)
        (i32.const 245)
       )
      )
      (local.set $2
       (i32.const 0)
      )
      (br_if $block1
       (i32.ge_u
        (local.get $0)
        (select
         (local.tee $3
          (i32.add
           (i32.and
            (i32.sub
             (i32.const -48)
             (i32.load offset=1051860
              (i32.const 0)
             )
            )
            (i32.const -9)
           )
           (i32.const -3)
          )
         )
         (i32.const -64)
         (i32.lt_u
          (local.get $3)
          (i32.const -64)
         )
        )
       )
      )
      (local.set $3
       (i32.and
        (local.tee $2
         (i32.add
          (local.get $0)
          (i32.const 11)
         )
        )
        (i32.const -8)
       )
      )
      (br_if $block2
       (i32.eqz
        (local.tee $4
         (i32.load offset=1051820
          (i32.const 0)
         )
        )
       )
      )
      (local.set $5
       (i32.const 31)
      )
      (br_if $block3
       (i32.ge_u
        (local.get $0)
        (i32.const 16777205)
       )
      )
      (local.set $5
       (i32.add
        (i32.sub
         (i32.and
          (i32.shr_u
           (local.get $3)
           (i32.sub
            (i32.const 38)
            (local.tee $0
             (i32.clz
              (i32.shr_u
               (local.get $2)
               (i32.const 8)
              )
             )
            )
           )
          )
          (i32.const 1)
         )
         (i32.shl
          (local.get $0)
          (i32.const 1)
         )
        )
        (i32.const 62)
       )
      )
      (br $block3)
     )
     (block $block13
      (block $block17
       (block $block21
        (block $block6
         (block $block5
          (block $block4
           (br_if $block4
            (i32.eqz
             (i32.and
              (local.tee $0
               (i32.shr_u
                (local.tee $6
                 (i32.load offset=1051816
                  (i32.const 0)
                 )
                )
                (local.tee $2
                 (i32.shr_u
                  (local.tee $3
                   (select
                    (i32.const 16)
                    (i32.and
                     (i32.add
                      (local.get $0)
                      (i32.const 11)
                     )
                     (i32.const 504)
                    )
                    (i32.lt_u
                     (local.get $0)
                     (i32.const 11)
                    )
                   )
                  )
                  (i32.const 3)
                 )
                )
               )
              )
              (i32.const 3)
             )
            )
           )
           (br_if $block5
            (i32.eq
             (local.tee $2
              (i32.add
               (local.tee $0
                (i32.shl
                 (local.tee $7
                  (i32.add
                   (i32.and
                    (i32.xor
                     (local.get $0)
                     (i32.const -1)
                    )
                    (i32.const 1)
                   )
                   (local.get $2)
                  )
                 )
                 (i32.const 3)
                )
               )
               (i32.const 1051552)
              )
             )
             (local.tee $8
              (i32.load offset=8
               (local.tee $3
                (i32.load
                 (i32.add
                  (local.get $0)
                  (i32.const 1051560)
                 )
                )
               )
              )
             )
            )
           )
           (i32.store offset=12
            (local.get $8)
            (local.get $2)
           )
           (i32.store offset=8
            (local.get $2)
            (local.get $8)
           )
           (br $block6)
          )
          (br_if $block2
           (i32.le_u
            (local.get $3)
            (i32.load offset=1051824
             (i32.const 0)
            )
           )
          )
          (block $block7
           (br_if $block7
            (local.get $0)
           )
           (br_if $block2
            (i32.eqz
             (local.tee $0
              (i32.load offset=1051820
               (i32.const 0)
              )
             )
            )
           )
           (local.set $2
            (i32.sub
             (i32.and
              (i32.load offset=4
               (local.tee $8
                (i32.load
                 (i32.add
                  (i32.shl
                   (i32.ctz
                    (local.get $0)
                   )
                   (i32.const 2)
                  )
                  (i32.const 1051408)
                 )
                )
               )
              )
              (i32.const -8)
             )
             (local.get $3)
            )
           )
           (local.set $6
            (local.get $8)
           )
           (block $block9
            (loop $label
             (block $block8
              (br_if $block8
               (local.tee $0
                (i32.load offset=16
                 (local.get $8)
                )
               )
              )
              (br_if $block9
               (i32.eqz
                (local.tee $0
                 (i32.load offset=20
                  (local.get $8)
                 )
                )
               )
              )
             )
             (local.set $2
              (select
               (local.tee $8
                (i32.sub
                 (i32.and
                  (i32.load offset=4
                   (local.get $0)
                  )
                  (i32.const -8)
                 )
                 (local.get $3)
                )
               )
               (local.get $2)
               (local.tee $8
                (i32.lt_u
                 (local.get $8)
                 (local.get $2)
                )
               )
              )
             )
             (local.set $6
              (select
               (local.get $0)
               (local.get $6)
               (local.get $8)
              )
             )
             (local.set $8
              (local.get $0)
             )
             (br $label)
            )
           )
           (local.set $5
            (i32.load offset=24
             (local.get $6)
            )
           )
           (block $block12
            (block $block11
             (block $block10
              (br_if $block10
               (i32.ne
                (local.get $6)
                (local.tee $0
                 (i32.load offset=12
                  (local.get $6)
                 )
                )
               )
              )
              (br_if $block11
               (local.tee $8
                (i32.load
                 (i32.add
                  (local.get $6)
                  (select
                   (i32.const 20)
                   (i32.const 16)
                   (local.tee $0
                    (i32.load offset=20
                     (local.get $6)
                    )
                   )
                  )
                 )
                )
               )
              )
              (local.set $0
               (i32.const 0)
              )
              (br $block12)
             )
             (i32.store offset=12
              (local.tee $8
               (i32.load offset=8
                (local.get $6)
               )
              )
              (local.get $0)
             )
             (i32.store offset=8
              (local.get $0)
              (local.get $8)
             )
             (br $block12)
            )
            (local.set $7
             (select
              (i32.add
               (local.get $6)
               (i32.const 20)
              )
              (i32.add
               (local.get $6)
               (i32.const 16)
              )
              (local.get $0)
             )
            )
            (loop $label1
             (local.set $9
              (local.get $7)
             )
             (local.set $7
              (select
               (i32.add
                (local.tee $0
                 (local.get $8)
                )
                (i32.const 20)
               )
               (i32.add
                (local.get $0)
                (i32.const 16)
               )
               (local.tee $8
                (i32.load offset=20
                 (local.get $0)
                )
               )
              )
             )
             (br_if $label1
              (local.tee $8
               (i32.load
                (i32.add
                 (local.get $0)
                 (select
                  (i32.const 20)
                  (i32.const 16)
                  (local.get $8)
                 )
                )
               )
              )
             )
            )
            (i32.store
             (local.get $9)
             (i32.const 0)
            )
           )
           (br_if $block13
            (i32.eqz
             (local.get $5)
            )
           )
           (block $block16
            (block $block14
             (br_if $block14
              (i32.eq
               (local.get $6)
               (i32.load
                (local.tee $8
                 (i32.add
                  (i32.shl
                   (i32.load offset=28
                    (local.get $6)
                   )
                   (i32.const 2)
                  )
                  (i32.const 1051408)
                 )
                )
               )
              )
             )
             (block $block15
              (br_if $block15
               (i32.eq
                (local.get $6)
                (i32.load offset=16
                 (local.get $5)
                )
               )
              )
              (i32.store offset=20
               (local.get $5)
               (local.get $0)
              )
              (br_if $block16
               (local.get $0)
              )
              (br $block13)
             )
             (i32.store offset=16
              (local.get $5)
              (local.get $0)
             )
             (br_if $block16
              (local.get $0)
             )
             (br $block13)
            )
            (i32.store
             (local.get $8)
             (local.get $0)
            )
            (br_if $block17
             (i32.eqz
              (local.get $0)
             )
            )
           )
           (i32.store offset=24
            (local.get $0)
            (local.get $5)
           )
           (block $block18
            (br_if $block18
             (i32.eqz
              (local.tee $8
               (i32.load offset=16
                (local.get $6)
               )
              )
             )
            )
            (i32.store offset=16
             (local.get $0)
             (local.get $8)
            )
            (i32.store offset=24
             (local.get $8)
             (local.get $0)
            )
           )
           (br_if $block13
            (i32.eqz
             (local.tee $8
              (i32.load offset=20
               (local.get $6)
              )
             )
            )
           )
           (i32.store offset=20
            (local.get $0)
            (local.get $8)
           )
           (i32.store offset=24
            (local.get $8)
            (local.get $0)
           )
           (br $block13)
          )
          (block $block20
           (block $block19
            (br_if $block19
             (i32.eq
              (local.tee $8
               (i32.add
                (local.tee $2
                 (i32.shl
                  (local.tee $9
                   (i32.ctz
                    (i32.and
                     (i32.shl
                      (local.get $0)
                      (local.get $2)
                     )
                     (i32.or
                      (local.tee $0
                       (i32.shl
                        (i32.const 2)
                        (local.get $2)
                       )
                      )
                      (i32.sub
                       (i32.const 0)
                       (local.get $0)
                      )
                     )
                    )
                   )
                  )
                  (i32.const 3)
                 )
                )
                (i32.const 1051552)
               )
              )
              (local.tee $7
               (i32.load offset=8
                (local.tee $0
                 (i32.load
                  (i32.add
                   (local.get $2)
                   (i32.const 1051560)
                  )
                 )
                )
               )
              )
             )
            )
            (i32.store offset=12
             (local.get $7)
             (local.get $8)
            )
            (i32.store offset=8
             (local.get $8)
             (local.get $7)
            )
            (br $block20)
           )
           (i32.store offset=1051816
            (i32.const 0)
            (i32.and
             (local.get $6)
             (i32.rotl
              (i32.const -2)
              (local.get $9)
             )
            )
           )
          )
          (i32.store offset=4
           (local.get $0)
           (i32.or
            (local.get $3)
            (i32.const 3)
           )
          )
          (i32.store
           (i32.add
            (local.get $0)
            (local.get $2)
           )
           (local.tee $8
            (i32.sub
             (local.get $2)
             (local.get $3)
            )
           )
          )
          (i32.store offset=4
           (local.tee $6
            (i32.add
             (local.get $0)
             (local.get $3)
            )
           )
           (i32.or
            (local.get $8)
            (i32.const 1)
           )
          )
          (br_if $block21
           (i32.eqz
            (local.tee $3
             (i32.load offset=1051824
              (i32.const 0)
             )
            )
           )
          )
          (local.set $2
           (i32.load offset=1051832
            (i32.const 0)
           )
          )
          (block $block23
           (block $block22
            (br_if $block22
             (i32.and
              (local.tee $7
               (i32.load offset=1051816
                (i32.const 0)
               )
              )
              (local.tee $9
               (i32.shl
                (i32.const 1)
                (i32.shr_u
                 (local.get $3)
                 (i32.const 3)
                )
               )
              )
             )
            )
            (i32.store offset=1051816
             (i32.const 0)
             (i32.or
              (local.get $7)
              (local.get $9)
             )
            )
            (local.set $7
             (local.tee $3
              (i32.add
               (i32.and
                (local.get $3)
                (i32.const -8)
               )
               (i32.const 1051552)
              )
             )
            )
            (br $block23)
           )
           (local.set $7
            (i32.add
             (local.tee $3
              (i32.and
               (local.get $3)
               (i32.const -8)
              )
             )
             (i32.const 1051552)
            )
           )
           (local.set $3
            (i32.load
             (i32.add
              (local.get $3)
              (i32.const 1051560)
             )
            )
           )
          )
          (i32.store offset=8
           (local.get $7)
           (local.get $2)
          )
          (i32.store offset=12
           (local.get $3)
           (local.get $2)
          )
          (i32.store offset=12
           (local.get $2)
           (local.get $7)
          )
          (i32.store offset=8
           (local.get $2)
           (local.get $3)
          )
          (br $block21)
         )
         (i32.store offset=1051816
          (i32.const 0)
          (i32.and
           (local.get $6)
           (i32.rotl
            (i32.const -2)
            (local.get $7)
           )
          )
         )
        )
        (local.set $2
         (i32.add
          (local.get $3)
          (i32.const 8)
         )
        )
        (i32.store offset=4
         (local.get $3)
         (i32.or
          (local.get $0)
          (i32.const 3)
         )
        )
        (i32.store offset=4
         (local.tee $0
          (i32.add
           (local.get $3)
           (local.get $0)
          )
         )
         (i32.or
          (i32.load offset=4
           (local.get $0)
          )
          (i32.const 1)
         )
        )
        (br $block1)
       )
       (local.set $2
        (i32.add
         (local.get $0)
         (i32.const 8)
        )
       )
       (i32.store offset=1051832
        (i32.const 0)
        (local.get $6)
       )
       (i32.store offset=1051824
        (i32.const 0)
        (local.get $8)
       )
       (br $block1)
      )
      (i32.store offset=1051820
       (i32.const 0)
       (i32.and
        (i32.load offset=1051820
         (i32.const 0)
        )
        (i32.rotl
         (i32.const -2)
         (i32.load offset=28
          (local.get $6)
         )
        )
       )
      )
     )
     (block $block28
      (block $block25
       (block $block24
        (br_if $block24
         (i32.lt_u
          (local.get $2)
          (i32.const 16)
         )
        )
        (i32.store offset=4
         (local.get $6)
         (i32.or
          (local.get $3)
          (i32.const 3)
         )
        )
        (i32.store offset=4
         (local.tee $8
          (i32.add
           (local.get $6)
           (local.get $3)
          )
         )
         (i32.or
          (local.get $2)
          (i32.const 1)
         )
        )
        (i32.store
         (i32.add
          (local.get $8)
          (local.get $2)
         )
         (local.get $2)
        )
        (br_if $block25
         (i32.eqz
          (local.tee $7
           (i32.load offset=1051824
            (i32.const 0)
           )
          )
         )
        )
        (local.set $0
         (i32.load offset=1051832
          (i32.const 0)
         )
        )
        (block $block27
         (block $block26
          (br_if $block26
           (i32.and
            (local.tee $9
             (i32.load offset=1051816
              (i32.const 0)
             )
            )
            (local.tee $5
             (i32.shl
              (i32.const 1)
              (i32.shr_u
               (local.get $7)
               (i32.const 3)
              )
             )
            )
           )
          )
          (i32.store offset=1051816
           (i32.const 0)
           (i32.or
            (local.get $9)
            (local.get $5)
           )
          )
          (local.set $9
           (local.tee $7
            (i32.add
             (i32.and
              (local.get $7)
              (i32.const -8)
             )
             (i32.const 1051552)
            )
           )
          )
          (br $block27)
         )
         (local.set $9
          (i32.add
           (local.tee $7
            (i32.and
             (local.get $7)
             (i32.const -8)
            )
           )
           (i32.const 1051552)
          )
         )
         (local.set $7
          (i32.load
           (i32.add
            (local.get $7)
            (i32.const 1051560)
           )
          )
         )
        )
        (i32.store offset=8
         (local.get $9)
         (local.get $0)
        )
        (i32.store offset=12
         (local.get $7)
         (local.get $0)
        )
        (i32.store offset=12
         (local.get $0)
         (local.get $9)
        )
        (i32.store offset=8
         (local.get $0)
         (local.get $7)
        )
        (br $block25)
       )
       (i32.store offset=4
        (local.get $6)
        (i32.or
         (local.tee $0
          (i32.add
           (local.get $2)
           (local.get $3)
          )
         )
         (i32.const 3)
        )
       )
       (i32.store offset=4
        (local.tee $0
         (i32.add
          (local.get $6)
          (local.get $0)
         )
        )
        (i32.or
         (i32.load offset=4
          (local.get $0)
         )
         (i32.const 1)
        )
       )
       (br $block28)
      )
      (i32.store offset=1051832
       (i32.const 0)
       (local.get $8)
      )
      (i32.store offset=1051824
       (i32.const 0)
       (local.get $2)
      )
     )
     (br_if $block2
      (i32.eqz
       (local.tee $2
        (i32.add
         (local.get $6)
         (i32.const 8)
        )
       )
      )
     )
     (br $block1)
    )
    (local.set $2
     (i32.sub
      (i32.const 0)
      (local.get $3)
     )
    )
    (block $block34
     (block $block32
      (block $block30
       (block $block29
        (br_if $block29
         (local.tee $6
          (i32.load
           (i32.add
            (i32.shl
             (local.get $5)
             (i32.const 2)
            )
            (i32.const 1051408)
           )
          )
         )
        )
        (local.set $8
         (i32.const 0)
        )
        (local.set $0
         (i32.const 0)
        )
        (br $block30)
       )
       (local.set $8
        (i32.const 0)
       )
       (local.set $7
        (i32.shl
         (local.get $3)
         (select
          (i32.const 0)
          (i32.sub
           (i32.const 25)
           (i32.shr_u
            (local.get $5)
            (i32.const 1)
           )
          )
          (i32.eq
           (local.get $5)
           (i32.const 31)
          )
         )
        )
       )
       (local.set $0
        (i32.const 0)
       )
       (loop $label2
        (block $block31
         (br_if $block31
          (i32.lt_u
           (local.tee $9
            (i32.and
             (i32.load offset=4
              (local.tee $6
               (local.get $6)
              )
             )
             (i32.const -8)
            )
           )
           (local.get $3)
          )
         )
         (br_if $block31
          (i32.ge_u
           (local.tee $9
            (i32.sub
             (local.get $9)
             (local.get $3)
            )
           )
           (local.get $2)
          )
         )
         (local.set $8
          (local.get $6)
         )
         (local.set $2
          (local.get $9)
         )
         (br_if $block31
          (local.get $9)
         )
         (local.set $2
          (i32.const 0)
         )
         (local.set $0
          (local.get $6)
         )
         (local.set $8
          (local.get $6)
         )
         (br $block32)
        )
        (local.set $0
         (select
          (select
           (local.tee $9
            (i32.load offset=20
             (local.get $6)
            )
           )
           (local.get $0)
           (i32.ne
            (local.get $9)
            (local.tee $6
             (i32.load offset=16
              (i32.add
               (local.get $6)
               (i32.and
                (i32.shr_u
                 (local.get $7)
                 (i32.const 29)
                )
                (i32.const 4)
               )
              )
             )
            )
           )
          )
          (local.get $0)
          (local.get $9)
         )
        )
        (local.set $7
         (i32.shl
          (local.get $7)
          (i32.const 1)
         )
        )
        (br_if $label2
         (local.get $6)
        )
       )
      )
      (block $block33
       (br_if $block33
        (i32.or
         (local.get $0)
         (local.get $8)
        )
       )
       (local.set $8
        (i32.const 0)
       )
       (br_if $block2
        (i32.eqz
         (local.tee $0
          (i32.and
           (i32.or
            (local.tee $0
             (i32.shl
              (i32.const 2)
              (local.get $5)
             )
            )
            (i32.sub
             (i32.const 0)
             (local.get $0)
            )
           )
           (local.get $4)
          )
         )
        )
       )
       (local.set $0
        (i32.load
         (i32.add
          (i32.shl
           (i32.ctz
            (local.get $0)
           )
           (i32.const 2)
          )
          (i32.const 1051408)
         )
        )
       )
      )
      (br_if $block34
       (i32.eqz
        (local.get $0)
       )
      )
     )
     (loop $label3
      (local.set $9
       (select
        (local.tee $6
         (i32.sub
          (local.tee $7
           (i32.and
            (i32.load offset=4
             (local.get $0)
            )
            (i32.const -8)
           )
          )
          (local.get $3)
         )
        )
        (local.get $2)
        (i32.lt_u
         (local.get $6)
         (local.get $2)
        )
       )
      )
      (local.set $7
       (i32.lt_u
        (local.get $7)
        (local.get $3)
       )
      )
      (local.set $5
       (select
        (local.get $8)
        (local.get $0)
        (i32.ge_u
         (local.get $6)
         (local.get $2)
        )
       )
      )
      (block $block35
       (br_if $block35
        (local.tee $6
         (i32.load offset=16
          (local.get $0)
         )
        )
       )
       (local.set $6
        (i32.load offset=20
         (local.get $0)
        )
       )
      )
      (local.set $2
       (select
        (local.get $2)
        (local.get $9)
        (local.get $7)
       )
      )
      (local.set $8
       (select
        (local.get $8)
        (local.get $5)
        (local.get $7)
       )
      )
      (local.set $0
       (local.get $6)
      )
      (br_if $label3
       (local.get $6)
      )
     )
    )
    (br_if $block2
     (i32.eqz
      (local.get $8)
     )
    )
    (block $block36
     (br_if $block36
      (i32.lt_u
       (local.tee $0
        (i32.load offset=1051824
         (i32.const 0)
        )
       )
       (local.get $3)
      )
     )
     (br_if $block2
      (i32.ge_u
       (local.get $2)
       (i32.sub
        (local.get $0)
        (local.get $3)
       )
      )
     )
    )
    (local.set $5
     (i32.load offset=24
      (local.get $8)
     )
    )
    (block $block39
     (block $block38
      (block $block37
       (br_if $block37
        (i32.ne
         (local.get $8)
         (local.tee $0
          (i32.load offset=12
           (local.get $8)
          )
         )
        )
       )
       (br_if $block38
        (local.tee $6
         (i32.load
          (i32.add
           (local.get $8)
           (select
            (i32.const 20)
            (i32.const 16)
            (local.tee $0
             (i32.load offset=20
              (local.get $8)
             )
            )
           )
          )
         )
        )
       )
       (local.set $0
        (i32.const 0)
       )
       (br $block39)
      )
      (i32.store offset=12
       (local.tee $6
        (i32.load offset=8
         (local.get $8)
        )
       )
       (local.get $0)
      )
      (i32.store offset=8
       (local.get $0)
       (local.get $6)
      )
      (br $block39)
     )
     (local.set $7
      (select
       (i32.add
        (local.get $8)
        (i32.const 20)
       )
       (i32.add
        (local.get $8)
        (i32.const 16)
       )
       (local.get $0)
      )
     )
     (loop $label4
      (local.set $9
       (local.get $7)
      )
      (local.set $7
       (select
        (i32.add
         (local.tee $0
          (local.get $6)
         )
         (i32.const 20)
        )
        (i32.add
         (local.get $0)
         (i32.const 16)
        )
        (local.tee $6
         (i32.load offset=20
          (local.get $0)
         )
        )
       )
      )
      (br_if $label4
       (local.tee $6
        (i32.load
         (i32.add
          (local.get $0)
          (select
           (i32.const 20)
           (i32.const 16)
           (local.get $6)
          )
         )
        )
       )
      )
     )
     (i32.store
      (local.get $9)
      (i32.const 0)
     )
    )
    (block $block40
     (br_if $block40
      (i32.eqz
       (local.get $5)
      )
     )
     (block $block44
      (block $block43
       (block $block41
        (br_if $block41
         (i32.eq
          (local.get $8)
          (i32.load
           (local.tee $6
            (i32.add
             (i32.shl
              (i32.load offset=28
               (local.get $8)
              )
              (i32.const 2)
             )
             (i32.const 1051408)
            )
           )
          )
         )
        )
        (block $block42
         (br_if $block42
          (i32.eq
           (local.get $8)
           (i32.load offset=16
            (local.get $5)
           )
          )
         )
         (i32.store offset=20
          (local.get $5)
          (local.get $0)
         )
         (br_if $block43
          (local.get $0)
         )
         (br $block40)
        )
        (i32.store offset=16
         (local.get $5)
         (local.get $0)
        )
        (br_if $block43
         (local.get $0)
        )
        (br $block40)
       )
       (i32.store
        (local.get $6)
        (local.get $0)
       )
       (br_if $block44
        (i32.eqz
         (local.get $0)
        )
       )
      )
      (i32.store offset=24
       (local.get $0)
       (local.get $5)
      )
      (block $block45
       (br_if $block45
        (i32.eqz
         (local.tee $6
          (i32.load offset=16
           (local.get $8)
          )
         )
        )
       )
       (i32.store offset=16
        (local.get $0)
        (local.get $6)
       )
       (i32.store offset=24
        (local.get $6)
        (local.get $0)
       )
      )
      (br_if $block40
       (i32.eqz
        (local.tee $6
         (i32.load offset=20
          (local.get $8)
         )
        )
       )
      )
      (i32.store offset=20
       (local.get $0)
       (local.get $6)
      )
      (i32.store offset=24
       (local.get $6)
       (local.get $0)
      )
      (br $block40)
     )
     (i32.store offset=1051820
      (i32.const 0)
      (i32.and
       (i32.load offset=1051820
        (i32.const 0)
       )
       (i32.rotl
        (i32.const -2)
        (i32.load offset=28
         (local.get $8)
        )
       )
      )
     )
    )
    (block $block48
     (block $block46
      (br_if $block46
       (i32.lt_u
        (local.get $2)
        (i32.const 16)
       )
      )
      (i32.store offset=4
       (local.get $8)
       (i32.or
        (local.get $3)
        (i32.const 3)
       )
      )
      (i32.store offset=4
       (local.tee $0
        (i32.add
         (local.get $8)
         (local.get $3)
        )
       )
       (i32.or
        (local.get $2)
        (i32.const 1)
       )
      )
      (i32.store
       (i32.add
        (local.get $0)
        (local.get $2)
       )
       (local.get $2)
      )
      (block $block47
       (br_if $block47
        (i32.lt_u
         (local.get $2)
         (i32.const 256)
        )
       )
       (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE18insert_large_chunkCs4ma0AJv6Sxl_3std
        (local.get $0)
        (local.get $2)
       )
       (br $block48)
      )
      (block $block50
       (block $block49
        (br_if $block49
         (i32.and
          (local.tee $6
           (i32.load offset=1051816
            (i32.const 0)
           )
          )
          (local.tee $7
           (i32.shl
            (i32.const 1)
            (i32.shr_u
             (local.get $2)
             (i32.const 3)
            )
           )
          )
         )
        )
        (i32.store offset=1051816
         (i32.const 0)
         (i32.or
          (local.get $6)
          (local.get $7)
         )
        )
        (local.set $6
         (local.tee $2
          (i32.add
           (i32.and
            (local.get $2)
            (i32.const 248)
           )
           (i32.const 1051552)
          )
         )
        )
        (br $block50)
       )
       (local.set $6
        (i32.add
         (local.tee $2
          (i32.and
           (local.get $2)
           (i32.const 248)
          )
         )
         (i32.const 1051552)
        )
       )
       (local.set $2
        (i32.load
         (i32.add
          (local.get $2)
          (i32.const 1051560)
         )
        )
       )
      )
      (i32.store offset=8
       (local.get $6)
       (local.get $0)
      )
      (i32.store offset=12
       (local.get $2)
       (local.get $0)
      )
      (i32.store offset=12
       (local.get $0)
       (local.get $6)
      )
      (i32.store offset=8
       (local.get $0)
       (local.get $2)
      )
      (br $block48)
     )
     (i32.store offset=4
      (local.get $8)
      (i32.or
       (local.tee $0
        (i32.add
         (local.get $2)
         (local.get $3)
        )
       )
       (i32.const 3)
      )
     )
     (i32.store offset=4
      (local.tee $0
       (i32.add
        (local.get $8)
        (local.get $0)
       )
      )
      (i32.or
       (i32.load offset=4
        (local.get $0)
       )
       (i32.const 1)
      )
     )
    )
    (br_if $block1
     (local.tee $2
      (i32.add
       (local.get $8)
       (i32.const 8)
      )
     )
    )
   )
   (block $block71
    (block $block57
     (block $block68
      (block $block56
       (block $block65
        (block $block64
         (block $block58
          (block $block51
           (br_if $block51
            (i32.ge_u
             (local.tee $0
              (i32.load offset=1051824
               (i32.const 0)
              )
             )
             (local.get $3)
            )
           )
           (block $block52
            (br_if $block52
             (i32.gt_u
              (local.tee $0
               (i32.load offset=1051828
                (i32.const 0)
               )
              )
              (local.get $3)
             )
            )
            (local.set $2
             (i32.const 0)
            )
            (call $_RNvXs_NtCs9CYeDBX2pGb_8dlmalloc3sysNtB4_6SystemNtB6_9Allocator5alloc
             (i32.add
              (local.get $1)
              (i32.const 4)
             )
             (i32.const 1051868)
             (i32.and
              (i32.add
               (i32.add
                (local.get $3)
                (local.tee $0
                 (i32.load offset=1051860
                  (i32.const 0)
                 )
                )
               )
               (i32.const 47)
              )
              (i32.sub
               (i32.const 0)
               (local.get $0)
              )
             )
            )
            (br_if $block1
             (i32.eqz
              (local.tee $6
               (i32.load offset=4
                (local.get $1)
               )
              )
             )
            )
            (local.set $5
             (i32.load offset=12
              (local.get $1)
             )
            )
            (i32.store offset=1051840
             (i32.const 0)
             (local.tee $0
              (i32.add
               (i32.load offset=1051840
                (i32.const 0)
               )
               (local.tee $9
                (i32.load offset=8
                 (local.get $1)
                )
               )
              )
             )
            )
            (i32.store offset=1051844
             (i32.const 0)
             (select
              (local.tee $2
               (i32.load offset=1051844
                (i32.const 0)
               )
              )
              (local.get $0)
              (i32.gt_u
               (local.get $2)
               (local.get $0)
              )
             )
            )
            (block $block55
             (block $block54
              (block $block53
               (br_if $block53
                (i32.eqz
                 (local.tee $2
                  (i32.load offset=1051836
                   (i32.const 0)
                  )
                 )
                )
               )
               (local.set $0
                (i32.const 1051536)
               )
               (loop $label5
                (br_if $block54
                 (i32.eq
                  (local.get $6)
                  (i32.add
                   (local.tee $8
                    (i32.load
                     (local.get $0)
                    )
                   )
                   (local.tee $7
                    (i32.load offset=4
                     (local.get $0)
                    )
                   )
                  )
                 )
                )
                (br_if $label5
                 (local.tee $0
                  (i32.load offset=8
                   (local.get $0)
                  )
                 )
                )
                (br $block55)
               )
              )
              (br_if $block56
               (i32.eqz
                (local.tee $0
                 (i32.load offset=1051852
                  (i32.const 0)
                 )
                )
               )
              )
              (br_if $block56
               (i32.lt_u
                (local.get $6)
                (local.get $0)
               )
              )
              (br $block57)
             )
             (br_if $block55
              (i32.ge_u
               (local.get $2)
               (local.get $6)
              )
             )
             (br_if $block55
              (i32.gt_u
               (local.get $8)
               (local.get $2)
              )
             )
             (br_if $block55
              (i32.and
               (local.tee $8
                (i32.load offset=12
                 (local.get $0)
                )
               )
               (i32.const 1)
              )
             )
             (br_if $block58
              (i32.eq
               (local.get $5)
               (i32.shr_u
                (local.get $8)
                (i32.const 1)
               )
              )
             )
            )
            (i32.store offset=1051852
             (i32.const 0)
             (select
              (local.tee $0
               (i32.load offset=1051852
                (i32.const 0)
               )
              )
              (local.get $6)
              (i32.lt_u
               (local.get $0)
               (local.get $6)
              )
             )
            )
            (local.set $8
             (i32.add
              (local.get $6)
              (local.get $9)
             )
            )
            (local.set $0
             (i32.const 1051536)
            )
            (block $block63
             (block $block61
              (block $block60
               (block $block59
                (loop $label6
                 (br_if $block59
                  (i32.eq
                   (local.tee $7
                    (i32.load
                     (local.get $0)
                    )
                   )
                   (local.get $8)
                  )
                 )
                 (br_if $label6
                  (local.tee $0
                   (i32.load offset=8
                    (local.get $0)
                   )
                  )
                 )
                 (br $block60)
                )
               )
               (br_if $block60
                (i32.and
                 (local.tee $8
                  (i32.load offset=12
                   (local.get $0)
                  )
                 )
                 (i32.const 1)
                )
               )
               (br_if $block61
                (i32.eq
                 (local.get $5)
                 (i32.shr_u
                  (local.get $8)
                  (i32.const 1)
                 )
                )
               )
              )
              (local.set $0
               (i32.const 1051536)
              )
              (loop $label7
               (block $block62
                (br_if $block62
                 (i32.gt_u
                  (local.tee $8
                   (i32.load
                    (local.get $0)
                   )
                  )
                  (local.get $2)
                 )
                )
                (br_if $block63
                 (i32.lt_u
                  (local.get $2)
                  (local.tee $8
                   (i32.add
                    (local.get $8)
                    (i32.load offset=4
                     (local.get $0)
                    )
                   )
                  )
                 )
                )
               )
               (local.set $0
                (i32.load offset=8
                 (local.get $0)
                )
               )
               (br $label7)
              )
             )
             (i32.store
              (local.get $0)
              (local.get $6)
             )
             (i32.store offset=4
              (local.get $0)
              (i32.add
               (i32.load offset=4
                (local.get $0)
               )
               (local.get $9)
              )
             )
             (i32.store offset=4
              (local.tee $6
               (i32.add
                (i32.and
                 (i32.add
                  (local.get $6)
                  (i32.const 15)
                 )
                 (i32.const -8)
                )
                (i32.const -8)
               )
              )
              (i32.or
               (local.get $3)
               (i32.const 3)
              )
             )
             (local.set $2
              (i32.sub
               (local.tee $8
                (i32.add
                 (i32.and
                  (i32.add
                   (local.get $7)
                   (i32.const 15)
                  )
                  (i32.const -8)
                 )
                 (i32.const -8)
                )
               )
               (local.tee $0
                (i32.add
                 (local.get $6)
                 (local.get $3)
                )
               )
              )
             )
             (br_if $block64
              (i32.eq
               (local.get $8)
               (i32.load offset=1051836
                (i32.const 0)
               )
              )
             )
             (br_if $block65
              (i32.eq
               (local.get $8)
               (i32.load offset=1051832
                (i32.const 0)
               )
              )
             )
             (block $block66
              (br_if $block66
               (i32.ne
                (i32.and
                 (local.tee $3
                  (i32.load offset=4
                   (local.get $8)
                  )
                 )
                 (i32.const 3)
                )
                (i32.const 1)
               )
              )
              (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE12unlink_chunkCs4ma0AJv6Sxl_3std
               (local.get $8)
               (local.tee $3
                (i32.and
                 (local.get $3)
                 (i32.const -8)
                )
               )
              )
              (local.set $2
               (i32.add
                (local.get $3)
                (local.get $2)
               )
              )
              (local.set $3
               (i32.load offset=4
                (local.tee $8
                 (i32.add
                  (local.get $8)
                  (local.get $3)
                 )
                )
               )
              )
             )
             (i32.store offset=4
              (local.get $8)
              (i32.and
               (local.get $3)
               (i32.const -2)
              )
             )
             (i32.store offset=4
              (local.get $0)
              (i32.or
               (local.get $2)
               (i32.const 1)
              )
             )
             (i32.store
              (i32.add
               (local.get $0)
               (local.get $2)
              )
              (local.get $2)
             )
             (block $block67
              (br_if $block67
               (i32.lt_u
                (local.get $2)
                (i32.const 256)
               )
              )
              (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE18insert_large_chunkCs4ma0AJv6Sxl_3std
               (local.get $0)
               (local.get $2)
              )
              (br $block68)
             )
             (block $block70
              (block $block69
               (br_if $block69
                (i32.and
                 (local.tee $3
                  (i32.load offset=1051816
                   (i32.const 0)
                  )
                 )
                 (local.tee $8
                  (i32.shl
                   (i32.const 1)
                   (i32.shr_u
                    (local.get $2)
                    (i32.const 3)
                   )
                  )
                 )
                )
               )
               (i32.store offset=1051816
                (i32.const 0)
                (i32.or
                 (local.get $3)
                 (local.get $8)
                )
               )
               (local.set $3
                (local.tee $2
                 (i32.add
                  (i32.and
                   (local.get $2)
                   (i32.const 248)
                  )
                  (i32.const 1051552)
                 )
                )
               )
               (br $block70)
              )
              (local.set $3
               (i32.add
                (local.tee $2
                 (i32.and
                  (local.get $2)
                  (i32.const 248)
                 )
                )
                (i32.const 1051552)
               )
              )
              (local.set $2
               (i32.load
                (i32.add
                 (local.get $2)
                 (i32.const 1051560)
                )
               )
              )
             )
             (i32.store offset=8
              (local.get $3)
              (local.get $0)
             )
             (i32.store offset=12
              (local.get $2)
              (local.get $0)
             )
             (i32.store offset=12
              (local.get $0)
              (local.get $3)
             )
             (i32.store offset=8
              (local.get $0)
              (local.get $2)
             )
             (br $block68)
            )
            (i32.store offset=1051836
             (i32.const 0)
             (local.tee $7
              (i32.add
               (local.tee $0
                (i32.and
                 (i32.add
                  (local.get $6)
                  (i32.const 15)
                 )
                 (i32.const -8)
                )
               )
               (i32.const -8)
              )
             )
            )
            (i32.store offset=1051828
             (i32.const 0)
             (local.tee $4
              (i32.add
               (i32.add
                (i32.sub
                 (local.get $6)
                 (local.get $0)
                )
                (local.tee $0
                 (i32.add
                  (local.get $9)
                  (i32.const -40)
                 )
                )
               )
               (i32.const 8)
              )
             )
            )
            (i32.store offset=4
             (local.get $7)
             (i32.or
              (local.get $4)
              (i32.const 1)
             )
            )
            (i32.store offset=4
             (i32.add
              (local.get $6)
              (local.get $0)
             )
             (i32.const 40)
            )
            (i32.store offset=1051848
             (i32.const 0)
             (i32.const 2097152)
            )
            (i32.store offset=4
             (local.tee $7
              (select
               (local.get $2)
               (local.tee $0
                (i32.add
                 (i32.and
                  (i32.add
                   (local.get $8)
                   (i32.const -32)
                  )
                  (i32.const -8)
                 )
                 (i32.const -8)
                )
               )
               (i32.lt_u
                (local.get $0)
                (i32.add
                 (local.get $2)
                 (i32.const 16)
                )
               )
              )
             )
             (i32.const 27)
            )
            (local.set $10
             (i64.load offset=1051536 align=4
              (i32.const 0)
             )
            )
            (i64.store align=4
             (i32.add
              (local.get $7)
              (i32.const 16)
             )
             (i64.load offset=1051544 align=4
              (i32.const 0)
             )
            )
            (i64.store align=4
             (local.tee $0
              (i32.add
               (local.get $7)
               (i32.const 8)
              )
             )
             (local.get $10)
            )
            (i32.store offset=1051548
             (i32.const 0)
             (local.get $5)
            )
            (i32.store offset=1051540
             (i32.const 0)
             (local.get $9)
            )
            (i32.store offset=1051536
             (i32.const 0)
             (local.get $6)
            )
            (i32.store offset=1051544
             (i32.const 0)
             (local.get $0)
            )
            (local.set $0
             (i32.add
              (local.get $7)
              (i32.const 28)
             )
            )
            (loop $label8
             (i32.store
              (local.get $0)
              (i32.const 7)
             )
             (br_if $label8
              (i32.lt_u
               (local.tee $0
                (i32.add
                 (local.get $0)
                 (i32.const 4)
                )
               )
               (local.get $8)
              )
             )
            )
            (br_if $block71
             (i32.eq
              (local.get $2)
              (local.get $7)
             )
            )
            (i32.store offset=4
             (local.get $7)
             (i32.and
              (i32.load offset=4
               (local.get $7)
              )
              (i32.const -2)
             )
            )
            (i32.store offset=4
             (local.get $2)
             (i32.or
              (local.tee $0
               (i32.sub
                (local.get $7)
                (local.get $2)
               )
              )
              (i32.const 1)
             )
            )
            (i32.store
             (local.get $7)
             (local.get $0)
            )
            (block $block72
             (br_if $block72
              (i32.lt_u
               (local.get $0)
               (i32.const 256)
              )
             )
             (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE18insert_large_chunkCs4ma0AJv6Sxl_3std
              (local.get $2)
              (local.get $0)
             )
             (br $block71)
            )
            (block $block74
             (block $block73
              (br_if $block73
               (i32.and
                (local.tee $8
                 (i32.load offset=1051816
                  (i32.const 0)
                 )
                )
                (local.tee $6
                 (i32.shl
                  (i32.const 1)
                  (i32.shr_u
                   (local.get $0)
                   (i32.const 3)
                  )
                 )
                )
               )
              )
              (i32.store offset=1051816
               (i32.const 0)
               (i32.or
                (local.get $8)
                (local.get $6)
               )
              )
              (local.set $8
               (local.tee $0
                (i32.add
                 (i32.and
                  (local.get $0)
                  (i32.const 248)
                 )
                 (i32.const 1051552)
                )
               )
              )
              (br $block74)
             )
             (local.set $8
              (i32.add
               (local.tee $0
                (i32.and
                 (local.get $0)
                 (i32.const 248)
                )
               )
               (i32.const 1051552)
              )
             )
             (local.set $0
              (i32.load
               (i32.add
                (local.get $0)
                (i32.const 1051560)
               )
              )
             )
            )
            (i32.store offset=8
             (local.get $8)
             (local.get $2)
            )
            (i32.store offset=12
             (local.get $0)
             (local.get $2)
            )
            (i32.store offset=12
             (local.get $2)
             (local.get $8)
            )
            (i32.store offset=8
             (local.get $2)
             (local.get $0)
            )
            (br $block71)
           )
           (i32.store offset=1051828
            (i32.const 0)
            (local.tee $2
             (i32.sub
              (local.get $0)
              (local.get $3)
             )
            )
           )
           (i32.store offset=1051836
            (i32.const 0)
            (local.tee $8
             (i32.add
              (local.tee $0
               (i32.load offset=1051836
                (i32.const 0)
               )
              )
              (local.get $3)
             )
            )
           )
           (i32.store offset=4
            (local.get $8)
            (i32.or
             (local.get $2)
             (i32.const 1)
            )
           )
           (i32.store offset=4
            (local.get $0)
            (i32.or
             (local.get $3)
             (i32.const 3)
            )
           )
           (local.set $2
            (i32.add
             (local.get $0)
             (i32.const 8)
            )
           )
           (br $block1)
          )
          (local.set $2
           (i32.load offset=1051832
            (i32.const 0)
           )
          )
          (block $block76
           (block $block75
            (br_if $block75
             (i32.gt_u
              (local.tee $8
               (i32.sub
                (local.get $0)
                (local.get $3)
               )
              )
              (i32.const 15)
             )
            )
            (i32.store offset=1051832
             (i32.const 0)
             (i32.const 0)
            )
            (i32.store offset=1051824
             (i32.const 0)
             (i32.const 0)
            )
            (i32.store offset=4
             (local.get $2)
             (i32.or
              (local.get $0)
              (i32.const 3)
             )
            )
            (i32.store offset=4
             (local.tee $0
              (i32.add
               (local.get $2)
               (local.get $0)
              )
             )
             (i32.or
              (i32.load offset=4
               (local.get $0)
              )
              (i32.const 1)
             )
            )
            (br $block76)
           )
           (i32.store offset=1051824
            (i32.const 0)
            (local.get $8)
           )
           (i32.store offset=1051832
            (i32.const 0)
            (local.tee $6
             (i32.add
              (local.get $2)
              (local.get $3)
             )
            )
           )
           (i32.store offset=4
            (local.get $6)
            (i32.or
             (local.get $8)
             (i32.const 1)
            )
           )
           (i32.store
            (i32.add
             (local.get $2)
             (local.get $0)
            )
            (local.get $8)
           )
           (i32.store offset=4
            (local.get $2)
            (i32.or
             (local.get $3)
             (i32.const 3)
            )
           )
          )
          (local.set $2
           (i32.add
            (local.get $2)
            (i32.const 8)
           )
          )
          (br $block1)
         )
         (i32.store offset=4
          (local.get $0)
          (i32.add
           (local.get $7)
           (local.get $9)
          )
         )
         (i32.store offset=1051836
          (i32.const 0)
          (local.tee $8
           (i32.add
            (local.tee $2
             (i32.and
              (i32.add
               (local.tee $0
                (i32.load offset=1051836
                 (i32.const 0)
                )
               )
               (i32.const 15)
              )
              (i32.const -8)
             )
            )
            (i32.const -8)
           )
          )
         )
         (i32.store offset=1051828
          (i32.const 0)
          (local.tee $6
           (i32.add
            (i32.add
             (i32.sub
              (local.get $0)
              (local.get $2)
             )
             (local.tee $2
              (i32.add
               (i32.load offset=1051828
                (i32.const 0)
               )
               (local.get $9)
              )
             )
            )
            (i32.const 8)
           )
          )
         )
         (i32.store offset=4
          (local.get $8)
          (i32.or
           (local.get $6)
           (i32.const 1)
          )
         )
         (i32.store offset=4
          (i32.add
           (local.get $0)
           (local.get $2)
          )
          (i32.const 40)
         )
         (i32.store offset=1051848
          (i32.const 0)
          (i32.const 2097152)
         )
         (br $block71)
        )
        (i32.store offset=1051836
         (i32.const 0)
         (local.get $0)
        )
        (i32.store offset=1051828
         (i32.const 0)
         (local.tee $2
          (i32.add
           (i32.load offset=1051828
            (i32.const 0)
           )
           (local.get $2)
          )
         )
        )
        (i32.store offset=4
         (local.get $0)
         (i32.or
          (local.get $2)
          (i32.const 1)
         )
        )
        (br $block68)
       )
       (i32.store offset=1051832
        (i32.const 0)
        (local.get $0)
       )
       (i32.store offset=1051824
        (i32.const 0)
        (local.tee $2
         (i32.add
          (i32.load offset=1051824
           (i32.const 0)
          )
          (local.get $2)
         )
        )
       )
       (i32.store offset=4
        (local.get $0)
        (i32.or
         (local.get $2)
         (i32.const 1)
        )
       )
       (i32.store
        (i32.add
         (local.get $0)
         (local.get $2)
        )
        (local.get $2)
       )
       (br $block68)
      )
      (i32.store offset=1051852
       (i32.const 0)
       (local.get $6)
      )
      (br $block57)
     )
     (local.set $2
      (i32.add
       (local.get $6)
       (i32.const 8)
      )
     )
     (br $block1)
    )
    (i32.store offset=1051548
     (i32.const 0)
     (local.get $5)
    )
    (i32.store offset=1051540
     (i32.const 0)
     (local.get $9)
    )
    (i32.store offset=1051536
     (i32.const 0)
     (local.get $6)
    )
    (i32.store offset=1051564
     (i32.const 0)
     (i32.const 1051552)
    )
    (i32.store offset=1051572
     (i32.const 0)
     (i32.const 1051560)
    )
    (i32.store offset=1051560
     (i32.const 0)
     (i32.const 1051552)
    )
    (i32.store offset=1051580
     (i32.const 0)
     (i32.const 1051568)
    )
    (i32.store offset=1051568
     (i32.const 0)
     (i32.const 1051560)
    )
    (i32.store offset=1051588
     (i32.const 0)
     (i32.const 1051576)
    )
    (i32.store offset=1051576
     (i32.const 0)
     (i32.const 1051568)
    )
    (i32.store offset=1051596
     (i32.const 0)
     (i32.const 1051584)
    )
    (i32.store offset=1051584
     (i32.const 0)
     (i32.const 1051576)
    )
    (i32.store offset=1051604
     (i32.const 0)
     (i32.const 1051592)
    )
    (i32.store offset=1051592
     (i32.const 0)
     (i32.const 1051584)
    )
    (i32.store offset=1051612
     (i32.const 0)
     (i32.const 1051600)
    )
    (i32.store offset=1051600
     (i32.const 0)
     (i32.const 1051592)
    )
    (i32.store offset=1051620
     (i32.const 0)
     (i32.const 1051608)
    )
    (i32.store offset=1051608
     (i32.const 0)
     (i32.const 1051600)
    )
    (i32.store offset=1051856
     (i32.const 0)
     (select
      (local.tee $0
       (i32.load offset=1051864
        (i32.const 0)
       )
      )
      (i32.const -1)
      (local.get $0)
     )
    )
    (i32.store offset=1051628
     (i32.const 0)
     (i32.const 1051616)
    )
    (i32.store offset=1051616
     (i32.const 0)
     (i32.const 1051608)
    )
    (i32.store offset=1051624
     (i32.const 0)
     (i32.const 1051616)
    )
    (i32.store offset=1051636
     (i32.const 0)
     (i32.const 1051624)
    )
    (i32.store offset=1051632
     (i32.const 0)
     (i32.const 1051624)
    )
    (i32.store offset=1051644
     (i32.const 0)
     (i32.const 1051632)
    )
    (i32.store offset=1051640
     (i32.const 0)
     (i32.const 1051632)
    )
    (i32.store offset=1051652
     (i32.const 0)
     (i32.const 1051640)
    )
    (i32.store offset=1051648
     (i32.const 0)
     (i32.const 1051640)
    )
    (i32.store offset=1051660
     (i32.const 0)
     (i32.const 1051648)
    )
    (i32.store offset=1051656
     (i32.const 0)
     (i32.const 1051648)
    )
    (i32.store offset=1051668
     (i32.const 0)
     (i32.const 1051656)
    )
    (i32.store offset=1051664
     (i32.const 0)
     (i32.const 1051656)
    )
    (i32.store offset=1051676
     (i32.const 0)
     (i32.const 1051664)
    )
    (i32.store offset=1051684
     (i32.const 0)
     (i32.const 1051672)
    )
    (i32.store offset=1051672
     (i32.const 0)
     (i32.const 1051664)
    )
    (i32.store offset=1051680
     (i32.const 0)
     (i32.const 1051672)
    )
    (i32.store offset=1051692
     (i32.const 0)
     (i32.const 1051680)
    )
    (i32.store offset=1051700
     (i32.const 0)
     (i32.const 1051688)
    )
    (i32.store offset=1051688
     (i32.const 0)
     (i32.const 1051680)
    )
    (i32.store offset=1051696
     (i32.const 0)
     (i32.const 1051688)
    )
    (i32.store offset=1051708
     (i32.const 0)
     (i32.const 1051696)
    )
    (i32.store offset=1051704
     (i32.const 0)
     (i32.const 1051696)
    )
    (i32.store offset=1051716
     (i32.const 0)
     (i32.const 1051704)
    )
    (i32.store offset=1051712
     (i32.const 0)
     (i32.const 1051704)
    )
    (i32.store offset=1051724
     (i32.const 0)
     (i32.const 1051712)
    )
    (i32.store offset=1051720
     (i32.const 0)
     (i32.const 1051712)
    )
    (i32.store offset=1051732
     (i32.const 0)
     (i32.const 1051720)
    )
    (i32.store offset=1051728
     (i32.const 0)
     (i32.const 1051720)
    )
    (i32.store offset=1051740
     (i32.const 0)
     (i32.const 1051728)
    )
    (i32.store offset=1051736
     (i32.const 0)
     (i32.const 1051728)
    )
    (i32.store offset=1051748
     (i32.const 0)
     (i32.const 1051736)
    )
    (i32.store offset=1051744
     (i32.const 0)
     (i32.const 1051736)
    )
    (i32.store offset=1051756
     (i32.const 0)
     (i32.const 1051744)
    )
    (i32.store offset=1051752
     (i32.const 0)
     (i32.const 1051744)
    )
    (i32.store offset=1051764
     (i32.const 0)
     (i32.const 1051752)
    )
    (i32.store offset=1051772
     (i32.const 0)
     (i32.const 1051760)
    )
    (i32.store offset=1051760
     (i32.const 0)
     (i32.const 1051752)
    )
    (i32.store offset=1051780
     (i32.const 0)
     (i32.const 1051768)
    )
    (i32.store offset=1051768
     (i32.const 0)
     (i32.const 1051760)
    )
    (i32.store offset=1051788
     (i32.const 0)
     (i32.const 1051776)
    )
    (i32.store offset=1051776
     (i32.const 0)
     (i32.const 1051768)
    )
    (i32.store offset=1051796
     (i32.const 0)
     (i32.const 1051784)
    )
    (i32.store offset=1051784
     (i32.const 0)
     (i32.const 1051776)
    )
    (i32.store offset=1051804
     (i32.const 0)
     (i32.const 1051792)
    )
    (i32.store offset=1051792
     (i32.const 0)
     (i32.const 1051784)
    )
    (i32.store offset=1051812
     (i32.const 0)
     (i32.const 1051800)
    )
    (i32.store offset=1051800
     (i32.const 0)
     (i32.const 1051792)
    )
    (i32.store offset=1051836
     (i32.const 0)
     (local.tee $2
      (i32.add
       (local.tee $0
        (i32.and
         (i32.add
          (local.get $6)
          (i32.const 15)
         )
         (i32.const -8)
        )
       )
       (i32.const -8)
      )
     )
    )
    (i32.store offset=1051808
     (i32.const 0)
     (i32.const 1051800)
    )
    (i32.store offset=1051828
     (i32.const 0)
     (local.tee $8
      (i32.add
       (i32.add
        (i32.sub
         (local.get $6)
         (local.get $0)
        )
        (local.tee $0
         (i32.add
          (local.get $9)
          (i32.const -40)
         )
        )
       )
       (i32.const 8)
      )
     )
    )
    (i32.store offset=4
     (local.get $2)
     (i32.or
      (local.get $8)
      (i32.const 1)
     )
    )
    (i32.store offset=4
     (i32.add
      (local.get $6)
      (local.get $0)
     )
     (i32.const 40)
    )
    (i32.store offset=1051848
     (i32.const 0)
     (i32.const 2097152)
    )
   )
   (local.set $2
    (i32.const 0)
   )
   (br_if $block1
    (i32.le_u
     (local.tee $0
      (i32.load offset=1051828
       (i32.const 0)
      )
     )
     (local.get $3)
    )
   )
   (i32.store offset=1051828
    (i32.const 0)
    (local.tee $2
     (i32.sub
      (local.get $0)
      (local.get $3)
     )
    )
   )
   (i32.store offset=1051836
    (i32.const 0)
    (local.tee $8
     (i32.add
      (local.tee $0
       (i32.load offset=1051836
        (i32.const 0)
       )
      )
      (local.get $3)
     )
    )
   )
   (i32.store offset=4
    (local.get $8)
    (i32.or
     (local.get $2)
     (i32.const 1)
    )
   )
   (i32.store offset=4
    (local.get $0)
    (i32.or
     (local.get $3)
     (i32.const 3)
    )
   )
   (local.set $2
    (i32.add
     (local.get $0)
     (i32.const 8)
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $1)
    (i32.const 16)
   )
  )
  (local.get $2)
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc12___rust_abort
  (unreachable)
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc13___rdl_dealloc (param $0 i32) (param $1 i32) (param $2 i32)
  (local $3 i32)
  (local $4 i32)
  (block $block2
   (block $block
    (br_if $block
     (i32.lt_u
      (local.tee $4
       (i32.and
        (local.tee $3
         (i32.load
          (i32.add
           (local.get $0)
           (i32.const -4)
          )
         )
        )
        (i32.const -8)
       )
      )
      (i32.add
       (select
        (i32.const 4)
        (i32.const 8)
        (local.tee $3
         (i32.and
          (local.get $3)
          (i32.const 3)
         )
        )
       )
       (local.get $1)
      )
     )
    )
    (block $block1
     (br_if $block1
      (i32.eqz
       (local.get $3)
      )
     )
     (br_if $block2
      (i32.gt_u
       (local.get $4)
       (i32.add
        (local.get $1)
        (i32.const 39)
       )
      )
     )
    )
    (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE4freeCs4ma0AJv6Sxl_3std
     (local.get $0)
    )
    (return)
   )
   (call $_RNvNtCskCpoLMRBwWe_4core9panicking5panic
    (i32.const 1049015)
    (i32.const 46)
    (i32.const 1049064)
   )
   (unreachable)
  )
  (call $_RNvNtCskCpoLMRBwWe_4core9panicking5panic
   (i32.const 1049080)
   (i32.const 46)
   (i32.const 1049128)
  )
  (unreachable)
 )
 (func $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE4freeCs4ma0AJv6Sxl_3std (param $0 i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local.set $3
   (i32.add
    (local.tee $1
     (i32.add
      (local.get $0)
      (i32.const -8)
     )
    )
    (local.tee $0
     (i32.and
      (local.tee $2
       (i32.load
        (i32.add
         (local.get $0)
         (i32.const -4)
        )
       )
      )
      (i32.const -8)
     )
    )
   )
  )
  (block $block1
   (block $block
    (br_if $block
     (i32.and
      (local.get $2)
      (i32.const 1)
     )
    )
    (br_if $block1
     (i32.eqz
      (i32.and
       (local.get $2)
       (i32.const 2)
      )
     )
    )
    (local.set $0
     (i32.add
      (local.tee $2
       (i32.load
        (local.get $1)
       )
      )
      (local.get $0)
     )
    )
    (block $block2
     (br_if $block2
      (i32.ne
       (local.tee $1
        (i32.sub
         (local.get $1)
         (local.get $2)
        )
       )
       (i32.load offset=1051832
        (i32.const 0)
       )
      )
     )
     (br_if $block
      (i32.ne
       (i32.and
        (i32.load offset=4
         (local.get $3)
        )
        (i32.const 3)
       )
       (i32.const 3)
      )
     )
     (i32.store offset=1051824
      (i32.const 0)
      (local.get $0)
     )
     (i32.store offset=4
      (local.get $3)
      (i32.and
       (i32.load offset=4
        (local.get $3)
       )
       (i32.const -2)
      )
     )
     (i32.store offset=4
      (local.get $1)
      (i32.or
       (local.get $0)
       (i32.const 1)
      )
     )
     (i32.store
      (local.get $3)
      (local.get $0)
     )
     (return)
    )
    (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE12unlink_chunkCs4ma0AJv6Sxl_3std
     (local.get $1)
     (local.get $2)
    )
   )
   (block $block10
    (block $block11
     (block $block5
      (block $block8
       (block $block7
        (block $block4
         (block $block6
          (block $block3
           (br_if $block3
            (i32.and
             (local.tee $2
              (i32.load offset=4
               (local.get $3)
              )
             )
             (i32.const 2)
            )
           )
           (br_if $block4
            (i32.eq
             (local.get $3)
             (i32.load offset=1051836
              (i32.const 0)
             )
            )
           )
           (br_if $block5
            (i32.eq
             (local.get $3)
             (i32.load offset=1051832
              (i32.const 0)
             )
            )
           )
           (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE12unlink_chunkCs4ma0AJv6Sxl_3std
            (local.get $3)
            (local.tee $2
             (i32.and
              (local.get $2)
              (i32.const -8)
             )
            )
           )
           (i32.store offset=4
            (local.get $1)
            (i32.or
             (local.tee $0
              (i32.add
               (local.get $2)
               (local.get $0)
              )
             )
             (i32.const 1)
            )
           )
           (i32.store
            (i32.add
             (local.get $1)
             (local.get $0)
            )
            (local.get $0)
           )
           (br_if $block6
            (i32.ne
             (local.get $1)
             (i32.load offset=1051832
              (i32.const 0)
             )
            )
           )
           (i32.store offset=1051824
            (i32.const 0)
            (local.get $0)
           )
           (return)
          )
          (i32.store offset=4
           (local.get $3)
           (i32.and
            (local.get $2)
            (i32.const -2)
           )
          )
          (i32.store offset=4
           (local.get $1)
           (i32.or
            (local.get $0)
            (i32.const 1)
           )
          )
          (i32.store
           (i32.add
            (local.get $1)
            (local.get $0)
           )
           (local.get $0)
          )
         )
         (br_if $block7
          (i32.lt_u
           (local.get $0)
           (i32.const 256)
          )
         )
         (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE18insert_large_chunkCs4ma0AJv6Sxl_3std
          (local.get $1)
          (local.get $0)
         )
         (local.set $1
          (i32.const 0)
         )
         (i32.store offset=1051856
          (i32.const 0)
          (local.tee $0
           (i32.add
            (i32.load offset=1051856
             (i32.const 0)
            )
            (i32.const -1)
           )
          )
         )
         (br_if $block8
          (i32.eqz
           (local.get $0)
          )
         )
         (br $block1)
        )
        (i32.store offset=1051836
         (i32.const 0)
         (local.get $1)
        )
        (i32.store offset=1051828
         (i32.const 0)
         (local.tee $0
          (i32.add
           (i32.load offset=1051828
            (i32.const 0)
           )
           (local.get $0)
          )
         )
        )
        (i32.store offset=4
         (local.get $1)
         (i32.or
          (local.get $0)
          (i32.const 1)
         )
        )
        (block $block9
         (br_if $block9
          (i32.ne
           (local.get $1)
           (i32.load offset=1051832
            (i32.const 0)
           )
          )
         )
         (i32.store offset=1051824
          (i32.const 0)
          (i32.const 0)
         )
         (i32.store offset=1051832
          (i32.const 0)
          (i32.const 0)
         )
        )
        (br_if $block1
         (i32.le_u
          (local.get $0)
          (local.tee $4
           (i32.load offset=1051848
            (i32.const 0)
           )
          )
         )
        )
        (br_if $block1
         (i32.eq
          (i32.and
           (i32.sub
            (i32.const -48)
            (local.tee $1
             (i32.load offset=1051860
              (i32.const 0)
             )
            )
           )
           (i32.const -9)
          )
          (i32.const 3)
         )
        )
        (br_if $block1
         (i32.eqz
          (local.tee $0
           (i32.load offset=1051836
            (i32.const 0)
           )
          )
         )
        )
        (local.set $2
         (i32.const 0)
        )
        (br_if $block10
         (i32.lt_u
          (local.tee $5
           (i32.load offset=1051828
            (i32.const 0)
           )
          )
          (i32.const 41)
         )
        )
        (br_if $block11
         (i32.eqz
          (local.get $1)
         )
        )
        (local.set $1
         (i32.const 1051536)
        )
        (loop $label
         (block $block12
          (br_if $block12
           (i32.gt_u
            (local.tee $3
             (i32.load
              (local.get $1)
             )
            )
            (local.get $0)
           )
          )
          (br_if $block10
           (i32.lt_u
            (local.get $0)
            (i32.add
             (local.get $3)
             (i32.load offset=4
              (local.get $1)
             )
            )
           )
          )
         )
         (local.set $1
          (i32.load offset=8
           (local.get $1)
          )
         )
         (br $label)
        )
       )
       (block $block14
        (block $block13
         (br_if $block13
          (i32.and
           (local.tee $3
            (i32.load offset=1051816
             (i32.const 0)
            )
           )
           (local.tee $2
            (i32.shl
             (i32.const 1)
             (i32.shr_u
              (local.get $0)
              (i32.const 3)
             )
            )
           )
          )
         )
         (i32.store offset=1051816
          (i32.const 0)
          (i32.or
           (local.get $3)
           (local.get $2)
          )
         )
         (local.set $3
          (local.tee $0
           (i32.add
            (i32.and
             (local.get $0)
             (i32.const 248)
            )
            (i32.const 1051552)
           )
          )
         )
         (br $block14)
        )
        (local.set $3
         (i32.add
          (local.tee $0
           (i32.and
            (local.get $0)
            (i32.const 248)
           )
          )
          (i32.const 1051552)
         )
        )
        (local.set $0
         (i32.load
          (i32.add
           (local.get $0)
           (i32.const 1051560)
          )
         )
        )
       )
       (i32.store offset=8
        (local.get $3)
        (local.get $1)
       )
       (i32.store offset=12
        (local.get $0)
        (local.get $1)
       )
       (i32.store offset=12
        (local.get $1)
        (local.get $3)
       )
       (i32.store offset=8
        (local.get $1)
        (local.get $0)
       )
       (return)
      )
      (block $block15
       (br_if $block15
        (i32.eqz
         (local.tee $0
          (i32.load offset=1051544
           (i32.const 0)
          )
         )
        )
       )
       (local.set $1
        (i32.const 0)
       )
       (loop $label1
        (local.set $1
         (i32.add
          (local.get $1)
          (i32.const 1)
         )
        )
        (br_if $label1
         (local.tee $0
          (i32.load offset=8
           (local.get $0)
          )
         )
        )
       )
      )
      (i32.store offset=1051856
       (i32.const 0)
       (select
        (select
         (local.get $1)
         (local.tee $0
          (i32.load offset=1051864
           (i32.const 0)
          )
         )
         (i32.gt_u
          (local.get $1)
          (local.get $0)
         )
        )
        (i32.const -1)
        (local.get $0)
       )
      )
      (return)
     )
     (i32.store offset=1051832
      (i32.const 0)
      (local.get $1)
     )
     (i32.store offset=1051824
      (i32.const 0)
      (local.tee $0
       (i32.add
        (i32.load offset=1051824
         (i32.const 0)
        )
        (local.get $0)
       )
      )
     )
     (i32.store offset=4
      (local.get $1)
      (i32.or
       (local.get $0)
       (i32.const 1)
      )
     )
     (i32.store
      (i32.add
       (local.get $1)
       (local.get $0)
      )
      (local.get $0)
     )
     (return)
    )
    (call $_RNvNtNtCskCpoLMRBwWe_4core9panicking11panic_const23panic_const_div_by_zero
     (i32.const 1049144)
    )
    (unreachable)
   )
   (block $block16
    (br_if $block16
     (i32.eqz
      (local.tee $1
       (i32.load offset=1051544
        (i32.const 0)
       )
      )
     )
    )
    (local.set $2
     (i32.const 0)
    )
    (loop $label2
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label2
      (local.tee $1
       (i32.load offset=8
        (local.get $1)
       )
      )
     )
    )
   )
   (i32.store offset=1051856
    (i32.const 0)
    (select
     (select
      (local.get $2)
      (local.tee $1
       (i32.load offset=1051864
        (i32.const 0)
       )
      )
      (i32.gt_u
       (local.get $2)
       (local.get $1)
      )
     )
     (i32.const -1)
     (local.get $1)
    )
   )
   (br_if $block1
    (i32.le_u
     (local.get $5)
     (local.get $4)
    )
   )
   (i32.store offset=1051848
    (i32.const 0)
    (i32.const -1)
   )
   (return)
  )
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc13___rdl_realloc (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (result i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (block $block9
   (block $block7
    (block $block14
     (block $block16
      (block $block19
       (block $block8
        (block $block6
         (block $block2
          (block $block
           (br_if $block
            (i32.lt_u
             (local.tee $6
              (i32.and
               (local.tee $5
                (i32.load
                 (local.tee $4
                  (i32.add
                   (local.get $0)
                   (i32.const -4)
                  )
                 )
                )
               )
               (i32.const -8)
              )
             )
             (i32.add
              (select
               (i32.const 4)
               (i32.const 8)
               (local.tee $7
                (i32.and
                 (local.get $5)
                 (i32.const 3)
                )
               )
              )
              (local.get $1)
             )
            )
           )
           (local.set $8
            (i32.add
             (local.get $1)
             (i32.const 39)
            )
           )
           (block $block1
            (br_if $block1
             (i32.eqz
              (local.get $7)
             )
            )
            (br_if $block2
             (i32.gt_u
              (local.get $6)
              (local.get $8)
             )
            )
           )
           (block $block3
            (br_if $block3
             (i32.lt_u
              (local.get $2)
              (i32.const 9)
             )
            )
            (block $block4
             (br_if $block4
              (local.tee $2
               (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE8memalignCs4ma0AJv6Sxl_3std
                (local.get $2)
                (local.get $3)
               )
              )
             )
             (return
              (i32.const 0)
             )
            )
            (block $block5
             (br_if $block5
              (i32.eqz
               (local.tee $3
                (select
                 (local.get $1)
                 (local.get $3)
                 (i32.lt_u
                  (local.get $1)
                  (local.get $3)
                 )
                )
               )
              )
             )
             (memory.copy
              (local.get $2)
              (local.get $0)
              (local.get $3)
             )
            )
            (br_if $block6
             (i32.lt_u
              (local.tee $7
               (i32.and
                (local.tee $3
                 (i32.load
                  (local.get $4)
                 )
                )
                (i32.const -8)
               )
              )
              (i32.add
               (select
                (i32.const 4)
                (i32.const 8)
                (local.tee $3
                 (i32.and
                  (local.get $3)
                  (i32.const 3)
                 )
                )
               )
               (local.get $1)
              )
             )
            )
            (br_if $block7
             (i32.eqz
              (local.get $3)
             )
            )
            (br_if $block8
             (i32.gt_u
              (local.get $7)
              (local.get $8)
             )
            )
            (br $block7)
           )
           (local.set $2
            (i32.const 0)
           )
           (br_if $block9
            (i32.ge_u
             (local.get $3)
             (select
              (local.tee $1
               (i32.add
                (i32.and
                 (i32.sub
                  (i32.const -48)
                  (local.tee $9
                   (i32.load offset=1051860
                    (i32.const 0)
                   )
                  )
                 )
                 (i32.const -9)
                )
                (i32.const -3)
               )
              )
              (i32.const -64)
              (i32.lt_u
               (local.get $1)
               (i32.const -64)
              )
             )
            )
           )
           (local.set $1
            (select
             (i32.const 16)
             (i32.and
              (i32.add
               (local.get $3)
               (i32.const 11)
              )
              (i32.const -8)
             )
             (i32.lt_u
              (local.get $3)
              (i32.const 11)
             )
            )
           )
           (local.set $8
            (i32.add
             (local.get $0)
             (i32.const -8)
            )
           )
           (block $block12
            (block $block11
             (block $block13
              (block $block15
               (block $block10
                (br_if $block10
                 (i32.eqz
                  (local.get $7)
                 )
                )
                (local.set $7
                 (i32.add
                  (local.get $8)
                  (local.get $6)
                 )
                )
                (br_if $block11
                 (i32.ge_u
                  (local.get $6)
                  (local.get $1)
                 )
                )
                (br_if $block12
                 (i32.eq
                  (local.get $7)
                  (i32.load offset=1051836
                   (i32.const 0)
                  )
                 )
                )
                (br_if $block13
                 (i32.eq
                  (local.get $7)
                  (i32.load offset=1051832
                   (i32.const 0)
                  )
                 )
                )
                (br_if $block14
                 (i32.and
                  (local.tee $5
                   (i32.load offset=4
                    (local.get $7)
                   )
                  )
                  (i32.const 2)
                 )
                )
                (br_if $block14
                 (i32.lt_u
                  (local.tee $5
                   (i32.add
                    (local.tee $9
                     (i32.and
                      (local.get $5)
                      (i32.const -8)
                     )
                    )
                    (local.get $6)
                   )
                  )
                  (local.get $1)
                 )
                )
                (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE12unlink_chunkCs4ma0AJv6Sxl_3std
                 (local.get $7)
                 (local.get $9)
                )
                (br_if $block15
                 (i32.lt_u
                  (local.tee $7
                   (i32.sub
                    (local.get $5)
                    (local.get $1)
                   )
                  )
                  (i32.const 16)
                 )
                )
                (i32.store
                 (local.get $4)
                 (i32.or
                  (i32.or
                   (local.get $1)
                   (i32.and
                    (i32.load
                     (local.get $4)
                    )
                    (i32.const 1)
                   )
                  )
                  (i32.const 2)
                 )
                )
                (i32.store offset=4
                 (local.tee $1
                  (i32.add
                   (local.get $8)
                   (local.get $1)
                  )
                 )
                 (i32.or
                  (local.get $7)
                  (i32.const 3)
                 )
                )
                (i32.store offset=4
                 (local.tee $5
                  (i32.add
                   (local.get $8)
                   (local.get $5)
                  )
                 )
                 (i32.or
                  (i32.load offset=4
                   (local.get $5)
                  )
                  (i32.const 1)
                 )
                )
                (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE13dispose_chunkCs4ma0AJv6Sxl_3std
                 (local.get $1)
                 (local.get $7)
                )
                (br $block16)
               )
               (br_if $block14
                (i32.lt_u
                 (local.get $1)
                 (i32.const 256)
                )
               )
               (br_if $block14
                (i32.le_u
                 (local.get $6)
                 (local.get $1)
                )
               )
               (br_if $block14
                (i32.eqz
                 (local.get $8)
                )
               )
               (br_if $block14
                (i32.gt_u
                 (i32.sub
                  (local.get $6)
                  (local.get $1)
                 )
                 (i32.shl
                  (local.get $9)
                  (i32.const 1)
                 )
                )
               )
               (return
                (local.get $0)
               )
              )
              (i32.store
               (local.get $4)
               (i32.or
                (i32.or
                 (local.get $5)
                 (i32.and
                  (i32.load
                   (local.get $4)
                  )
                  (i32.const 1)
                 )
                )
                (i32.const 2)
               )
              )
              (i32.store offset=4
               (local.tee $1
                (i32.add
                 (local.get $8)
                 (local.get $5)
                )
               )
               (i32.or
                (i32.load offset=4
                 (local.get $1)
                )
                (i32.const 1)
               )
              )
              (br $block16)
             )
             (br_if $block14
              (i32.lt_u
               (local.tee $7
                (i32.add
                 (i32.load offset=1051824
                  (i32.const 0)
                 )
                 (local.get $6)
                )
               )
               (local.get $1)
              )
             )
             (block $block18
              (block $block17
               (br_if $block17
                (i32.gt_u
                 (local.tee $6
                  (i32.sub
                   (local.get $7)
                   (local.get $1)
                  )
                 )
                 (i32.const 15)
                )
               )
               (i32.store
                (local.get $4)
                (i32.or
                 (i32.or
                  (i32.and
                   (local.get $5)
                   (i32.const 1)
                  )
                  (local.get $7)
                 )
                 (i32.const 2)
                )
               )
               (i32.store offset=4
                (local.tee $1
                 (i32.add
                  (local.get $8)
                  (local.get $7)
                 )
                )
                (i32.or
                 (i32.load offset=4
                  (local.get $1)
                 )
                 (i32.const 1)
                )
               )
               (local.set $6
                (i32.const 0)
               )
               (local.set $1
                (i32.const 0)
               )
               (br $block18)
              )
              (i32.store
               (local.get $4)
               (i32.or
                (i32.or
                 (local.get $1)
                 (i32.and
                  (local.get $5)
                  (i32.const 1)
                 )
                )
                (i32.const 2)
               )
              )
              (i32.store offset=4
               (local.tee $1
                (i32.add
                 (local.get $8)
                 (local.get $1)
                )
               )
               (i32.or
                (local.get $6)
                (i32.const 1)
               )
              )
              (i32.store
               (local.tee $7
                (i32.add
                 (local.get $8)
                 (local.get $7)
                )
               )
               (local.get $6)
              )
              (i32.store offset=4
               (local.get $7)
               (i32.and
                (i32.load offset=4
                 (local.get $7)
                )
                (i32.const -2)
               )
              )
             )
             (i32.store offset=1051832
              (i32.const 0)
              (local.get $1)
             )
             (i32.store offset=1051824
              (i32.const 0)
              (local.get $6)
             )
             (br $block16)
            )
            (br_if $block16
             (i32.le_u
              (local.tee $6
               (i32.sub
                (local.get $6)
                (local.get $1)
               )
              )
              (i32.const 15)
             )
            )
            (i32.store
             (local.get $4)
             (i32.or
              (i32.or
               (local.get $1)
               (i32.and
                (local.get $5)
                (i32.const 1)
               )
              )
              (i32.const 2)
             )
            )
            (i32.store offset=4
             (local.tee $1
              (i32.add
               (local.get $8)
               (local.get $1)
              )
             )
             (i32.or
              (local.get $6)
              (i32.const 3)
             )
            )
            (i32.store offset=4
             (local.get $7)
             (i32.or
              (i32.load offset=4
               (local.get $7)
              )
              (i32.const 1)
             )
            )
            (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE13dispose_chunkCs4ma0AJv6Sxl_3std
             (local.get $1)
             (local.get $6)
            )
            (br $block16)
           )
           (br_if $block19
            (i32.gt_u
             (local.tee $7
              (i32.add
               (i32.load offset=1051828
                (i32.const 0)
               )
               (local.get $6)
              )
             )
             (local.get $1)
            )
           )
           (br $block14)
          )
          (call $_RNvNtCskCpoLMRBwWe_4core9panicking5panic
           (i32.const 1049015)
           (i32.const 46)
           (i32.const 1049064)
          )
          (unreachable)
         )
         (call $_RNvNtCskCpoLMRBwWe_4core9panicking5panic
          (i32.const 1049080)
          (i32.const 46)
          (i32.const 1049128)
         )
         (unreachable)
        )
        (call $_RNvNtCskCpoLMRBwWe_4core9panicking5panic
         (i32.const 1049015)
         (i32.const 46)
         (i32.const 1049064)
        )
        (unreachable)
       )
       (call $_RNvNtCskCpoLMRBwWe_4core9panicking5panic
        (i32.const 1049080)
        (i32.const 46)
        (i32.const 1049128)
       )
       (unreachable)
      )
      (i32.store
       (local.get $4)
       (i32.or
        (i32.or
         (local.get $1)
         (i32.and
          (local.get $5)
          (i32.const 1)
         )
        )
        (i32.const 2)
       )
      )
      (i32.store offset=4
       (local.tee $5
        (i32.add
         (local.get $8)
         (local.get $1)
        )
       )
       (i32.or
        (local.tee $1
         (i32.sub
          (local.get $7)
          (local.get $1)
         )
        )
        (i32.const 1)
       )
      )
      (i32.store offset=1051828
       (i32.const 0)
       (local.get $1)
      )
      (i32.store offset=1051836
       (i32.const 0)
       (local.get $5)
      )
     )
     (br_if $block14
      (i32.eqz
       (local.get $8)
      )
     )
     (return
      (local.get $0)
     )
    )
    (br_if $block9
     (i32.eqz
      (local.tee $1
       (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE6mallocCs4ma0AJv6Sxl_3std
        (local.get $3)
       )
      )
     )
    )
    (block $block20
     (br_if $block20
      (local.tee $3
       (select
        (local.tee $2
         (i32.add
          (select
           (i32.const -4)
           (i32.const -8)
           (i32.and
            (local.tee $2
             (i32.load
              (local.get $4)
             )
            )
            (i32.const 3)
           )
          )
          (i32.and
           (local.get $2)
           (i32.const -8)
          )
         )
        )
        (local.get $3)
        (i32.lt_u
         (local.get $2)
         (local.get $3)
        )
       )
      )
     )
     (local.set $2
      (local.get $1)
     )
     (br $block7)
    )
    (memory.copy
     (local.get $1)
     (local.get $0)
     (local.get $3)
    )
    (local.set $2
     (local.get $1)
    )
   )
   (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE4freeCs4ma0AJv6Sxl_3std
    (local.get $0)
   )
  )
  (local.get $2)
 )
 (func $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE12unlink_chunkCs4ma0AJv6Sxl_3std (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local.set $2
   (i32.load offset=12
    (local.get $0)
   )
  )
  (block $block8
   (block $block4
    (block $block7
     (block $block
      (br_if $block
       (i32.lt_u
        (local.get $1)
        (i32.const 256)
       )
      )
      (local.set $3
       (i32.load offset=24
        (local.get $0)
       )
      )
      (block $block3
       (block $block2
        (block $block1
         (br_if $block1
          (i32.ne
           (local.get $0)
           (local.get $2)
          )
         )
         (br_if $block2
          (local.tee $1
           (i32.load
            (i32.add
             (local.get $0)
             (select
              (i32.const 20)
              (i32.const 16)
              (local.tee $2
               (i32.load offset=20
                (local.get $0)
               )
              )
             )
            )
           )
          )
         )
         (local.set $2
          (i32.const 0)
         )
         (br $block3)
        )
        (i32.store offset=12
         (local.tee $1
          (i32.load offset=8
           (local.get $0)
          )
         )
         (local.get $2)
        )
        (i32.store offset=8
         (local.get $2)
         (local.get $1)
        )
        (br $block3)
       )
       (local.set $4
        (select
         (i32.add
          (local.get $0)
          (i32.const 20)
         )
         (i32.add
          (local.get $0)
          (i32.const 16)
         )
         (local.get $2)
        )
       )
       (loop $label
        (local.set $5
         (local.get $4)
        )
        (local.set $4
         (select
          (i32.add
           (local.tee $2
            (local.get $1)
           )
           (i32.const 20)
          )
          (i32.add
           (local.get $2)
           (i32.const 16)
          )
          (local.tee $1
           (i32.load offset=20
            (local.get $2)
           )
          )
         )
        )
        (br_if $label
         (local.tee $1
          (i32.load
           (i32.add
            (local.get $2)
            (select
             (i32.const 20)
             (i32.const 16)
             (local.get $1)
            )
           )
          )
         )
        )
       )
       (i32.store
        (local.get $5)
        (i32.const 0)
       )
      )
      (br_if $block4
       (i32.eqz
        (local.get $3)
       )
      )
      (block $block6
       (block $block5
        (br_if $block5
         (i32.eq
          (local.get $0)
          (i32.load
           (local.tee $1
            (i32.add
             (i32.shl
              (i32.load offset=28
               (local.get $0)
              )
              (i32.const 2)
             )
             (i32.const 1051408)
            )
           )
          )
         )
        )
        (br_if $block6
         (i32.eq
          (local.get $0)
          (i32.load offset=16
           (local.get $3)
          )
         )
        )
        (i32.store offset=20
         (local.get $3)
         (local.get $2)
        )
        (br_if $block7
         (local.get $2)
        )
        (br $block4)
       )
       (i32.store
        (local.get $1)
        (local.get $2)
       )
       (br_if $block8
        (i32.eqz
         (local.get $2)
        )
       )
       (br $block7)
      )
      (i32.store offset=16
       (local.get $3)
       (local.get $2)
      )
      (br_if $block7
       (local.get $2)
      )
      (br $block4)
     )
     (block $block9
      (br_if $block9
       (i32.eq
        (local.tee $4
         (i32.load offset=8
          (local.get $0)
         )
        )
        (local.get $2)
       )
      )
      (i32.store offset=12
       (local.get $4)
       (local.get $2)
      )
      (i32.store offset=8
       (local.get $2)
       (local.get $4)
      )
      (return)
     )
     (i32.store offset=1051816
      (i32.const 0)
      (i32.and
       (i32.load offset=1051816
        (i32.const 0)
       )
       (i32.rotl
        (i32.const -2)
        (i32.shr_u
         (local.get $1)
         (i32.const 3)
        )
       )
      )
     )
     (return)
    )
    (i32.store offset=24
     (local.get $2)
     (local.get $3)
    )
    (block $block10
     (br_if $block10
      (i32.eqz
       (local.tee $1
        (i32.load offset=16
         (local.get $0)
        )
       )
      )
     )
     (i32.store offset=16
      (local.get $2)
      (local.get $1)
     )
     (i32.store offset=24
      (local.get $1)
      (local.get $2)
     )
    )
    (br_if $block4
     (i32.eqz
      (local.tee $1
       (i32.load offset=20
        (local.get $0)
       )
      )
     )
    )
    (i32.store offset=20
     (local.get $2)
     (local.get $1)
    )
    (i32.store offset=24
     (local.get $1)
     (local.get $2)
    )
    (return)
   )
   (return)
  )
  (i32.store offset=1051820
   (i32.const 0)
   (i32.and
    (i32.load offset=1051820
     (i32.const 0)
    )
    (i32.rotl
     (i32.const -2)
     (i32.load offset=28
      (local.get $0)
     )
    )
   )
  )
 )
 (func $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE13dispose_chunkCs4ma0AJv6Sxl_3std (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local.set $2
   (i32.add
    (local.get $0)
    (local.get $1)
   )
  )
  (block $block5
   (block $block1
    (block $block
     (br_if $block
      (i32.and
       (local.tee $3
        (i32.load offset=4
         (local.get $0)
        )
       )
       (i32.const 1)
      )
     )
     (br_if $block1
      (i32.eqz
       (i32.and
        (local.get $3)
        (i32.const 2)
       )
      )
     )
     (local.set $1
      (i32.add
       (local.tee $3
        (i32.load
         (local.get $0)
        )
       )
       (local.get $1)
      )
     )
     (block $block2
      (br_if $block2
       (i32.ne
        (local.tee $0
         (i32.sub
          (local.get $0)
          (local.get $3)
         )
        )
        (i32.load offset=1051832
         (i32.const 0)
        )
       )
      )
      (br_if $block
       (i32.ne
        (i32.and
         (i32.load offset=4
          (local.get $2)
         )
         (i32.const 3)
        )
        (i32.const 3)
       )
      )
      (i32.store offset=1051824
       (i32.const 0)
       (local.get $1)
      )
      (i32.store offset=4
       (local.get $2)
       (i32.and
        (i32.load offset=4
         (local.get $2)
        )
        (i32.const -2)
       )
      )
      (i32.store offset=4
       (local.get $0)
       (i32.or
        (local.get $1)
        (i32.const 1)
       )
      )
      (i32.store
       (local.get $2)
       (local.get $1)
      )
      (return)
     )
     (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE12unlink_chunkCs4ma0AJv6Sxl_3std
      (local.get $0)
      (local.get $3)
     )
    )
    (block $block4
     (block $block6
      (block $block3
       (br_if $block3
        (i32.and
         (local.tee $3
          (i32.load offset=4
           (local.get $2)
          )
         )
         (i32.const 2)
        )
       )
       (br_if $block4
        (i32.eq
         (local.get $2)
         (i32.load offset=1051836
          (i32.const 0)
         )
        )
       )
       (br_if $block5
        (i32.eq
         (local.get $2)
         (i32.load offset=1051832
          (i32.const 0)
         )
        )
       )
       (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE12unlink_chunkCs4ma0AJv6Sxl_3std
        (local.get $2)
        (local.tee $3
         (i32.and
          (local.get $3)
          (i32.const -8)
         )
        )
       )
       (i32.store offset=4
        (local.get $0)
        (i32.or
         (local.tee $1
          (i32.add
           (local.get $3)
           (local.get $1)
          )
         )
         (i32.const 1)
        )
       )
       (i32.store
        (i32.add
         (local.get $0)
         (local.get $1)
        )
        (local.get $1)
       )
       (br_if $block6
        (i32.ne
         (local.get $0)
         (i32.load offset=1051832
          (i32.const 0)
         )
        )
       )
       (i32.store offset=1051824
        (i32.const 0)
        (local.get $1)
       )
       (return)
      )
      (i32.store offset=4
       (local.get $2)
       (i32.and
        (local.get $3)
        (i32.const -2)
       )
      )
      (i32.store offset=4
       (local.get $0)
       (i32.or
        (local.get $1)
        (i32.const 1)
       )
      )
      (i32.store
       (i32.add
        (local.get $0)
        (local.get $1)
       )
       (local.get $1)
      )
     )
     (block $block7
      (br_if $block7
       (i32.lt_u
        (local.get $1)
        (i32.const 256)
       )
      )
      (call $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE18insert_large_chunkCs4ma0AJv6Sxl_3std
       (local.get $0)
       (local.get $1)
      )
      (return)
     )
     (block $block9
      (block $block8
       (br_if $block8
        (i32.and
         (local.tee $2
          (i32.load offset=1051816
           (i32.const 0)
          )
         )
         (local.tee $3
          (i32.shl
           (i32.const 1)
           (i32.shr_u
            (local.get $1)
            (i32.const 3)
           )
          )
         )
        )
       )
       (i32.store offset=1051816
        (i32.const 0)
        (i32.or
         (local.get $2)
         (local.get $3)
        )
       )
       (local.set $2
        (local.tee $1
         (i32.add
          (i32.and
           (local.get $1)
           (i32.const 248)
          )
          (i32.const 1051552)
         )
        )
       )
       (br $block9)
      )
      (local.set $2
       (i32.add
        (local.tee $1
         (i32.and
          (local.get $1)
          (i32.const 248)
         )
        )
        (i32.const 1051552)
       )
      )
      (local.set $1
       (i32.load
        (i32.add
         (local.get $1)
         (i32.const 1051560)
        )
       )
      )
     )
     (i32.store offset=8
      (local.get $2)
      (local.get $0)
     )
     (i32.store offset=12
      (local.get $1)
      (local.get $0)
     )
     (i32.store offset=12
      (local.get $0)
      (local.get $2)
     )
     (i32.store offset=8
      (local.get $0)
      (local.get $1)
     )
     (return)
    )
    (i32.store offset=1051836
     (i32.const 0)
     (local.get $0)
    )
    (i32.store offset=1051828
     (i32.const 0)
     (local.tee $1
      (i32.add
       (i32.load offset=1051828
        (i32.const 0)
       )
       (local.get $1)
      )
     )
    )
    (i32.store offset=4
     (local.get $0)
     (i32.or
      (local.get $1)
      (i32.const 1)
     )
    )
    (br_if $block1
     (i32.ne
      (local.get $0)
      (i32.load offset=1051832
       (i32.const 0)
      )
     )
    )
    (i32.store offset=1051824
     (i32.const 0)
     (i32.const 0)
    )
    (i32.store offset=1051832
     (i32.const 0)
     (i32.const 0)
    )
   )
   (return)
  )
  (i32.store offset=1051832
   (i32.const 0)
   (local.get $0)
  )
  (i32.store offset=1051824
   (i32.const 0)
   (local.tee $1
    (i32.add
     (i32.load offset=1051824
      (i32.const 0)
     )
     (local.get $1)
    )
   )
  )
  (i32.store offset=4
   (local.get $0)
   (i32.or
    (local.get $1)
    (i32.const 1)
   )
  )
  (i32.store
   (i32.add
    (local.get $0)
    (local.get $1)
   )
   (local.get $1)
  )
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc17rust_begin_unwind (param $0 i32)
  (local $1 i32)
  (local $2 i64)
  (global.set $__stack_pointer
   (local.tee $1
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (local.set $2
   (i64.load align=4
    (local.get $0)
   )
  )
  (i32.store offset=12
   (local.get $1)
   (local.get $0)
  )
  (i64.store offset=4 align=4
   (local.get $1)
   (local.get $2)
  )
  (call $_RINvNtNtCs4ma0AJv6Sxl_3std3sys9backtrace26___rust_end_short_backtraceNCNvNtB6_9panicking13panic_handler0zEB6_
   (i32.add
    (local.get $1)
    (i32.const 4)
   )
  )
  (unreachable)
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc26___rust_alloc_error_handler (param $0 i32) (param $1 i32)
  (call $_RNvNtCs4ma0AJv6Sxl_3std5alloc8rust_oom
   (local.get $1)
   (local.get $0)
  )
  (unreachable)
 )
 (func $_RNvNtCs4ma0AJv6Sxl_3std5alloc8rust_oom (param $0 i32) (param $1 i32)
  (local $2 i32)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (i32.store offset=12
   (local.get $2)
   (local.get $1)
  )
  (i32.store offset=8
   (local.get $2)
   (local.get $0)
  )
  (call $_RINvNtNtCs4ma0AJv6Sxl_3std3sys9backtrace26___rust_end_short_backtraceNCNvNtB6_5alloc8rust_oom0zEB6_
   (i32.add
    (local.get $2)
    (i32.const 8)
   )
  )
  (unreachable)
 )
 (func $_RNvMs0_NtCs9CYeDBX2pGb_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE18insert_large_chunkCs4ma0AJv6Sxl_3std (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local.set $2
   (i32.const 0)
  )
  (block $block
   (br_if $block
    (i32.eqz
     (local.tee $3
      (i32.shr_u
       (local.get $1)
       (i32.const 8)
      )
     )
    )
   )
   (local.set $2
    (i32.const 31)
   )
   (br_if $block
    (i32.ge_u
     (local.get $1)
     (i32.const 16777216)
    )
   )
   (local.set $2
    (i32.xor
     (i32.or
      (i32.and
       (i32.shr_u
        (local.get $1)
        (i32.sub
         (i32.const 38)
         (local.tee $2
          (i32.clz
           (local.get $3)
          )
         )
        )
       )
       (i32.const 1)
      )
      (i32.shl
       (local.get $2)
       (i32.const 1)
      )
     )
     (i32.const 62)
    )
   )
  )
  (i64.store offset=16 align=4
   (local.get $0)
   (i64.const 0)
  )
  (i32.store offset=28
   (local.get $0)
   (local.get $2)
  )
  (local.set $3
   (i32.add
    (i32.shl
     (local.get $2)
     (i32.const 2)
    )
    (i32.const 1051408)
   )
  )
  (block $block1
   (br_if $block1
    (i32.and
     (i32.load offset=1051820
      (i32.const 0)
     )
     (local.tee $4
      (i32.shl
       (i32.const 1)
       (local.get $2)
      )
     )
    )
   )
   (i32.store
    (local.get $3)
    (local.get $0)
   )
   (i32.store offset=24
    (local.get $0)
    (local.get $3)
   )
   (i32.store offset=12
    (local.get $0)
    (local.get $0)
   )
   (i32.store offset=8
    (local.get $0)
    (local.get $0)
   )
   (i32.store offset=1051820
    (i32.const 0)
    (i32.or
     (i32.load offset=1051820
      (i32.const 0)
     )
     (local.get $4)
    )
   )
   (return)
  )
  (block $block4
   (block $block3
    (block $block2
     (br_if $block2
      (i32.ne
       (local.get $1)
       (i32.and
        (i32.load offset=4
         (local.tee $4
          (i32.load
           (local.get $3)
          )
         )
        )
        (i32.const -8)
       )
      )
     )
     (local.set $2
      (local.get $4)
     )
     (br $block3)
    )
    (local.set $3
     (i32.shl
      (local.get $1)
      (select
       (i32.const 0)
       (i32.sub
        (i32.const 25)
        (i32.shr_u
         (local.get $2)
         (i32.const 1)
        )
       )
       (i32.eq
        (local.get $2)
        (i32.const 31)
       )
      )
     )
    )
    (loop $label
     (br_if $block4
      (i32.eqz
       (local.tee $2
        (i32.load offset=16
         (local.tee $5
          (i32.add
           (local.get $4)
           (i32.and
            (i32.shr_u
             (local.get $3)
             (i32.const 29)
            )
            (i32.const 4)
           )
          )
         )
        )
       )
      )
     )
     (local.set $3
      (i32.shl
       (local.get $3)
       (i32.const 1)
      )
     )
     (local.set $4
      (local.get $2)
     )
     (br_if $label
      (i32.ne
       (local.get $1)
       (i32.and
        (i32.load offset=4
         (local.get $2)
        )
        (i32.const -8)
       )
      )
     )
    )
   )
   (i32.store offset=12
    (local.tee $3
     (i32.load offset=8
      (local.get $2)
     )
    )
    (local.get $0)
   )
   (i32.store offset=8
    (local.get $2)
    (local.get $0)
   )
   (i32.store offset=24
    (local.get $0)
    (i32.const 0)
   )
   (i32.store offset=12
    (local.get $0)
    (local.get $2)
   )
   (i32.store offset=8
    (local.get $0)
    (local.get $3)
   )
   (return)
  )
  (i32.store
   (i32.add
    (local.get $5)
    (i32.const 16)
   )
   (local.get $0)
  )
  (i32.store offset=24
   (local.get $0)
   (local.get $4)
  )
  (i32.store offset=12
   (local.get $0)
   (local.get $0)
  )
  (i32.store offset=8
   (local.get $0)
   (local.get $0)
  )
 )
 (func $_RNvNtNtCs4ma0AJv6Sxl_3std9panicking11panic_count8increase (param $0 i32) (result i32)
  (local $1 i32)
  (local $2 i32)
  (local.set $1
   (i32.const 0)
  )
  (i32.store offset=1051892
   (i32.const 0)
   (i32.add
    (local.tee $2
     (i32.load offset=1051892
      (i32.const 0)
     )
    )
    (i32.const 1)
   )
  )
  (block $block
   (br_if $block
    (i32.lt_s
     (local.get $2)
     (i32.const 0)
    )
   )
   (local.set $1
    (i32.const 1)
   )
   (br_if $block
    (i32.load8_u offset=1051872
     (i32.const 0)
    )
   )
   (i32.store8 offset=1051872
    (i32.const 0)
    (local.get $0)
   )
   (i32.store offset=1051868
    (i32.const 0)
    (i32.add
     (i32.load offset=1051868
      (i32.const 0)
     )
     (i32.const 1)
    )
   )
   (local.set $1
    (i32.const 2)
   )
  )
  (local.get $1)
 )
 (func $_RNvXNtCskCpoLMRBwWe_4core3anyNtNtCs1eLRiQ1QTaf_5alloc6string6StringNtB2_3Any7type_idCs4ma0AJv6Sxl_3std (param $0 i32) (param $1 i32)
  (i64.store offset=8 align=4
   (local.get $0)
   (i64.load offset=1048720 align=4
    (i32.const 0)
   )
  )
  (i64.store align=4
   (local.get $0)
   (i64.load offset=1048712 align=4
    (i32.const 0)
   )
  )
 )
 (func $_RNvXNtCskCpoLMRBwWe_4core3anyReNtB2_3Any7type_idCs4ma0AJv6Sxl_3std (param $0 i32) (param $1 i32)
  (i64.store offset=8 align=4
   (local.get $0)
   (i64.load offset=1048704 align=4
    (i32.const 0)
   )
  )
  (i64.store align=4
   (local.get $0)
   (i64.load offset=1048696 align=4
    (i32.const 0)
   )
  )
 )
 (func $_RNvXs0_NvNtCs4ma0AJv6Sxl_3std9panicking13panic_handlerNtB5_19FormatStringPayloadNtNtCskCpoLMRBwWe_4core3fmt7Display3fmt (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (block $block
   (br_if $block
    (i32.eq
     (i32.load
      (local.get $0)
     )
     (i32.const -1)
    )
   )
   (return
    (call $_RNvMsa_NtCskCpoLMRBwWe_4core3fmtNtB5_9Formatter9write_str
     (local.get $1)
     (i32.load offset=4
      (local.get $0)
     )
     (i32.load offset=8
      (local.get $0)
     )
    )
   )
  )
  (local.set $2
   (i32.load offset=4
    (local.get $1)
   )
  )
  (local.set $1
   (i32.load
    (local.get $1)
   )
  )
  (local.set $3
   (i32.load
    (local.tee $0
     (i32.load
      (i32.load offset=12
       (local.get $0)
      )
     )
    )
   )
  )
  (block $block1
   (br_if $block1
    (i32.eqz
     (i32.and
      (local.tee $0
       (i32.load offset=4
        (local.get $0)
       )
      )
      (i32.const 1)
     )
    )
   )
   (return
    (call_indirect $0 (type $3)
     (local.get $1)
     (local.get $3)
     (i32.shr_u
      (local.get $0)
      (i32.const 1)
     )
     (i32.load offset=12
      (local.get $2)
     )
    )
   )
  )
  (call $_RNvNtCskCpoLMRBwWe_4core3fmt5write
   (local.get $1)
   (local.get $2)
   (local.get $3)
   (local.get $0)
  )
 )
 (func $_RNvXs15_NtCs1eLRiQ1QTaf_5alloc6stringNtB6_6StringNtNtCskCpoLMRBwWe_4core3fmt5Write10write_char (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local.set $2
   (i32.load offset=8
    (local.get $0)
   )
  )
  (block $block1
   (block $block
    (br_if $block
     (i32.ge_u
      (local.get $1)
      (i32.const 128)
     )
    )
    (local.set $3
     (i32.const 1)
    )
    (br $block1)
   )
   (block $block2
    (br_if $block2
     (i32.ge_u
      (local.get $1)
      (i32.const 2048)
     )
    )
    (local.set $3
     (i32.const 2)
    )
    (br $block1)
   )
   (local.set $3
    (select
     (i32.const 3)
     (i32.const 4)
     (i32.lt_u
      (local.get $1)
      (i32.const 65536)
     )
    )
   )
  )
  (block $block3
   (br_if $block3
    (i32.le_u
     (local.get $3)
     (i32.sub
      (i32.load
       (local.get $0)
      )
      (local.get $2)
     )
    )
   )
   (call $_RINvNvMs5_NtCs1eLRiQ1QTaf_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs4ma0AJv6Sxl_3std
    (local.get $0)
    (local.get $2)
    (local.get $3)
    (i32.const 1)
    (i32.const 1)
   )
  )
  (local.set $4
   (i32.add
    (i32.load offset=4
     (local.get $0)
    )
    (local.get $2)
   )
  )
  (block $block6
   (block $block4
    (br_if $block4
     (i32.lt_u
      (local.get $1)
      (i32.const 128)
     )
    )
    (local.set $5
     (i32.or
      (i32.and
       (local.get $1)
       (i32.const 63)
      )
      (i32.const -128)
     )
    )
    (local.set $6
     (i32.shr_u
      (local.get $1)
      (i32.const 6)
     )
    )
    (block $block5
     (br_if $block5
      (i32.ge_u
       (local.get $1)
       (i32.const 2048)
      )
     )
     (i32.store8 offset=1
      (local.get $4)
      (local.get $5)
     )
     (i32.store8
      (local.get $4)
      (i32.or
       (local.get $6)
       (i32.const 192)
      )
     )
     (br $block6)
    )
    (local.set $7
     (i32.shr_u
      (local.get $1)
      (i32.const 12)
     )
    )
    (local.set $6
     (i32.or
      (i32.and
       (local.get $6)
       (i32.const 63)
      )
      (i32.const -128)
     )
    )
    (block $block7
     (br_if $block7
      (i32.gt_u
       (local.get $1)
       (i32.const 65535)
      )
     )
     (i32.store8 offset=2
      (local.get $4)
      (local.get $5)
     )
     (i32.store8 offset=1
      (local.get $4)
      (local.get $6)
     )
     (i32.store8
      (local.get $4)
      (i32.or
       (local.get $7)
       (i32.const 224)
      )
     )
     (br $block6)
    )
    (i32.store8 offset=3
     (local.get $4)
     (local.get $5)
    )
    (i32.store8 offset=2
     (local.get $4)
     (local.get $6)
    )
    (i32.store8 offset=1
     (local.get $4)
     (i32.or
      (i32.and
       (local.get $7)
       (i32.const 63)
      )
      (i32.const -128)
     )
    )
    (i32.store8
     (local.get $4)
     (i32.or
      (i32.shr_u
       (local.get $1)
       (i32.const 18)
      )
      (i32.const -16)
     )
    )
    (br $block6)
   )
   (i32.store8
    (local.get $4)
    (local.get $1)
   )
  )
  (i32.store offset=8
   (local.get $0)
   (i32.add
    (local.get $3)
    (local.get $2)
   )
  )
  (i32.const 0)
 )
 (func $_RNvXs15_NtCs1eLRiQ1QTaf_5alloc6stringNtB6_6StringNtNtCskCpoLMRBwWe_4core3fmt5Write9write_str (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (local $3 i32)
  (block $block2
   (block $block1
    (block $block
     (br_if $block
      (i32.le_u
       (local.get $2)
       (i32.sub
        (i32.load
         (local.get $0)
        )
        (local.tee $3
         (i32.load offset=8
          (local.get $0)
         )
        )
       )
      )
     )
     (call $_RINvNvMs5_NtCs1eLRiQ1QTaf_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs4ma0AJv6Sxl_3std
      (local.get $0)
      (local.get $3)
      (local.get $2)
      (i32.const 1)
      (i32.const 1)
     )
     (local.set $3
      (i32.load offset=8
       (local.get $0)
      )
     )
     (br $block1)
    )
    (br_if $block2
     (i32.eqz
      (local.get $2)
     )
    )
   )
   (br_if $block2
    (i32.eqz
     (local.get $2)
    )
   )
   (memory.copy
    (i32.add
     (i32.load offset=4
      (local.get $0)
     )
     (local.get $3)
    )
    (local.get $1)
    (local.get $2)
   )
  )
  (i32.store offset=8
   (local.get $0)
   (i32.add
    (local.get $3)
    (local.get $2)
   )
  )
  (i32.const 0)
 )
 (func $_RNvXs1_NvNtCs4ma0AJv6Sxl_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCs1eLRiQ1QTaf_5alloc9panicking12PanicPayload3get (param $0 i32) (param $1 i32)
  (i32.store offset=4
   (local.get $0)
   (i32.const 1049204)
  )
  (i32.store
   (local.get $0)
   (local.get $1)
  )
 )
 (func $_RNvXs1_NvNtCs4ma0AJv6Sxl_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCs1eLRiQ1QTaf_5alloc9panicking12PanicPayload6as_str (param $0 i32) (param $1 i32)
  (i64.store
   (local.get $0)
   (i64.load align=4
    (local.get $1)
   )
  )
 )
 (func $_RNvXs1_NvNtCs4ma0AJv6Sxl_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCs1eLRiQ1QTaf_5alloc9panicking12PanicPayload8take_box (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local.set $2
   (i32.load offset=4
    (local.get $1)
   )
  )
  (local.set $3
   (i32.load
    (local.get $1)
   )
  )
  (call $_RNvCs9VHGBS8Gq78_7___rustc35___rust_no_alloc_shim_is_unstable_v2)
  (block $block
   (br_if $block
    (local.tee $1
     (call $_RNvCs9VHGBS8Gq78_7___rustc12___rust_alloc
      (i32.const 8)
      (i32.const 4)
     )
    )
   )
   (call $_RNvNtCs1eLRiQ1QTaf_5alloc5alloc18handle_alloc_error
    (i32.const 4)
    (i32.const 8)
   )
   (unreachable)
  )
  (i32.store offset=4
   (local.get $1)
   (local.get $2)
  )
  (i32.store
   (local.get $1)
   (local.get $3)
  )
  (i32.store offset=4
   (local.get $0)
   (i32.const 1049204)
  )
  (i32.store
   (local.get $0)
   (local.get $1)
  )
 )
 (func $_RNvXs2_NvNtCs4ma0AJv6Sxl_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCskCpoLMRBwWe_4core3fmt7Display3fmt (param $0 i32) (param $1 i32) (result i32)
  (call $_RNvMsa_NtCskCpoLMRBwWe_4core3fmtNtB5_9Formatter9write_str
   (local.get $1)
   (i32.load
    (local.get $0)
   )
   (i32.load offset=4
    (local.get $0)
   )
  )
 )
 (func $_RNvXs_NvNtCs4ma0AJv6Sxl_3std9panicking13panic_handlerNtB4_19FormatStringPayloadNtNtCs1eLRiQ1QTaf_5alloc9panicking12PanicPayload3get (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i64)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (block $block
   (br_if $block
    (i32.ne
     (i32.load
      (local.get $1)
     )
     (i32.const -1)
    )
   )
   (local.set $3
    (i32.load offset=12
     (local.get $1)
    )
   )
   (local.set $4
    (i32.const 0)
   )
   (i32.store offset=28
    (local.get $2)
    (i32.const 0)
   )
   (i64.store offset=20 align=4
    (local.get $2)
    (i64.const 4294967296)
   )
   (local.set $5
    (i32.load
     (local.tee $3
      (i32.load
       (local.get $3)
      )
     )
    )
   )
   (block $block3
    (block $block1
     (br_if $block1
      (i32.eqz
       (i32.and
        (local.tee $3
         (i32.load offset=4
          (local.get $3)
         )
        )
        (i32.const 1)
       )
      )
     )
     (block $block2
      (br_if $block2
       (i32.eqz
        (local.tee $3
         (i32.shr_u
          (local.get $3)
          (i32.const 1)
         )
        )
       )
      )
      (call $_RINvNvMs5_NtCs1eLRiQ1QTaf_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs4ma0AJv6Sxl_3std
       (i32.add
        (local.get $2)
        (i32.const 20)
       )
       (i32.const 0)
       (local.get $3)
       (i32.const 1)
       (i32.const 1)
      )
      (local.set $4
       (i32.load offset=28
        (local.get $2)
       )
      )
      (br_if $block2
       (i32.eqz
        (local.get $3)
       )
      )
      (memory.copy
       (i32.add
        (i32.load offset=24
         (local.get $2)
        )
        (local.get $4)
       )
       (local.get $5)
       (local.get $3)
      )
     )
     (i32.store offset=28
      (local.get $2)
      (i32.add
       (local.get $4)
       (local.get $3)
      )
     )
     (br $block3)
    )
    (drop
     (call $_RNvNtCskCpoLMRBwWe_4core3fmt5write
      (i32.add
       (local.get $2)
       (i32.const 20)
      )
      (i32.const 1048728)
      (local.get $5)
      (local.get $3)
     )
    )
   )
   (i32.store offset=16
    (local.get $2)
    (local.tee $3
     (i32.load offset=28
      (local.get $2)
     )
    )
   )
   (i64.store offset=8
    (local.get $2)
    (local.tee $6
     (i64.load offset=20 align=4
      (local.get $2)
     )
    )
   )
   (i32.store offset=8
    (local.get $1)
    (local.get $3)
   )
   (i64.store align=4
    (local.get $1)
    (local.get $6)
   )
  )
  (i32.store offset=4
   (local.get $0)
   (i32.const 1049220)
  )
  (i32.store
   (local.get $0)
   (local.get $1)
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 32)
   )
  )
 )
 (func $_RNvXs_NvNtCs4ma0AJv6Sxl_3std9panicking13panic_handlerNtB4_19FormatStringPayloadNtNtCs1eLRiQ1QTaf_5alloc9panicking12PanicPayload8take_box (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i64)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (block $block
   (br_if $block
    (i32.ne
     (i32.load
      (local.get $1)
     )
     (i32.const -1)
    )
   )
   (local.set $3
    (i32.load offset=12
     (local.get $1)
    )
   )
   (local.set $4
    (i32.const 0)
   )
   (i32.store offset=24
    (local.get $2)
    (i32.const 0)
   )
   (i64.store offset=16 align=4
    (local.get $2)
    (i64.const 4294967296)
   )
   (local.set $5
    (i32.load
     (local.tee $3
      (i32.load
       (local.get $3)
      )
     )
    )
   )
   (block $block3
    (block $block1
     (br_if $block1
      (i32.eqz
       (i32.and
        (local.tee $3
         (i32.load offset=4
          (local.get $3)
         )
        )
        (i32.const 1)
       )
      )
     )
     (block $block2
      (br_if $block2
       (i32.eqz
        (local.tee $3
         (i32.shr_u
          (local.get $3)
          (i32.const 1)
         )
        )
       )
      )
      (call $_RINvNvMs5_NtCs1eLRiQ1QTaf_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs4ma0AJv6Sxl_3std
       (i32.add
        (local.get $2)
        (i32.const 16)
       )
       (i32.const 0)
       (local.get $3)
       (i32.const 1)
       (i32.const 1)
      )
      (local.set $4
       (i32.load offset=24
        (local.get $2)
       )
      )
      (br_if $block2
       (i32.eqz
        (local.get $3)
       )
      )
      (memory.copy
       (i32.add
        (i32.load offset=20
         (local.get $2)
        )
        (local.get $4)
       )
       (local.get $5)
       (local.get $3)
      )
     )
     (i32.store offset=24
      (local.get $2)
      (i32.add
       (local.get $4)
       (local.get $3)
      )
     )
     (br $block3)
    )
    (drop
     (call $_RNvNtCskCpoLMRBwWe_4core3fmt5write
      (i32.add
       (local.get $2)
       (i32.const 16)
      )
      (i32.const 1048728)
      (local.get $5)
      (local.get $3)
     )
    )
   )
   (i32.store offset=8
    (local.get $2)
    (local.tee $3
     (i32.load offset=24
      (local.get $2)
     )
    )
   )
   (i64.store
    (local.get $2)
    (local.tee $6
     (i64.load offset=16 align=4
      (local.get $2)
     )
    )
   )
   (i32.store offset=8
    (local.get $1)
    (local.get $3)
   )
   (i64.store align=4
    (local.get $1)
    (local.get $6)
   )
  )
  (local.set $3
   (i32.load offset=8
    (local.get $1)
   )
  )
  (i32.store offset=8
   (local.get $1)
   (i32.const 0)
  )
  (local.set $6
   (i64.load align=4
    (local.get $1)
   )
  )
  (i64.store align=4
   (local.get $1)
   (i64.const 4294967296)
  )
  (i32.store offset=24
   (local.get $2)
   (local.get $3)
  )
  (i64.store offset=16
   (local.get $2)
   (local.get $6)
  )
  (call $_RNvCs9VHGBS8Gq78_7___rustc35___rust_no_alloc_shim_is_unstable_v2)
  (block $block4
   (br_if $block4
    (local.tee $1
     (call $_RNvCs9VHGBS8Gq78_7___rustc12___rust_alloc
      (i32.const 12)
      (i32.const 4)
     )
    )
   )
   (call $_RNvNtCs1eLRiQ1QTaf_5alloc5alloc18handle_alloc_error
    (i32.const 4)
    (i32.const 12)
   )
   (unreachable)
  )
  (i32.store offset=8
   (local.get $1)
   (i32.load offset=24
    (local.get $2)
   )
  )
  (i64.store align=4
   (local.get $1)
   (i64.load offset=16
    (local.get $2)
   )
  )
  (i32.store offset=4
   (local.get $0)
   (i32.const 1049220)
  )
  (i32.store
   (local.get $0)
   (local.get $1)
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 32)
   )
  )
 )
 (func $_RNvYINtNvNtCs4ma0AJv6Sxl_3std9panicking11begin_panic7PayloadReENtNtCs1eLRiQ1QTaf_5alloc9panicking12PanicPayload6as_strB9_ (param $0 i32) (param $1 i32)
  (i32.store
   (local.get $0)
   (i32.const 0)
  )
 )
 (func $_RNvYNtNtCs1eLRiQ1QTaf_5alloc6string6StringNtNtCskCpoLMRBwWe_4core3fmt5Write9write_fmtCs4ma0AJv6Sxl_3std (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (local $3 i32)
  (block $block
   (br_if $block
    (i32.eqz
     (i32.and
      (local.get $2)
      (i32.const 1)
     )
    )
   )
   (block $block3
    (block $block2
     (block $block1
      (br_if $block1
       (i32.le_u
        (local.tee $2
         (i32.shr_u
          (local.get $2)
          (i32.const 1)
         )
        )
        (i32.sub
         (i32.load
          (local.get $0)
         )
         (local.tee $3
          (i32.load offset=8
           (local.get $0)
          )
         )
        )
       )
      )
      (call $_RINvNvMs5_NtCs1eLRiQ1QTaf_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs4ma0AJv6Sxl_3std
       (local.get $0)
       (local.get $3)
       (local.get $2)
       (i32.const 1)
       (i32.const 1)
      )
      (local.set $3
       (i32.load offset=8
        (local.get $0)
       )
      )
      (br $block2)
     )
     (br_if $block3
      (i32.eqz
       (local.get $2)
      )
     )
    )
    (br_if $block3
     (i32.eqz
      (local.get $2)
     )
    )
    (memory.copy
     (i32.add
      (i32.load offset=4
       (local.get $0)
      )
      (local.get $3)
     )
     (local.get $1)
     (local.get $2)
    )
   )
   (i32.store offset=8
    (local.get $0)
    (i32.add
     (local.get $3)
     (local.get $2)
    )
   )
   (return
    (i32.const 0)
   )
  )
  (call $_RNvNtCskCpoLMRBwWe_4core3fmt5write
   (local.get $0)
   (i32.const 1048728)
   (local.get $1)
   (local.get $2)
  )
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc18___rust_start_panic (param $0 i32) (param $1 i32) (result i32)
  (call $_RNvCs9VHGBS8Gq78_7___rustc12___rust_abort)
  (unreachable)
 )
 (func $_RNvXs_NtCs9CYeDBX2pGb_8dlmalloc3sysNtB4_6SystemNtB6_9Allocator5alloc (param $0 i32) (param $1 i32) (param $2 i32)
  (local $3 i32)
  (local $4 i32)
  (block $block1
   (block $block
    (br_if $block
     (i32.eqz
      (local.get $2)
     )
    )
    (local.set $3
     (i32.load8_u offset=1051897
      (i32.const 0)
     )
    )
    (i32.store8 offset=1051897
     (i32.const 0)
     (i32.const 1)
    )
    (local.set $4
     (i32.const 1051904)
    )
    (br_if $block
     (i32.le_u
      (i32.const 1114112)
      (i32.const 1051904)
     )
    )
    (br_if $block
     (i32.gt_u
      (local.get $2)
      (i32.sub
       (i32.const 1114112)
       (i32.const 1051904)
      )
     )
    )
    (br_if $block
     (i32.and
      (local.get $3)
      (i32.const 255)
     )
    )
    (local.set $2
     (i32.sub
      (i32.const 1114112)
      (i32.const 1051904)
     )
    )
    (br $block1)
   )
   (local.set $4
    (i32.const 0)
   )
   (block $block2
    (br_if $block2
     (i32.ne
      (local.tee $3
       (memory.grow
        (local.tee $2
         (i32.add
          (i32.shr_u
           (local.get $2)
           (i32.const 16)
          )
          (i32.ne
           (i32.and
            (local.get $2)
            (i32.const 65535)
           )
           (i32.const 0)
          )
         )
        )
       )
      )
      (i32.const -1)
     )
    )
    (local.set $2
     (i32.const 0)
    )
    (br $block1)
   )
   (local.set $2
    (select
     (i32.add
      (local.tee $2
       (i32.shl
        (local.get $2)
        (i32.const 16)
       )
      )
      (i32.const -16)
     )
     (local.get $2)
     (i32.eq
      (local.tee $4
       (i32.shl
        (local.get $3)
        (i32.const 16)
       )
      )
      (i32.sub
       (i32.const 0)
       (local.get $2)
      )
     )
    )
   )
  )
  (i32.store offset=8
   (local.get $0)
   (i32.const 0)
  )
  (i32.store offset=4
   (local.get $0)
   (local.get $2)
  )
  (i32.store
   (local.get $0)
   (local.get $4)
  )
 )
 (func $_RNvNtCs1eLRiQ1QTaf_5alloc7raw_vec12handle_error (param $0 i32) (param $1 i32)
  (block $block
   (br_if $block
    (i32.eqz
     (local.get $0)
    )
   )
   (call $_RNvNtCs1eLRiQ1QTaf_5alloc5alloc18handle_alloc_error
    (local.get $0)
    (local.get $1)
   )
   (unreachable)
  )
  (call $_RNvNtCs1eLRiQ1QTaf_5alloc7raw_vec17capacity_overflow)
  (unreachable)
 )
 (func $_RNvNtCs1eLRiQ1QTaf_5alloc5alloc18handle_alloc_error (param $0 i32) (param $1 i32)
  (call $_RNvCs9VHGBS8Gq78_7___rustc26___rust_alloc_error_handler
   (local.get $1)
   (local.get $0)
  )
  (unreachable)
 )
 (func $_RNvNtCs1eLRiQ1QTaf_5alloc7raw_vec17capacity_overflow
  (call $_RNvNtCskCpoLMRBwWe_4core9panicking9panic_fmt
   (i32.const 1049292)
   (i32.const 35)
   (i32.const 1049312)
  )
  (unreachable)
 )
 (func $_RNvNtCskCpoLMRBwWe_4core9panicking5panic (param $0 i32) (param $1 i32) (param $2 i32)
  (call $_RNvNtCskCpoLMRBwWe_4core9panicking9panic_fmt
   (local.get $0)
   (i32.or
    (i32.shl
     (local.get $1)
     (i32.const 1)
    )
    (i32.const 1)
   )
   (local.get $2)
  )
  (unreachable)
 )
 (func $_RNvXs1i_NtCskCpoLMRBwWe_4core3fmtReNtB6_7Display3fmtB8_ (param $0 i32) (param $1 i32) (result i32)
  (call $_RNvMsa_NtCskCpoLMRBwWe_4core3fmtNtB5_9Formatter3pad
   (local.get $1)
   (i32.load
    (local.get $0)
   )
   (i32.load offset=4
    (local.get $0)
   )
  )
 )
 (func $_RNvNtCskCpoLMRBwWe_4core3fmt5write (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (result i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (global.set $__stack_pointer
   (local.tee $4
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (block $block2
   (block $block1
    (block $block
     (br_if $block
      (i32.and
       (local.get $3)
       (i32.const 1)
      )
     )
     (br_if $block1
      (local.tee $5
       (i32.load8_u
        (local.get $2)
       )
      )
     )
     (local.set $5
      (i32.const 0)
     )
     (br $block2)
    )
    (local.set $5
     (call_indirect $0 (type $3)
      (local.get $0)
      (local.get $2)
      (i32.shr_u
       (local.get $3)
       (i32.const 1)
      )
      (i32.load offset=12
       (local.get $1)
      )
     )
    )
    (br $block2)
   )
   (local.set $6
    (i32.load offset=12
     (local.get $1)
    )
   )
   (local.set $7
    (i32.const 0)
   )
   (loop $label
    (local.set $8
     (i32.add
      (local.get $2)
      (i32.const 1)
     )
    )
    (block $block8
     (block $block5
      (block $block6
       (block $block4
        (block $block3
         (br_if $block3
          (i32.gt_s
           (i32.extend8_s
            (local.get $5)
           )
           (i32.const -1)
          )
         )
         (br_if $block4
          (i32.eq
           (local.tee $9
            (i32.and
             (local.get $5)
             (i32.const 255)
            )
           )
           (i32.const 128)
          )
         )
         (br_if $block5
          (i32.ne
           (local.get $9)
           (i32.const 192)
          )
         )
         (i32.store offset=4
          (local.get $4)
          (local.get $1)
         )
         (i32.store
          (local.get $4)
          (local.get $0)
         )
         (i64.store offset=8 align=4
          (local.get $4)
          (i64.const 1610612768)
         )
         (br_if $block6
          (i32.eqz
           (call_indirect $0 (type $2)
            (i32.load
             (local.tee $5
              (i32.add
               (local.get $3)
               (i32.shl
                (local.get $7)
                (i32.const 3)
               )
              )
             )
            )
            (local.get $4)
            (i32.load offset=4
             (local.get $5)
            )
           )
          )
         )
         (local.set $5
          (i32.const 1)
         )
         (br $block2)
        )
        (block $block7
         (br_if $block7
          (call_indirect $0 (type $3)
           (local.get $0)
           (local.get $8)
           (local.tee $5
            (i32.and
             (local.get $5)
             (i32.const 255)
            )
           )
           (local.get $6)
          )
         )
         (local.set $2
          (i32.add
           (local.get $8)
           (local.get $5)
          )
         )
         (br $block8)
        )
        (local.set $5
         (i32.const 1)
        )
        (br $block2)
       )
       (block $block9
        (br_if $block9
         (call_indirect $0 (type $3)
          (local.get $0)
          (local.tee $5
           (i32.add
            (local.get $2)
            (i32.const 3)
           )
          )
          (local.tee $2
           (i32.load16_u offset=1 align=1
            (local.get $2)
           )
          )
          (local.get $6)
         )
        )
        (local.set $2
         (i32.add
          (local.get $5)
          (local.get $2)
         )
        )
        (br $block8)
       )
       (local.set $5
        (i32.const 1)
       )
       (br $block2)
      )
      (local.set $7
       (i32.add
        (local.get $7)
        (i32.const 1)
       )
      )
      (local.set $2
       (local.get $8)
      )
      (br $block8)
     )
     (local.set $10
      (i32.const 1610612768)
     )
     (block $block10
      (br_if $block10
       (i32.eqz
        (i32.and
         (local.get $5)
         (i32.const 1)
        )
       )
      )
      (local.set $8
       (i32.add
        (local.get $2)
        (i32.const 5)
       )
      )
      (local.set $10
       (i32.load offset=1 align=1
        (local.get $2)
       )
      )
     )
     (local.set $9
      (i32.const 0)
     )
     (block $block12
      (block $block11
       (br_if $block11
        (i32.and
         (local.get $5)
         (i32.const 2)
        )
       )
       (local.set $11
        (i32.const 0)
       )
       (local.set $2
        (local.get $8)
       )
       (br $block12)
      )
      (local.set $2
       (i32.add
        (local.get $8)
        (i32.const 2)
       )
      )
      (local.set $11
       (i32.load16_u align=1
        (local.get $8)
       )
      )
     )
     (block $block14
      (block $block13
       (br_if $block13
        (i32.and
         (local.get $5)
         (i32.const 4)
        )
       )
       (local.set $8
        (local.get $2)
       )
       (br $block14)
      )
      (local.set $8
       (i32.add
        (local.get $2)
        (i32.const 2)
       )
      )
      (local.set $9
       (i32.load16_u align=1
        (local.get $2)
       )
      )
     )
     (block $block16
      (block $block15
       (br_if $block15
        (i32.and
         (local.get $5)
         (i32.const 8)
        )
       )
       (local.set $2
        (local.get $8)
       )
       (br $block16)
      )
      (local.set $2
       (i32.add
        (local.get $8)
        (i32.const 2)
       )
      )
      (local.set $7
       (i32.load16_u align=1
        (local.get $8)
       )
      )
     )
     (block $block17
      (br_if $block17
       (i32.eqz
        (i32.and
         (local.get $5)
         (i32.const 16)
        )
       )
      )
      (local.set $11
       (i32.load16_u offset=4
        (i32.add
         (local.get $3)
         (i32.shl
          (i32.and
           (local.get $11)
           (i32.const 65535)
          )
          (i32.const 3)
         )
        )
       )
      )
     )
     (block $block18
      (br_if $block18
       (i32.eqz
        (i32.and
         (local.get $5)
         (i32.const 32)
        )
       )
      )
      (local.set $9
       (i32.load16_u offset=4
        (i32.add
         (local.get $3)
         (i32.shl
          (i32.and
           (local.get $9)
           (i32.const 65535)
          )
          (i32.const 3)
         )
        )
       )
      )
     )
     (i32.store16 offset=14
      (local.get $4)
      (local.get $9)
     )
     (i32.store16 offset=12
      (local.get $4)
      (local.get $11)
     )
     (i32.store offset=8
      (local.get $4)
      (local.get $10)
     )
     (i32.store offset=4
      (local.get $4)
      (local.get $1)
     )
     (i32.store
      (local.get $4)
      (local.get $0)
     )
     (block $block19
      (br_if $block19
       (i32.eqz
        (call_indirect $0 (type $2)
         (i32.load
          (local.tee $5
           (i32.add
            (local.get $3)
            (i32.shl
             (local.get $7)
             (i32.const 3)
            )
           )
          )
         )
         (local.get $4)
         (i32.load offset=4
          (local.get $5)
         )
        )
       )
      )
      (local.set $5
       (i32.const 1)
      )
      (br $block2)
     )
     (local.set $7
      (i32.add
       (local.get $7)
       (i32.const 1)
      )
     )
    )
    (br_if $label
     (local.tee $5
      (i32.load8_u
       (local.get $2)
      )
     )
    )
   )
   (local.set $5
    (i32.const 0)
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $4)
    (i32.const 16)
   )
  )
  (local.get $5)
 )
 (func $_RNvNtCskCpoLMRBwWe_4core9panicking9panic_fmt (param $0 i32) (param $1 i32) (param $2 i32)
  (local $3 i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (i32.store offset=16
   (local.get $3)
   (local.get $1)
  )
  (i32.store offset=12
   (local.get $3)
   (local.get $0)
  )
  (i32.store16 offset=28
   (local.get $3)
   (i32.const 1)
  )
  (i32.store offset=24
   (local.get $3)
   (local.get $2)
  )
  (i32.store offset=20
   (local.get $3)
   (i32.add
    (local.get $3)
    (i32.const 12)
   )
  )
  (call $_RNvCs9VHGBS8Gq78_7___rustc17rust_begin_unwind
   (i32.add
    (local.get $3)
    (i32.const 20)
   )
  )
  (unreachable)
 )
 (func $_RNvNtNtCskCpoLMRBwWe_4core3str5count14do_count_chars (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (block $block4
   (block $block
    (br_if $block
     (i32.lt_u
      (local.get $1)
      (local.tee $3
       (i32.sub
        (local.tee $2
         (i32.and
          (i32.add
           (local.get $0)
           (i32.const 3)
          )
          (i32.const -4)
         )
        )
        (local.get $0)
       )
      )
     )
    )
    (br_if $block
     (i32.eqz
      (local.tee $5
       (i32.shr_u
        (local.tee $4
         (i32.sub
          (local.get $1)
          (local.get $3)
         )
        )
        (i32.const 2)
       )
      )
     )
    )
    (local.set $6
     (i32.and
      (local.get $4)
      (i32.const 3)
     )
    )
    (local.set $7
     (i32.const 0)
    )
    (local.set $1
     (i32.const 0)
    )
    (block $block1
     (br_if $block1
      (i32.eq
       (local.get $2)
       (local.get $0)
      )
     )
     (local.set $8
      (i32.const 0)
     )
     (local.set $1
      (i32.const 0)
     )
     (block $block2
      (br_if $block2
       (i32.gt_u
        (local.tee $9
         (i32.sub
          (local.get $0)
          (local.get $2)
         )
        )
        (i32.const -4)
       )
      )
      (local.set $8
       (i32.const 0)
      )
      (local.set $1
       (i32.const 0)
      )
      (loop $label
       (local.set $1
        (i32.add
         (i32.add
          (i32.add
           (i32.add
            (local.get $1)
            (i32.gt_s
             (i32.load8_s
              (local.tee $2
               (i32.add
                (local.get $0)
                (local.get $8)
               )
              )
             )
             (i32.const -65)
            )
           )
           (i32.gt_s
            (i32.load8_s
             (i32.add
              (local.get $2)
              (i32.const 1)
             )
            )
            (i32.const -65)
           )
          )
          (i32.gt_s
           (i32.load8_s
            (i32.add
             (local.get $2)
             (i32.const 2)
            )
           )
           (i32.const -65)
          )
         )
         (i32.gt_s
          (i32.load8_s
           (i32.add
            (local.get $2)
            (i32.const 3)
           )
          )
          (i32.const -65)
         )
        )
       )
       (br_if $label
        (local.tee $8
         (i32.add
          (local.get $8)
          (i32.const 4)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $0)
       (local.get $8)
      )
     )
     (loop $label1
      (local.set $1
       (i32.add
        (local.get $1)
        (i32.gt_s
         (i32.load8_s
          (local.get $2)
         )
         (i32.const -65)
        )
       )
      )
      (local.set $2
       (i32.add
        (local.get $2)
        (i32.const 1)
       )
      )
      (br_if $label1
       (local.tee $9
        (i32.add
         (local.get $9)
         (i32.const 1)
        )
       )
      )
     )
    )
    (local.set $9
     (i32.add
      (local.get $0)
      (local.get $3)
     )
    )
    (block $block3
     (br_if $block3
      (i32.eqz
       (local.get $6)
      )
     )
     (local.set $7
      (i32.gt_s
       (i32.load8_s
        (local.tee $2
         (i32.add
          (local.get $9)
          (i32.and
           (local.get $4)
           (i32.const 2147483644)
          )
         )
        )
       )
       (i32.const -65)
      )
     )
     (br_if $block3
      (i32.eq
       (local.get $6)
       (i32.const 1)
      )
     )
     (local.set $7
      (i32.add
       (local.get $7)
       (i32.gt_s
        (i32.load8_s offset=1
         (local.get $2)
        )
        (i32.const -65)
       )
      )
     )
     (br_if $block3
      (i32.eq
       (local.get $6)
       (i32.const 2)
      )
     )
     (local.set $7
      (i32.add
       (local.get $7)
       (i32.gt_s
        (i32.load8_s offset=2
         (local.get $2)
        )
        (i32.const -65)
       )
      )
     )
    )
    (local.set $8
     (i32.add
      (local.get $7)
      (local.get $1)
     )
    )
    (loop $label3
     (local.set $3
      (local.get $9)
     )
     (br_if $block4
      (i32.eqz
       (local.get $5)
      )
     )
     (local.set $6
      (i32.and
       (local.tee $7
        (select
         (local.get $5)
         (i32.const 192)
         (i32.lt_u
          (local.get $5)
          (i32.const 192)
         )
        )
       )
       (i32.const 3)
      )
     )
     (block $block6
      (block $block5
       (br_if $block5
        (local.tee $1
         (i32.and
          (local.tee $4
           (i32.shl
            (local.get $7)
            (i32.const 2)
           )
          )
          (i32.const 1008)
         )
        )
       )
       (local.set $2
        (i32.const 0)
       )
       (br $block6)
      )
      (local.set $0
       (i32.add
        (local.get $3)
        (local.get $1)
       )
      )
      (local.set $2
       (i32.const 0)
      )
      (local.set $1
       (local.get $3)
      )
      (loop $label2
       (local.set $2
        (i32.add
         (i32.and
          (i32.or
           (i32.shr_u
            (i32.xor
             (local.tee $9
              (i32.load
               (i32.add
                (local.get $1)
                (i32.const 12)
               )
              )
             )
             (i32.const -1)
            )
            (i32.const 7)
           )
           (i32.shr_u
            (local.get $9)
            (i32.const 6)
           )
          )
          (i32.const 16843009)
         )
         (i32.add
          (i32.and
           (i32.or
            (i32.shr_u
             (i32.xor
              (local.tee $9
               (i32.load
                (i32.add
                 (local.get $1)
                 (i32.const 8)
                )
               )
              )
              (i32.const -1)
             )
             (i32.const 7)
            )
            (i32.shr_u
             (local.get $9)
             (i32.const 6)
            )
           )
           (i32.const 16843009)
          )
          (i32.add
           (i32.and
            (i32.or
             (i32.shr_u
              (i32.xor
               (local.tee $9
                (i32.load
                 (i32.add
                  (local.get $1)
                  (i32.const 4)
                 )
                )
               )
               (i32.const -1)
              )
              (i32.const 7)
             )
             (i32.shr_u
              (local.get $9)
              (i32.const 6)
             )
            )
            (i32.const 16843009)
           )
           (i32.add
            (i32.and
             (i32.or
              (i32.shr_u
               (i32.xor
                (local.tee $9
                 (i32.load
                  (local.get $1)
                 )
                )
                (i32.const -1)
               )
               (i32.const 7)
              )
              (i32.shr_u
               (local.get $9)
               (i32.const 6)
              )
             )
             (i32.const 16843009)
            )
            (local.get $2)
           )
          )
         )
        )
       )
       (br_if $label2
        (i32.ne
         (local.tee $1
          (i32.add
           (local.get $1)
           (i32.const 16)
          )
         )
         (local.get $0)
        )
       )
      )
     )
     (local.set $5
      (i32.sub
       (local.get $5)
       (local.get $7)
      )
     )
     (local.set $9
      (i32.add
       (local.get $3)
       (local.get $4)
      )
     )
     (local.set $8
      (i32.add
       (i32.shr_u
        (i32.mul
         (i32.add
          (i32.and
           (i32.shr_u
            (local.get $2)
            (i32.const 8)
           )
           (i32.const 16711935)
          )
          (i32.and
           (local.get $2)
           (i32.const 16711935)
          )
         )
         (i32.const 65537)
        )
        (i32.const 16)
       )
       (local.get $8)
      )
     )
     (br_if $label3
      (i32.eqz
       (local.get $6)
      )
     )
    )
    (local.set $1
     (i32.and
      (i32.or
       (i32.shr_u
        (i32.xor
         (local.tee $1
          (i32.load
           (local.tee $2
            (i32.add
             (local.get $3)
             (i32.shl
              (i32.and
               (local.get $7)
               (i32.const 252)
              )
              (i32.const 2)
             )
            )
           )
          )
         )
         (i32.const -1)
        )
        (i32.const 7)
       )
       (i32.shr_u
        (local.get $1)
        (i32.const 6)
       )
      )
      (i32.const 16843009)
     )
    )
    (block $block7
     (br_if $block7
      (i32.eq
       (local.get $6)
       (i32.const 1)
      )
     )
     (local.set $1
      (i32.add
       (i32.and
        (i32.or
         (i32.shr_u
          (i32.xor
           (local.tee $9
            (i32.load offset=4
             (local.get $2)
            )
           )
           (i32.const -1)
          )
          (i32.const 7)
         )
         (i32.shr_u
          (local.get $9)
          (i32.const 6)
         )
        )
        (i32.const 16843009)
       )
       (local.get $1)
      )
     )
     (br_if $block7
      (i32.eq
       (local.get $6)
       (i32.const 2)
      )
     )
     (local.set $1
      (i32.add
       (i32.and
        (i32.or
         (i32.shr_u
          (i32.xor
           (local.tee $2
            (i32.load offset=8
             (local.get $2)
            )
           )
           (i32.const -1)
          )
          (i32.const 7)
         )
         (i32.shr_u
          (local.get $2)
          (i32.const 6)
         )
        )
        (i32.const 16843009)
       )
       (local.get $1)
      )
     )
    )
    (local.set $8
     (i32.add
      (i32.shr_u
       (i32.mul
        (i32.add
         (i32.and
          (i32.shr_u
           (local.get $1)
           (i32.const 8)
          )
          (i32.const 459007)
         )
         (i32.and
          (local.get $1)
          (i32.const 16711935)
         )
        )
        (i32.const 65537)
       )
       (i32.const 16)
      )
      (local.get $8)
     )
    )
    (br $block4)
   )
   (block $block8
    (br_if $block8
     (local.get $1)
    )
    (return
     (i32.const 0)
    )
   )
   (local.set $2
    (i32.and
     (local.get $1)
     (i32.const 3)
    )
   )
   (local.set $9
    (i32.const 0)
   )
   (local.set $8
    (i32.const 0)
   )
   (block $block9
    (br_if $block9
     (i32.lt_u
      (local.get $1)
      (i32.const 4)
     )
    )
    (local.set $5
     (i32.and
      (local.get $1)
      (i32.const -4)
     )
    )
    (local.set $8
     (i32.const 0)
    )
    (local.set $9
     (i32.const 0)
    )
    (loop $label4
     (local.set $8
      (i32.add
       (i32.add
        (i32.add
         (i32.add
          (local.get $8)
          (i32.gt_s
           (i32.load8_s
            (local.tee $1
             (i32.add
              (local.get $0)
              (local.get $9)
             )
            )
           )
           (i32.const -65)
          )
         )
         (i32.gt_s
          (i32.load8_s
           (i32.add
            (local.get $1)
            (i32.const 1)
           )
          )
          (i32.const -65)
         )
        )
        (i32.gt_s
         (i32.load8_s
          (i32.add
           (local.get $1)
           (i32.const 2)
          )
         )
         (i32.const -65)
        )
       )
       (i32.gt_s
        (i32.load8_s
         (i32.add
          (local.get $1)
          (i32.const 3)
         )
        )
        (i32.const -65)
       )
      )
     )
     (br_if $label4
      (i32.ne
       (local.get $5)
       (local.tee $9
        (i32.add
         (local.get $9)
         (i32.const 4)
        )
       )
      )
     )
    )
    (br_if $block4
     (i32.eqz
      (local.get $2)
     )
    )
   )
   (local.set $1
    (i32.add
     (local.get $0)
     (local.get $9)
    )
   )
   (loop $label5
    (local.set $8
     (i32.add
      (local.get $8)
      (i32.gt_s
       (i32.load8_s
        (local.get $1)
       )
       (i32.const -65)
      )
     )
    )
    (local.set $1
     (i32.add
      (local.get $1)
      (i32.const 1)
     )
    )
    (br_if $label5
     (local.tee $2
      (i32.add
       (local.get $2)
       (i32.const -1)
      )
     )
    )
   )
  )
  (local.get $8)
 )
 (func $_RNvMsa_NtCskCpoLMRBwWe_4core3fmtNtB5_9Formatter3pad (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (block $block16
   (block $block
    (br_if $block
     (i32.eqz
      (i32.and
       (local.tee $3
        (i32.load offset=8
         (local.get $0)
        )
       )
       (i32.const 402653184)
      )
     )
    )
    (block $block5
     (block $block8
      (block $block3
       (block $block2
        (block $block1
         (br_if $block1
          (i32.eqz
           (i32.and
            (local.get $3)
            (i32.const 268435456)
           )
          )
         )
         (br_if $block2
          (local.tee $4
           (i32.load16_u offset=14
            (local.get $0)
           )
          )
         )
         (local.set $2
          (i32.const 0)
         )
         (br $block3)
        )
        (block $block4
         (br_if $block4
          (i32.lt_u
           (local.get $2)
           (i32.const 16)
          )
         )
         (local.set $5
          (call $_RNvNtNtCskCpoLMRBwWe_4core3str5count14do_count_chars
           (local.get $1)
           (local.get $2)
          )
         )
         (br $block5)
        )
        (block $block6
         (br_if $block6
          (local.get $2)
         )
         (local.set $5
          (i32.const 0)
         )
         (br $block5)
        )
        (local.set $6
         (i32.and
          (local.get $2)
          (i32.const 3)
         )
        )
        (local.set $7
         (i32.const 0)
        )
        (local.set $5
         (i32.const 0)
        )
        (block $block7
         (br_if $block7
          (i32.lt_u
           (local.get $2)
           (i32.const 4)
          )
         )
         (local.set $4
          (i32.and
           (local.get $2)
           (i32.const 12)
          )
         )
         (local.set $5
          (i32.const 0)
         )
         (local.set $7
          (i32.const 0)
         )
         (loop $label
          (local.set $5
           (i32.add
            (i32.add
             (i32.add
              (i32.add
               (local.get $5)
               (i32.gt_s
                (i32.load8_s
                 (local.tee $8
                  (i32.add
                   (local.get $1)
                   (local.get $7)
                  )
                 )
                )
                (i32.const -65)
               )
              )
              (i32.gt_s
               (i32.load8_s
                (i32.add
                 (local.get $8)
                 (i32.const 1)
                )
               )
               (i32.const -65)
              )
             )
             (i32.gt_s
              (i32.load8_s
               (i32.add
                (local.get $8)
                (i32.const 2)
               )
              )
              (i32.const -65)
             )
            )
            (i32.gt_s
             (i32.load8_s
              (i32.add
               (local.get $8)
               (i32.const 3)
              )
             )
             (i32.const -65)
            )
           )
          )
          (br_if $label
           (i32.ne
            (local.get $4)
            (local.tee $7
             (i32.add
              (local.get $7)
              (i32.const 4)
             )
            )
           )
          )
         )
         (br_if $block5
          (i32.eqz
           (local.get $6)
          )
         )
        )
        (local.set $8
         (i32.add
          (local.get $1)
          (local.get $7)
         )
        )
        (loop $label1
         (local.set $5
          (i32.add
           (local.get $5)
           (i32.gt_s
            (i32.load8_s
             (local.get $8)
            )
            (i32.const -65)
           )
          )
         )
         (local.set $8
          (i32.add
           (local.get $8)
           (i32.const 1)
          )
         )
         (br_if $label1
          (local.tee $6
           (i32.add
            (local.get $6)
            (i32.const -1)
           )
          )
         )
         (br $block5)
        )
       )
       (local.set $7
        (i32.add
         (local.get $1)
         (local.get $2)
        )
       )
       (local.set $2
        (i32.const 0)
       )
       (local.set $8
        (local.get $1)
       )
       (local.set $6
        (local.get $4)
       )
       (loop $label2
        (br_if $block8
         (i32.eq
          (local.tee $5
           (local.get $8)
          )
          (local.get $7)
         )
        )
        (block $block10
         (block $block9
          (br_if $block9
           (i32.le_s
            (local.tee $8
             (i32.load8_s
              (local.get $5)
             )
            )
            (i32.const -1)
           )
          )
          (local.set $8
           (i32.add
            (local.get $5)
            (i32.const 1)
           )
          )
          (br $block10)
         )
         (block $block11
          (br_if $block11
           (i32.ge_u
            (local.get $8)
            (i32.const -32)
           )
          )
          (local.set $8
           (i32.add
            (local.get $5)
            (i32.const 2)
           )
          )
          (br $block10)
         )
         (local.set $8
          (i32.add
           (local.get $5)
           (select
            (i32.const 4)
            (i32.const 3)
            (i32.gt_u
             (local.get $8)
             (i32.const -17)
            )
           )
          )
         )
        )
        (local.set $2
         (i32.add
          (i32.sub
           (local.get $8)
           (local.get $5)
          )
          (local.get $2)
         )
        )
        (br_if $label2
         (local.tee $6
          (i32.add
           (local.get $6)
           (i32.const -1)
          )
         )
        )
       )
      )
      (local.set $6
       (i32.const 0)
      )
     )
     (local.set $5
      (i32.sub
       (local.get $4)
       (local.get $6)
      )
     )
    )
    (br_if $block
     (i32.ge_u
      (local.get $5)
      (local.tee $8
       (i32.load16_u offset=12
        (local.get $0)
       )
      )
     )
    )
    (local.set $9
     (i32.sub
      (local.get $8)
      (local.get $5)
     )
    )
    (local.set $4
     (i32.const 0)
    )
    (block $block12
     (block $block14
      (block $block13
       (br_table $block12 $block13 $block14 $block12 $block12
        (i32.and
         (i32.shr_u
          (local.get $3)
          (i32.const 29)
         )
         (i32.const 3)
        )
       )
      )
      (local.set $4
       (local.get $9)
      )
      (br $block12)
     )
     (local.set $4
      (i32.shr_u
       (i32.and
        (local.get $9)
        (i32.const 65534)
       )
       (i32.const 1)
      )
     )
    )
    (local.set $6
     (i32.and
      (local.get $3)
      (i32.const 2097151)
     )
    )
    (local.set $10
     (i32.load offset=4
      (local.get $0)
     )
    )
    (local.set $8
     (i32.load
      (local.get $0)
     )
    )
    (block $block15
     (br_if $block15
      (i32.eqz
       (local.tee $7
        (i32.and
         (local.get $4)
         (i32.const 65535)
        )
       )
      )
     )
     (local.set $3
      (i32.load offset=16
       (local.get $10)
      )
     )
     (local.set $5
      (i32.const 0)
     )
     (local.set $0
      (i32.const 1)
     )
     (loop $label3
      (br_if $block16
       (call_indirect $0 (type $2)
        (local.get $8)
        (local.get $6)
        (local.get $3)
       )
      )
      (br_if $label3
       (i32.lt_u
        (i32.and
         (local.tee $5
          (i32.add
           (local.get $5)
           (i32.const 1)
          )
         )
         (i32.const 65535)
        )
        (local.get $7)
       )
      )
     )
    )
    (block $block17
     (br_if $block17
      (i32.eqz
       (call_indirect $0 (type $3)
        (local.get $8)
        (local.get $1)
        (local.get $2)
        (i32.load offset=12
         (local.get $10)
        )
       )
      )
     )
     (return
      (i32.const 1)
     )
    )
    (block $block18
     (br_if $block18
      (i32.ne
       (i32.and
        (local.get $9)
        (i32.const 65535)
       )
       (i32.and
        (local.get $4)
        (i32.const 65535)
       )
      )
     )
     (return
      (i32.const 0)
     )
    )
    (local.set $2
     (i32.load offset=16
      (local.get $10)
     )
    )
    (local.set $5
     (i32.const 0)
    )
    (local.set $7
     (i32.and
      (i32.sub
       (local.get $9)
       (local.get $4)
      )
      (i32.const 65535)
     )
    )
    (loop $label4
     (br_if $block16
      (local.tee $0
       (call_indirect $0 (type $2)
        (local.get $8)
        (local.get $6)
        (local.get $2)
       )
      )
     )
     (br_if $block16
      (i32.ge_u
       (i32.and
        (local.tee $5
         (i32.add
          (local.get $5)
          (i32.const 1)
         )
        )
        (i32.const 65535)
       )
       (local.get $7)
      )
     )
     (br $label4)
    )
   )
   (local.set $0
    (call_indirect $0 (type $3)
     (i32.load
      (local.get $0)
     )
     (local.get $1)
     (local.get $2)
     (i32.load offset=12
      (i32.load offset=4
       (local.get $0)
      )
     )
    )
   )
  )
  (local.get $0)
 )
 (func $_RNvMsa_NtCskCpoLMRBwWe_4core3fmtNtB5_9Formatter9write_str (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (call_indirect $0 (type $3)
   (i32.load
    (local.get $0)
   )
   (local.get $1)
   (local.get $2)
   (i32.load offset=12
    (i32.load offset=4
     (local.get $0)
    )
   )
  )
 )
 (func $_RNvNtCskCpoLMRBwWe_4core6option13expect_failed (param $0 i32) (param $1 i32) (param $2 i32)
  (local $3 i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (i32.store offset=4
   (local.get $3)
   (local.get $1)
  )
  (i32.store
   (local.get $3)
   (local.get $0)
  )
  (i64.store offset=8
   (local.get $3)
   (i64.or
    (i64.shl
     (i64.extend_i32_u
      (i32.const 20)
     )
     (i64.const 32)
    )
    (i64.extend_i32_u
     (local.get $3)
    )
   )
  )
  (call $_RNvNtCskCpoLMRBwWe_4core9panicking9panic_fmt
   (i32.const 1048752)
   (i32.add
    (local.get $3)
    (i32.const 8)
   )
   (local.get $2)
  )
  (unreachable)
 )
 (func $_RNvNtNtCskCpoLMRBwWe_4core9panicking11panic_const23panic_const_div_by_zero (param $0 i32)
  (call $_RNvNtCskCpoLMRBwWe_4core9panicking9panic_fmt
   (i32.const 1049328)
   (i32.const 51)
   (local.get $0)
  )
  (unreachable)
 )
 (func $_RNvNtNtNtCs62tQcOokijN_17compiler_builtins4math9libm_math3exp3exp (param $0 f64) (result f64)
  (local $1 i64)
  (local $2 i32)
  (local $3 f64)
  (local $4 f64)
  (local $5 i32)
  (local $6 i64)
  (local $7 f64)
  (block $block4
   (block $block5
    (block $block1
     (block $block
      (br_if $block
       (i32.lt_u
        (local.tee $2
         (i32.and
          (i32.wrap_i64
           (i64.shr_u
            (local.tee $1
             (i64.reinterpret_f64
              (local.get $0)
             )
            )
            (i64.const 52)
           )
          )
          (i32.const 2047)
         )
        )
        (i32.const 969)
       )
      )
      (br_if $block1
       (i32.gt_u
        (local.get $2)
        (i32.const 1032)
       )
      )
      (local.set $0
       (f64.add
        (f64.mul
         (f64.mul
          (local.tee $4
           (f64.mul
            (local.tee $0
             (f64.add
              (f64.add
               (local.get $0)
               (f64.mul
                (local.tee $4
                 (f64.add
                  (local.tee $3
                   (f64.add
                    (f64.mul
                     (local.get $0)
                     (f64.const 184.6649652337873)
                    )
                    (f64.const 6755399441055744)
                   )
                  )
                  (f64.const -6755399441055744)
                 )
                )
                (f64.const -0.005415212348111709)
               )
              )
              (f64.mul
               (local.get $4)
               (f64.const -1.2864023111638346e-14)
              )
             )
            )
            (local.get $0)
           )
          )
          (local.get $4)
         )
         (f64.add
          (f64.mul
           (local.get $0)
           (f64.const 0.008333335853059549)
          )
          (f64.const 0.0416666808410674)
         )
        )
        (f64.add
         (f64.mul
          (local.get $4)
          (f64.add
           (f64.mul
            (local.get $0)
            (f64.const 0.16666666666665886)
           )
           (f64.const 0.49999999999996786)
          )
         )
         (f64.add
          (local.get $0)
          (f64.load offset=1049360
           (local.tee $5
            (i32.shl
             (i32.and
              (i32.wrap_i64
               (local.tee $1
                (i64.reinterpret_f64
                 (local.get $3)
                )
               )
              )
              (i32.const 127)
             )
             (i32.const 4)
            )
           )
          )
         )
        )
       )
      )
      (local.set $6
       (i64.add
        (i64.load offset=1049368
         (local.get $5)
        )
        (i64.shl
         (local.get $1)
         (i64.const 45)
        )
       )
      )
      (block $block2
       (br_if $block2
        (i32.eq
         (local.get $2)
         (i32.const 1032)
        )
       )
       (return
        (f64.add
         (f64.mul
          (local.get $0)
          (local.tee $4
           (f64.reinterpret_i64
            (local.get $6)
           )
          )
         )
         (local.get $4)
        )
       )
      )
      (block $block3
       (br_if $block3
        (i64.ne
         (i64.and
          (local.get $1)
          (i64.const 2147483648)
         )
         (i64.const 0)
        )
       )
       (return
        (f64.mul
         (f64.add
          (f64.mul
           (local.get $0)
           (local.tee $4
            (f64.reinterpret_i64
             (i64.add
              (local.get $6)
              (i64.const -4544132024016830464)
             )
            )
           )
          )
          (local.get $4)
         )
         (f64.const 5486124068793688683255936e279)
        )
       )
      )
      (br_if $block4
       (i32.eqz
        (f64.lt
         (local.tee $0
          (f64.add
           (local.tee $3
            (f64.mul
             (local.get $0)
             (local.tee $4
              (f64.reinterpret_i64
               (i64.add
                (local.get $6)
                (i64.const 4602678819172646912)
               )
              )
             )
            )
           )
           (local.get $4)
          )
         )
         (f64.const 1)
        )
       )
      )
      (br_if $block4
       (f64.ne
        (local.tee $0
         (f64.add
          (f64.add
           (local.tee $7
            (f64.add
             (local.get $0)
             (f64.const 1)
            )
           )
           (f64.add
            (f64.add
             (local.get $3)
             (f64.sub
              (local.get $4)
              (local.get $0)
             )
            )
            (f64.add
             (local.get $0)
             (f64.sub
              (f64.const 1)
              (local.get $7)
             )
            )
           )
          )
          (f64.const -1)
         )
        )
        (f64.const 0)
       )
      )
      (local.set $0
       (f64.const 0)
      )
      (br $block4)
     )
     (local.set $4
      (f64.add
       (local.get $0)
       (f64.const 1)
      )
     )
     (br $block5)
    )
    (local.set $4
     (f64.const 0)
    )
    (br_if $block5
     (i64.eq
      (local.get $1)
      (i64.const -4503599627370496)
     )
    )
    (block $block6
     (br_if $block6
      (i32.eq
       (local.get $2)
       (i32.const 2047)
      )
     )
     (return
      (select
       (f64.const inf)
       (f64.const 0)
       (i64.gt_s
        (local.get $1)
        (i64.const -1)
       )
      )
     )
    )
    (return
     (f64.add
      (local.get $0)
      (f64.const 1)
     )
    )
   )
   (return
    (local.get $4)
   )
  )
  (f64.mul
   (local.get $0)
   (f64.const 2.2250738585072014e-308)
  )
 )
 (func $_RNvNtNtCs62tQcOokijN_17compiler_builtins4math20partial_availability4exp2 (param $0 f64) (result f64)
  (local $1 i64)
  (local $2 i32)
  (local $3 f64)
  (local $4 f64)
  (local $5 i64)
  (local $6 i64)
  (local $7 f64)
  (block $block1
   (block $block3
    (block $block2
     (block $block
      (br_if $block
       (i32.lt_u
        (local.tee $2
         (i32.and
          (i32.wrap_i64
           (i64.shr_u
            (local.tee $1
             (i64.reinterpret_f64
              (local.get $0)
             )
            )
            (i64.const 52)
           )
          )
          (i32.const 2047)
         )
        )
        (i32.const 969)
       )
      )
      (br_if $block1
       (i32.le_u
        (local.get $2)
        (i32.const 1032)
       )
      )
      (local.set $3
       (f64.const 0)
      )
      (br_if $block2
       (i64.eq
        (local.get $1)
        (i64.const -4503599627370496)
       )
      )
      (br_if $block3
       (i32.eq
        (local.get $2)
        (i32.const 2047)
       )
      )
      (local.set $3
       (f64.const inf)
      )
      (br_if $block2
       (i64.gt_s
        (local.get $1)
        (i64.const -1)
       )
      )
      (local.set $3
       (f64.const 0)
      )
      (br_if $block1
       (i64.le_u
        (local.get $1)
        (i64.const -4570929321408987137)
       )
      )
      (br $block2)
     )
     (local.set $3
      (f64.add
       (local.get $0)
       (f64.const 1)
      )
     )
    )
    (return
     (local.get $3)
    )
   )
   (return
    (f64.add
     (local.get $0)
     (f64.const 1)
    )
   )
  )
  (local.set $0
   (f64.add
    (f64.mul
     (f64.mul
      (local.tee $3
       (f64.mul
        (local.tee $0
         (f64.sub
          (local.get $0)
          (f64.add
           (local.tee $4
            (f64.add
             (local.get $0)
             (f64.const 52776558133248)
            )
           )
           (f64.const -52776558133248)
          )
         )
        )
        (local.get $0)
       )
      )
      (local.get $3)
     )
     (f64.add
      (f64.mul
       (local.get $0)
       (f64.const 1.3332074570119598e-03)
      )
      (f64.const 0.009618131975721055)
     )
    )
    (f64.add
     (f64.mul
      (local.get $3)
      (f64.add
       (f64.mul
        (local.get $0)
        (f64.const 0.0555041086686087)
       )
       (f64.const 0.24022650695909065)
      )
     )
     (f64.add
      (f64.mul
       (local.get $0)
       (f64.const 0.6931471805599453)
      )
      (f64.load offset=1049360
       (local.tee $2
        (i32.shl
         (i32.and
          (i32.wrap_i64
           (local.tee $5
            (i64.reinterpret_f64
             (local.get $4)
            )
           )
          )
          (i32.const 127)
         )
         (i32.const 4)
        )
       )
      )
     )
    )
   )
  )
  (local.set $6
   (i64.add
    (i64.load offset=1049368
     (local.get $2)
    )
    (i64.shl
     (local.get $5)
     (i64.const 45)
    )
   )
  )
  (block $block4
   (br_if $block4
    (i64.gt_u
     (i64.shl
      (local.get $1)
      (i64.const 1)
     )
     (i64.const -9143996093422370816)
    )
   )
   (return
    (f64.add
     (f64.mul
      (local.get $0)
      (local.tee $3
       (f64.reinterpret_i64
        (local.get $6)
       )
      )
     )
     (local.get $3)
    )
   )
  )
  (block $block5
   (br_if $block5
    (i64.ne
     (i64.and
      (local.get $5)
      (i64.const 2147483648)
     )
     (i64.const 0)
    )
   )
   (return
    (f64.add
     (local.tee $0
      (f64.add
       (f64.mul
        (local.get $0)
        (local.tee $3
         (f64.reinterpret_i64
          (i64.add
           (local.get $6)
           (i64.const -4503599627370496)
          )
         )
        )
       )
       (local.get $3)
      )
     )
     (local.get $0)
    )
   )
  )
  (block $block6
   (br_if $block6
    (i32.eqz
     (f64.lt
      (local.tee $0
       (f64.add
        (local.tee $4
         (f64.mul
          (local.get $0)
          (local.tee $3
           (f64.reinterpret_i64
            (i64.add
             (local.get $6)
             (i64.const 4602678819172646912)
            )
           )
          )
         )
        )
        (local.get $3)
       )
      )
      (f64.const 1)
     )
    )
   )
   (br_if $block6
    (f64.ne
     (local.tee $0
      (f64.add
       (f64.add
        (local.tee $7
         (f64.add
          (local.get $0)
          (f64.const 1)
         )
        )
        (f64.add
         (f64.add
          (local.get $4)
          (f64.sub
           (local.get $3)
           (local.get $0)
          )
         )
         (f64.add
          (local.get $0)
          (f64.sub
           (f64.const 1)
           (local.get $7)
          )
         )
        )
       )
       (f64.const -1)
      )
     )
     (f64.const 0)
    )
   )
   (local.set $0
    (f64.const 0)
   )
  )
  (f64.mul
   (local.get $0)
   (f64.const 2.2250738585072014e-308)
  )
 )
 (func $exp (param $0 f64) (result f64)
  (call $_RNvNtNtNtCs62tQcOokijN_17compiler_builtins4math9libm_math3exp3exp
   (local.get $0)
  )
 )
 (func $exp2 (param $0 f64) (result f64)
  (call $_RNvNtNtCs62tQcOokijN_17compiler_builtins4math20partial_availability4exp2
   (local.get $0)
  )
 )
 ;; custom section "producers", size 60
 ;; features section: mutable-globals, nontrapping-float-to-int, bulk-memory, sign-ext, reference-types, multivalue, bulk-memory-opt, call-indirect-overlong
)

