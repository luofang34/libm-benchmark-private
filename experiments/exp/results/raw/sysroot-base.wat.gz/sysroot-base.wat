(module $exp_experiment.wasm
 (type $0 (func (param i32 i32)))
 (type $1 (func (param f64) (result f64)))
 (type $2 (func (param i32 i32) (result i32)))
 (type $3 (func (param i32 i32 i32) (result i32)))
 (type $4 (func (param i32)))
 (type $5 (func (param i32 i32 i32)))
 (type $6 (func (param i32 i32 i32 i32 i32)))
 (type $7 (func (param i32 i32 i32 i32) (result i32)))
 (type $8 (func))
 (type $9 (func (param i32) (result i32)))
 (type $10 (func (result f64)))
 (type $11 (func (param f64 i64 i64)))
 (type $12 (func (param i32 i32 i64) (result i64)))
 (type $13 (func (param i32 i32 i32 i32 i32 i32)))
 (import "env" "clock_ms" (func $_RNvNtCscurvdXMHcvM_14exp_experiment3abi8clock_ms (result f64)))
 (import "env" "report" (func $_RNvNtCscurvdXMHcvM_14exp_experiment3abi6report (param f64 i64 i64)))
 (global $__stack_pointer (mut i32) (i32.const 1048576))
 (memory $0 17)
 (data $.rodata (i32.const 1048576) "\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\80\00\00\00\00\00\00\f0\7f\00\00\00\00\00\00\f0\ff\00\00\00\00\00\00\f8\7f\01\00\00\00\00\00\f0\7f\ff\ff\ff\ff\ff\ff\ef\7f\ff\ff\ff\ff\ff\ff\ef\ff\00\00\00\00\08\00\00\00\04\00\00\00\05\00\00\00\06\00\00\00\07\00\00\00\08\00\00\00\t\00\00\00\10\00\00\00\04\00\00\00\n\00\00\00\0b\00\00\00\0c\00\00\00\r\00\00\00\\\f6\e9_\dc\02\f6\b9\f1\c1pl\f2a\c1$\ad!D\a0V\80\a6\df\c8\03L\b6\d9\7fE\ec\0e\00\00\00\0c\00\00\00\04\00\00\00\0f\00\00\00\10\00\00\00\11\00\00\00\c0\00/private/tmp/libm-exp-sysroots/base/library/std/src/sys/sync/rwlock/no_threads.rs\00/private/tmp/libm-exp-sysroots/base/library/alloc/src/raw_vec/mod.rs\00/Users/fangluo/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/dlmalloc-0.2.14/src/dlmalloc.rs\00assertion failed: psize >= size + min_overhead\00I\01\10\00c\00\00\00\e9\04\00\00\t\00\00\00assertion failed: psize <= size + max_overhead\00\00I\01\10\00c\00\00\00\ef\04\00\00\r\00\00\00I\01\10\00c\00\00\00M\05\00\00\1e\00\00\00rwlock overflowed read locks\b2\00\10\00Q\00\00\00\1e\00\00\00,\00\00\00\00\00\00\00\08\00\00\00\04\00\00\00\12\00\00\00\0e\00\00\00\0c\00\00\00\04\00\00\00\13\00\00\00rwlock has not been locked for reading\00\00\b2\00\10\00Q\00\00\00G\00\00\00\t\00\00\00capacity overflow\00\00\00\04\01\10\00D\00\00\00\1d\00\00\00\05\00\00\00attempt to divide by zero\00\00\00\00\00\00\00\00\00\e0?\00\00\00\00\00\00\e0\bf]=\7ff\9e\a0\e6?\00\00\00\00\00\889=D\17u\faR\b0\e6?\00\00\00\00\00\00\d8<\fe\d9\0bu\12\c0\e6?\00\00\00\00\00x(\bd\bfv\d4\dd\dc\cf\e6?\00\00\00\00\00\c0\1e=)\1ae<\b2\df\e6?\00\00\00\00\00\00\d8\bc\e3:Y\98\92\ef\e6?\00\00\00\00\00\00\bc\bc\86\93Q\f9}\ff\e6?\00\00\00\00\00\d8/\bd\a3-\f4ft\0f\e7?\00\00\00\00\00\88,\bd\c3_\ec\e8u\1f\e7?\00\00\00\00\00\c0\13=\05\cf\ea\86\82/\e7?\00\00\00\00\0008\bdR\81\a5H\9a?\e7?\00\00\00\00\00\c0\00\bd\fc\cc\d75\bdO\e7?\00\00\00\00\00\88/=\f1gBV\eb_\e7?\00\00\00\00\00\e0\03=Hm\ab\b1$p\e7?\00\00\00\00\00\d0\'\bd8]\deOi\80\e7?\00\00\00\00\00\00\dd\bc\00\1d\ac8\b9\90\e7?\00\00\00\00\00\00\e3<x\01\ebs\14\a1\e7?\00\00\00\00\00\00\ed\bc`\d0v\t{\b1\e7?\00\00\00\00\00@ =3\c10\01\ed\c1\e7?\00\00\00\00\00\00\a0<6\86\ffbj\d2\e7?\00\00\00\00\00\90&\bd;N\cf6\f3\e2\e7?\00\00\00\00\00\e0\02\bd\e8\c3\91\84\87\f3\e7?\00\00\00\00\00X$\bdN\1b>T\'\04\e8?\00\00\00\00\00\003=\1a\07\d1\ad\d2\14\e8?\00\00\00\00\00\00\0f=~\cdL\99\89%\e8?\00\00\00\00\00\c0!\bd\d0B\b9\1eL6\e8?\00\00\00\00\00\d0)=\b5\ca#F\1aG\e8?\00\00\00\00\00\10G=\bc[\9f\17\f4W\e8?\00\00\00\00\00`\"=\af\91D\9b\d9h\e8?\00\00\00\00\00\c42\bd\95\a31\d9\cay\e8?\00\00\00\00\00\00#\bd\b8e\8a\d9\c7\8a\e8?\00\00\00\00\00\80*\bd\00Xx\a4\d0\9b\e8?\00\00\00\00\00\00\ed\bc#\a2*B\e5\ac\e8?\00\00\00\00\00(3=\fa\19\d6\ba\05\be\e8?\00\00\00\00\00\b4B=\83C\b5\162\cf\e8?\00\00\00\00\00\d0.\bdLf\08^j\e0\e8?\00\00\00\00\00P \bd\07x\15\99\ae\f1\e8?\00\00\00\00\00((=\0e,(\d0\fe\02\e9?\00\00\00\00\00\b0\1c\bd\96\ff\91\0b[\14\e9?\00\00\00\00\00\e0\05\bd\f9/\aaS\c3%\e9?\00\00\00\00\00@\f5<J\c6\cd\b077\e9?\00\00\00\00\00 \17=\ae\98_+\b8H\e9?\00\00\00\00\00\00\t\bd\cbR\c8\cbDZ\e9?\00\00\00\00\00h%=!ov\9a\ddk\e9?\00\00\00\00\00\d06\bd*N\de\9f\82}\e9?\00\00\00\00\00\00\01\bd\a3#z\e43\8f\e9?\00\00\00\00\00\00-=\04\06\cap\f1\a0\e9?\00\00\00\00\00\a48\bd\89\ffSM\bb\b2\e9?\00\00\00\00\00\\5=[\f1\a3\82\91\c4\e9?\00\00\00\00\00\b8&=\c5\b8K\19t\d6\e9?\00\00\00\00\00\00\ec\bc\8e#\e3\19c\e8\e9?\00\00\00\00\00\d0\17=\02\f3\07\8d^\fa\e9?\00\00\00\00\00@\16=M\e5]{f\0c\ea?\00\00\00\00\00\00\f5\bc\f6\b8\8e\edz\1e\ea?\00\00\00\00\00\e0\t=\'.J\ec\9b0\ea?\00\00\00\00\00\d8*=]\nF\80\c9B\ea?\00\00\00\00\00\f0\1a\bd\9b%>\b2\03U\ea?\00\00\00\00\00`\0b=\13b\f4\8aJg\ea?\00\00\00\00\00\888=\a7\b30\13\9ey\ea?\00\00\00\00\00 \11=\8d.\c1S\fe\8b\ea?\00\00\00\00\00\c0\06=\d2\fcyUk\9e\ea?\00\00\00\00\00\b8)\bd\b8o5!\e5\b0\ea?\00\00\00\00\00p+=\81\f3\d3\bfk\c3\ea?\00\00\00\00\00\00\d9<\80\'<:\ff\d5\ea?\00\00\00\00\00\00\e4<\a3\d2Z\99\9f\e8\ea?\00\00\00\00\00\90,\bdg\f3\"\e6L\fb\ea?\00\00\00\00\00P\16=\90\b7\8d)\07\0e\eb?\00\00\00\00\00\d4/=\a9\89\9al\ce \eb?\00\00\00\00\00p\12=K\1aO\b8\a23\eb?\00\00\00\00\00GM=\e7G\b7\15\84F\eb?\00\00\00\00\0088\bd:Y\e5\8drY\eb?\00\00\00\00\00\00\98<j\c5\f1)nl\eb?\00\00\00\00\00\d0\n=P^\fb\f2v\7f\eb?\00\00\00\00\00\80\de<\b2I\'\f2\8c\92\eb?\00\00\00\00\00\c0\04\bd\03\06\a10\b0\a5\eb?\00\00\00\00\00p\r\bdfo\9a\b7\e0\b8\eb?\00\00\00\00\00\90\r=\ff\c1K\90\1e\cc\eb?\00\00\00\00\00\a0\02=o\a1\f3\c3i\df\eb?\00\00\00\00\00x\1f\bd\b8\1d\d7[\c2\f2\eb?\00\00\00\00\00\a0\10\bd\e9\b2Aa(\06\ec?\00\00\00\00\00@\11\bd\e0R\85\dd\9b\19\ec?\00\00\00\00\00\e0\0b=\eed\fa\d9\1c-\ec?\00\00\00\00\00@\t\bd/\d0\ff_\ab@\ec?\00\00\00\00\00\d0\0e\bd\15\fd\faxGT\ec?\00\00\00\00\00f9=\cb\d0W.\f1g\ec?\00\00\00\00\00\10\1a\bd\b6\c1\88\89\a8{\ec?\00\00\00\00\80EX\bd3\e7\06\94m\8f\ec?\00\00\00\00\00H\1a\bd\df\c4QW@\a3\ec?\00\00\00\00\00\00\cb<\94\90\ef\dc \b7\ec?\00\00\00\00\00@\01=\89\16m.\0f\cb\ec?\00\00\00\00\00 \f0<\12\c4]U\0b\df\ec?\00\00\00\00\00`\f3<;\ab[[\15\f3\ec?\00\00\00\00\00\90\06\bd\bc\89\07J-\07\ed?\00\00\00\00\00\a0\t=\fa\c8\08+S\1b\ed?\00\00\00\00\00\e0\15\bd\85\8a\r\08\87/\ed?\00\00\00\00\00(\1d=\03\a2\ca\ea\c8C\ed?\00\00\00\00\00\a0\01=\91\a4\fb\dc\18X\ed?\00\00\00\00\00\00\df<\a1\e6b\e8vl\ed?\00\00\00\00\00\a0\03\bdN\83\c9\16\e3\80\ed?\00\00\00\00\00\d8\0c\bd\90`\ffq]\95\ed?\00\00\00\00\00\c0\f4<\ae2\db\03\e6\a9\ed?\00\00\00\00\00\90\ff<%\83:\d6|\be\ed?\00\00\00\00\00\80\e9<E\b4\01\f3!\d3\ed?\00\00\00\00\00 \f5\bc\bf\05\1cd\d5\e7\ed?\00\00\00\00\00p\1d\bd\ec\9a{3\97\fc\ed?\00\00\00\00\00\14\16\bd^}\19kg\11\ee?\00\00\00\00\00H\0b=\e7\a3\f5\14F&\ee?\00\00\00\00\00\ce@=\\\ee\16;3;\ee?\00\00\00\00\00h\0c=\b4?\8b\e7.P\ee?\00\00\00\00\000\t\bdhmg$9e\ee?\00\00\00\00\00\00\e5\bcDL\c7\fbQz\ee?\00\00\00\00\00\f8\07\bd&\b7\cdwy\8f\ee?\00\00\00\00\00p\f3\bc\e8\90\a4\a2\af\a4\ee?\00\00\00\00\00\d0\e5<\e4\ca|\86\f4\b9\ee?\00\00\00\00\00\1a\16=\rh\8e-H\cf\ee?\00\00\00\00\00P\f5<\14\85\18\a2\aa\e4\ee?\00\00\00\00\00@\c6<\13Za\ee\1b\fa\ee?\00\00\00\00\00\80\ee\bc\06A\b6\1c\9c\0f\ef?\00\00\00\00\00\88\fa\bcc\b9k7+%\ef?\00\00\00\00\00\90,\bdur\ddH\c9:\ef?\00\00\00\00\00\00\aa<$En[vP\ef?\00\00\00\00\00\f0\f4\bc\fdD\88y2f\ef?\00\00\00\00\00\80\ca<8\be\9c\ad\fd{\ef?\00\00\00\00\00\bc\fa<\82<$\02\d8\91\ef?\00\00\00\00\00`\d4\bc\8e\90\9e\81\c1\a7\ef?\00\00\00\00\00\0c\0b\bd\11\d5\926\ba\bd\ef?\00\00\00\00\00\e0\c0\bc\94q\8f+\c2\d3\ef?\00\00\00\00\80\de\10\bd\ee#*k\d9\e9\ef?\00\00\00\00\00C\ee<\00\00\00\00\00\00\f0?\00\00\00\00\00\00\00\00\be\bcZ\fa\1a\0b\f0?\00\00\00\00\00@\b3\bc\033\fb\a9=\16\f0?\00\00\00\00\00\17\12\bd\82\02;\14h!\f0?\00\00\00\00\00@\ba<l\80w>\9a,\f0?\00\00\00\00\00\98\ef<\ca\bb\11.\d47\f0?\00\00\00\00\00@\c7\bc\89\7fn\e8\15C\f0?\00\00\00\00\000\d8<gT\f6r_N\f0?\00\00\00\00\00?\1a\bdZ\85\15\d3\b0Y\f0?\00\00\00\00\00\84\02\bd\95\1f<\0e\ne\f0?\00\00\00\00\00`\f1<\1a\f7\dd)kp\f0?\00\00\00\00\00$\15=-\a8r+\d4{\f0?\00\00\00\00\00\a0\e9\bc\d0\9bu\18E\87\f0?\00\00\00\00\00@\e6<\c8\07f\f6\bd\92\f0?\00\00\00\00\00x\00\bd\83\f3\c6\ca>\9e\f0?\00\00\00\00\00\00\98\bc09\1f\9b\c7\a9\f0?\00\00\00\00\00\a0\ff<\fc\88\f9lX\b5\f0?\00\00\00\00\00\c8\fa\bc\8al\e4E\f1\c0\f0?\00\00\00\00\00\c0\d9<\16Hr+\92\cc\f0?\00\00\00\00\00 \05=\d8]9#;\d8\f0?\00\00\00\00\00\d0\fa\bc\f3\d1\d32\ec\e3\f0?\00\00\00\00\00\ac\1b=\a6\a9\df_\a5\ef\f0?\00\00\00\00\00\e8\04\bd\f0\d2\fe\aff\fb\f0?\00\00\00\00\000\r\bdK#\d7(0\07\f1?\00\00\00\00\00P\f1<[[\12\d0\01\13\f1?\00\00\00\00\00\00\ec<\f9*^\ab\db\1e\f1?\00\00\00\00\00\bc\16=\d51l\c0\bd*\f1?\00\00\00\00\00@\e8<}\04\f2\14\a86\f1?\00\00\00\00\00\d0\0e\bd\e9-\a9\ae\9aB\f1?\00\00\00\00\00\e0\e8<81O\93\95N\f1?\00\00\00\00\00@\eb<q\8e\a5\c8\98Z\f1?\00\00\00\00\000\05=\df\c3qT\a4f\f1?\00\00\00\00\008\03=\11R}<\b8r\f1?\00\00\00\00\00\d4(=\9f\bb\95\86\d4~\f1?\00\00\00\00\00\d0\05\bd\93\8d\8c8\f9\8a\f1?\00\00\00\00\00\88\1c\bdf]7X&\97\f1?\00\00\00\00\00\f0\11=\a7\cbo\eb[\a3\f1?\00\00\00\00\00H\10=\e3\87\13\f8\99\af\f1?\00\00\00\00\009G\bdT]\04\84\e0\bb\f1?\00\00\00\00\00\e4$=C\1c(\95/\c8\f1?\00\00\00\00\00 \n\bd\b2\b9h1\87\d4\f1?\00\00\00\00\00\80\e3<1@\b4^\e7\e0\f1?\00\00\00\00\00\c0\ea<8\d9\fc\"P\ed\f1?\00\00\00\00\00\90\01=\f7\cd8\84\c1\f9\f1?\00\00\00\00\00x\1b\bd\8f\8db\88;\06\f2?\00\00\00\00\00\94-=\1e\a8x5\be\12\f2?\00\00\00\00\00\00\d8<A\dd}\91I\1f\f2?\00\00\00\00\004+=#\13y\a2\dd+\f2?\00\00\00\00\00\f8\19=\e7aunz8\f2?\00\00\00\00\00\c8\19\bd\'\14\82\fb\1fE\f2?\00\00\00\00\000\02=\02\a6\b2O\ceQ\f2?\00\00\00\00\00H\13\bd\b0\ce\1eq\85^\f2?\00\00\00\00\00p\12=\16}\e2eEk\f2?\00\00\00\00\00\d0\11=\0f\e0\1d4\0ex\f2?\00\00\00\00\00\ee1=>c\f5\e1\df\84\f2?\00\00\00\00\00\c0\14\bd0\bb\91u\ba\91\f2?\00\00\00\00\00\d8\13\bd\t\df\1f\f5\9d\9e\f2?\00\00\00\00\00\b0\08=\9b\0e\d1f\8a\ab\f2?\00\00\00\00\00|\"\bd:\da\da\d0\7f\b8\f2?\00\00\00\00\004*=\f9\1aw9~\c5\f2?\00\00\00\00\00\80\10\bd\d9\02\e4\a6\85\d2\f2?\00\00\00\00\00\d0\0e\bdy\15d\1f\96\df\f2?\00\00\00\00\00 \f4\bc\cf.>\a9\af\ec\f2?\00\00\00\00\00\98$\bd\"\88\bdJ\d2\f9\f2?\00\00\00\00\000\16\bd%\b61\n\fe\06\f3?\00\00\00\00\0062\bd\0b\a5\ee\ed2\14\f3?\00\00\00\00\80\dfp\bd\b8\d7L\fcp!\f3?\00\00\00\00\00H\"\bd\a2\e9\a8;\b8.\f3?\00\00\00\00\00\98%\bdf\17d\b2\08<\f3?\00\00\00\00\00\d0\1e=\'\fa\e3fbI\f3?\00\00\00\00\00\00\dc\bc\0f\9f\92_\c5V\f3?\00\00\00\00\00\d80\bd\b9\88\de\a21d\f3?\00\00\00\00\00\c8\"=9\aa:7\a7q\f3?\00\00\00\00\00` =\fet\1e#&\7f\f3?\00\00\00\00\00`\16\bd8\d8\05m\ae\8c\f3?\00\00\00\00\00\e0\n\bd\c3>q\1b@\9a\f3?\00\00\00\00\00rD\bd \a0\e54\db\a7\f3?\00\00\00\00\00 \08=\95n\ec\bf\7f\b5\f3?\00\00\00\00\00\80>=\f2\a8\13\c3-\c3\f3?\00\00\00\00\00\80\ef<\"\e1\edD\e5\d0\f3?\00\00\00\00\00\a0\17\bd\bb4\12L\a6\de\f3?\00\00\00\00\000&=\ccN\1c\dfp\ec\f3?\00\00\00\00\00\a6H\bd\8c~\ac\04E\fa\f3?\00\00\00\00\00\dc<\bd\bb\a0g\c3\"\08\f4?\00\00\00\00\00\b8%=\95.\f7!\n\16\f4?\00\00\00\00\00\c0\1e=FF\t\'\fb#\f4?\00\00\00\00\00`\13\bd \a9P\d9\f51\f4?\00\00\00\00\00\98#=\eb\b9\84?\fa?\f4?\00\00\00\00\00\00\fa<\19\89a`\08N\f4?\00\00\00\00\00\c0\f6\bc\01\d2\a7B \\\f4?\00\00\00\00\00\c0\0b\bd\16\00\1d\edAj\f4?\00\00\00\00\00\80\12\bd&3\8bfmx\f4?\00\00\00\00\00\e00=\00<\c1\b5\a2\86\f4?\00\00\00\00\00@-\bd\04\af\92\e1\e1\94\f4?\00\00\00\00\00 \0c=r\d3\d7\f0*\a3\f4?\00\00\00\00\00P\1e\bd\01\b8m\ea}\b1\f4?\00\00\00\00\00\80\07=\e1)6\d5\da\bf\f4?\00\00\00\00\00\80\13\bd2\c1\17\b8A\ce\f4?\00\00\00\00\00\80\00=\db\dd\fd\99\b2\dc\f4?\00\00\00\00\00p,=\96\ab\d8\81-\eb\f4?\00\00\00\00\00\e0\1c\bd\02-\9dv\b2\f9\f4?\00\00\00\00\00 \19=\c11E\7fA\08\f5?\00\00\00\00\00\c0\08\bd*f\cf\a2\da\16\f5?\00\00\00\00\00\00\fa\bc\eaQ?\e8}%\f5?\00\00\00\00\00\08J=\daN\9dV+4\f5?\00\00\00\00\00\d8&\bd\1a\ac\f6\f4\e2B\f5?\00\00\00\00\00D2\bd\db\94]\ca\a4Q\f5?\00\00\00\00\00<H=k\11\e9\ddp`\f5?\00\00\00\00\00\b0$=\de)\b56Go\f5?\00\00\00\00\00ZA=\0e\c4\e2\db\'~\f5?\00\00\00\00\00\e0)\bdo\c7\97\d4\12\8d\f5?\00\00\00\00\00\08#\bdL\0b\ff\'\08\9c\f5?\00\00\00\00\00\ecM=\'TH\dd\07\ab\f5?\00\00\00\00\00\00\c4\bc\f4z\a8\fb\11\ba\f5?\00\00\00\00\00\080=\0bFY\8a&\c9\f5?\00\00\00\00\00\c8&\bd?\8e\99\90E\d8\f5?\00\00\00\00\00\9aF=\e1 \ad\15o\e7\f5?\00\00\00\00\00@\1b\bd\ca\eb\dc \a3\f6\f5?\00\00\00\00\00p\17=\b8\dcv\b9\e1\05\f6?\00\00\00\00\00\f8&=\15\f7\cd\e6*\15\f6?\00\00\00\00\00\00\01=1U:\b0~$\f6?\00\00\00\00\00\d0\15\bd\b5)\19\1d\dd3\f6?\00\00\00\00\00\d0\12\bd\13\c3\cc4FC\f6?\00\00\00\00\00\80\ea\bc\fa\8e\bc\fe\b9R\f6?\00\00\00\00\00`(\bd\973U\828b\f6?\00\00\00\00\00\feq=\8e2\08\c7\c1q\f6?\00\00\00\00\00 7\bd~\a9L\d4U\81\f6?\00\00\00\00\00\80\e6<q\94\9e\b1\f4\90\f6?\00\00\00\00\00x)\bd")
 (data $.data (i32.const 1053456) "\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\ff\0f\00\00")
 (table $0 21 21 funcref)
 (elem $0 (i32.const 1) $_RNvNtCscurvdXMHcvM_14exp_experiment6kernel7control $_RNvNtCscurvdXMHcvM_14exp_experiment6kernel12standard_exp $_RNvNtCscurvdXMHcvM_14exp_experiment6kernel13standard_exp2 $_RNvNtCs5pJS1yE9e7z_3std5alloc24default_alloc_error_hook $_RNvXs2_NvNtCs5pJS1yE9e7z_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCseWvMq1ZOdSr_4core3fmt7Display3fmt $_RNvXs1_NvNtCs5pJS1yE9e7z_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCs7Tc6kFxL613_5alloc9panicking12PanicPayload8take_box $_RNvXs1_NvNtCs5pJS1yE9e7z_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCs7Tc6kFxL613_5alloc9panicking12PanicPayload3get $_RNvXs1_NvNtCs5pJS1yE9e7z_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCs7Tc6kFxL613_5alloc9panicking12PanicPayload6as_str $_RINvNtCseWvMq1ZOdSr_4core3ptr9drop_glueNtNvNtCs5pJS1yE9e7z_3std9panicking13panic_handler19FormatStringPayloadEBH_ $_RNvXs0_NvNtCs5pJS1yE9e7z_3std9panicking13panic_handlerNtB5_19FormatStringPayloadNtNtCseWvMq1ZOdSr_4core3fmt7Display3fmt $_RNvXs_NvNtCs5pJS1yE9e7z_3std9panicking13panic_handlerNtB4_19FormatStringPayloadNtNtCs7Tc6kFxL613_5alloc9panicking12PanicPayload8take_box $_RNvXs_NvNtCs5pJS1yE9e7z_3std9panicking13panic_handlerNtB4_19FormatStringPayloadNtNtCs7Tc6kFxL613_5alloc9panicking12PanicPayload3get $_RNvYINtNvNtCs5pJS1yE9e7z_3std9panicking11begin_panic7PayloadReENtNtCs7Tc6kFxL613_5alloc9panicking12PanicPayload6as_strB9_ $_RINvNtCseWvMq1ZOdSr_4core3ptr9drop_glueNtNtCs7Tc6kFxL613_5alloc6string6StringECs5pJS1yE9e7z_3std $_RNvXs15_NtCs7Tc6kFxL613_5alloc6stringNtB6_6StringNtNtCseWvMq1ZOdSr_4core3fmt5Write9write_str $_RNvXs15_NtCs7Tc6kFxL613_5alloc6stringNtB6_6StringNtNtCseWvMq1ZOdSr_4core3fmt5Write10write_char $_RNvYNtNtCs7Tc6kFxL613_5alloc6string6StringNtNtCseWvMq1ZOdSr_4core3fmt5Write9write_fmtCs5pJS1yE9e7z_3std $_RNvXNtCseWvMq1ZOdSr_4core3anyReNtB2_3Any7type_idCs5pJS1yE9e7z_3std $_RNvXNtCseWvMq1ZOdSr_4core3anyNtNtCs7Tc6kFxL613_5alloc6string6StringNtB2_3Any7type_idCs5pJS1yE9e7z_3std $_RNvXs1i_NtCseWvMq1ZOdSr_4core3fmtReNtB6_7Display3fmtB8_)
 (export "memory" (memory $0))
 (export "run_bench" (func $run_bench))
 (export "unary_bits" (func $unary_bits))
 (func $_RNvNtCscurvdXMHcvM_14exp_experiment6kernel12standard_exp (param $0 f64) (result f64)
  (call $exp
   (local.get $0)
  )
 )
 (func $_RNvNtCscurvdXMHcvM_14exp_experiment6kernel13standard_exp2 (param $0 f64) (result f64)
  (call $exp2
   (local.get $0)
  )
 )
 (func $_RNvNtCscurvdXMHcvM_14exp_experiment6kernel7control (param $0 f64) (result f64)
  (f64.add
   (local.get $0)
   (f64.const 1)
  )
 )
 (func $run_bench (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 f64)
  (local $8 i32)
  (local $9 i64)
  (local $10 i32)
  (local $11 i32)
  (local $12 f64)
  (local $13 f64)
  (local $14 i64)
  (local $15 i64)
  (local $16 i64)
  (local $17 f64)
  (global.set $__stack_pointer
   (local.tee $5
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (call $_RNvCs9VHGBS8Gq78_7___rustc35___rust_no_alloc_shim_is_unstable_v2)
  (block $block13
   (block $block11
    (block $block
     (br_if $block
      (i32.eqz
       (local.tee $6
        (call $_RNvCs9VHGBS8Gq78_7___rustc12___rust_alloc
         (i32.const 131072)
         (i32.const 8)
        )
       )
      )
     )
     (local.set $7
      (select
       (f64.const 1)
       (f64.const 0.6931471805599453)
       (local.get $0)
      )
     )
     (local.set $8
      (i32.const 0)
     )
     (local.set $9
      (i64.const 20261030)
     )
     (local.set $10
      (i32.add
       (local.get $3)
       (i32.const -1)
      )
     )
     (local.set $11
      (local.get $6)
     )
     (loop $label
      (local.set $12
       (f64.mul
        (f64.convert_i64_u
         (i64.shr_u
          (local.tee $9
           (i64.add
            (i64.mul
             (local.get $9)
             (i64.const 6364136223846793005)
            )
            (i64.const 1442695040888963407)
           )
          )
          (i64.const 11)
         )
        )
        (f64.const 1.1102230246251565e-16)
       )
      )
      (block $block7
       (block $block5
        (block $block4
         (block $block3
          (block $block2
           (block $block1
            (block $block6
             (br_table $block1 $block2 $block3 $block4 $block5 $block6
              (local.get $10)
             )
            )
            (local.set $12
             (f64.mul
              (local.get $7)
              (f64.add
               (f64.mul
                (local.get $12)
                (f64.const 32)
               )
               (f64.const -16)
              )
             )
            )
            (br $block7)
           )
           (local.set $12
            (f64.mul
             (f64.add
              (local.get $12)
              (f64.const -0.5)
             )
             (f64.const 1e-08)
            )
           )
           (br $block7)
          )
          (local.set $12
           (f64.reinterpret_i64
            (i64.or
             (i64.or
              (i64.and
               (local.get $9)
               (i64.const 4503599627370494)
              )
              (i64.shl
               (local.get $9)
               (i64.const 63)
              )
             )
             (i64.const 1)
            )
           )
          )
          (br $block7)
         )
         (local.set $12
          (f64.mul
           (local.get $7)
           (f64.add
            (f64.mul
             (local.get $12)
             (f64.const 54)
            )
            (f64.const -1075.5)
           )
          )
         )
         (br $block7)
        )
        (local.set $12
         (f64.mul
          (local.get $7)
          (f64.add
           (select
            (f64.const -1075)
            (f64.const 1024)
            (i32.and
             (local.get $8)
             (i32.const 1)
            )
           )
           (f64.mul
            (f64.add
             (local.get $12)
             (f64.const -0.5)
            )
            (f64.const 1e-09)
           )
          )
         )
        )
        (br $block7)
       )
       (local.set $12
        (f64.load offset=1048576
         (i32.shl
          (i32.and
           (local.get $8)
           (i32.const 7)
          )
          (i32.const 3)
         )
        )
       )
      )
      (f64.store
       (local.get $11)
       (local.get $12)
      )
      (local.set $11
       (i32.add
        (local.get $11)
        (i32.const 8)
       )
      )
      (br_if $label
       (i32.ne
        (local.tee $8
         (i32.add
          (local.get $8)
          (i32.const 1)
         )
        )
        (i32.const 16384)
       )
      )
     )
     (local.set $11
      (i32.const 1)
     )
     (block $block10
      (block $block9
       (block $block8
        (br_table $block8 $block9 $block10
         (local.get $0)
        )
       )
       (local.set $11
        (select
         (select
          (i32.const 2)
          (i32.const 1)
          (i32.eq
           (local.get $1)
           (i32.const 1)
          )
         )
         (i32.const 2)
         (local.get $1)
        )
       )
       (br $block10)
      )
      (local.set $11
       (select
        (select
         (i32.const 3)
         (i32.const 1)
         (i32.eq
          (local.get $1)
          (i32.const 1)
         )
        )
        (i32.const 3)
        (local.get $1)
       )
      )
     )
     (local.set $13
      (call $_RNvNtCscurvdXMHcvM_14exp_experiment3abi8clock_ms)
     )
     (br_if $block11
      (local.get $2)
     )
     (block $block12
      (br_if $block12
       (local.get $4)
      )
      (local.set $9
       (i64.const 0)
      )
      (br $block13)
     )
     (local.set $1
      (i32.const 0)
     )
     (local.set $9
      (i64.const 0)
     )
     (local.set $14
      (i64.const 0)
     )
     (local.set $15
      (i64.const 0)
     )
     (local.set $16
      (i64.const 0)
     )
     (loop $label2
      (local.set $0
       (i32.const 0)
      )
      (loop $label1
       (f64.store offset=8
        (local.get $5)
        (f64.load
         (local.tee $10
          (i32.add
           (local.get $6)
           (local.get $0)
          )
         )
        )
       )
       (local.set $8
        (i32.add
         (local.get $5)
         (i32.const 8)
        )
       )
       (local.set $12
        (call_indirect $0 (type $1)
         (f64.load offset=8
          (local.get $5)
         )
         (local.get $11)
        )
       )
       (f64.store offset=8
        (local.get $5)
        (f64.load
         (i32.add
          (local.get $10)
          (i32.const 8)
         )
        )
       )
       (local.set $7
        (call_indirect $0 (type $1)
         (f64.load offset=8
          (local.get $5)
         )
         (local.get $11)
        )
       )
       (f64.store offset=8
        (local.get $5)
        (f64.load
         (i32.add
          (local.get $10)
          (i32.const 16)
         )
        )
       )
       (local.set $17
        (call_indirect $0 (type $1)
         (f64.load offset=8
          (local.get $5)
         )
         (local.get $11)
        )
       )
       (f64.store offset=8
        (local.get $5)
        (f64.load
         (i32.add
          (local.get $10)
          (i32.const 24)
         )
        )
       )
       (local.set $9
        (i64.add
         (local.get $9)
         (i64.reinterpret_f64
          (local.get $12)
         )
        )
       )
       (local.set $14
        (i64.add
         (local.get $14)
         (i64.reinterpret_f64
          (local.get $7)
         )
        )
       )
       (local.set $15
        (i64.add
         (local.get $15)
         (i64.reinterpret_f64
          (local.get $17)
         )
        )
       )
       (local.set $16
        (i64.add
         (local.get $16)
         (i64.reinterpret_f64
          (call_indirect $0 (type $1)
           (f64.load offset=8
            (local.get $5)
           )
           (local.get $11)
          )
         )
        )
       )
       (br_if $label1
        (i32.ne
         (local.tee $0
          (i32.add
           (local.get $0)
           (i32.const 32)
          )
         )
         (i32.const 131072)
        )
       )
      )
      (br_if $label2
       (i32.ne
        (local.tee $1
         (i32.add
          (local.get $1)
          (i32.const 1)
         )
        )
        (local.get $4)
       )
      )
     )
     (local.set $9
      (i64.add
       (i64.add
        (i64.add
         (local.get $14)
         (local.get $9)
        )
        (local.get $15)
       )
       (local.get $16)
      )
     )
     (br $block13)
    )
    (call $_RNvNtCs7Tc6kFxL613_5alloc7raw_vec12handle_error
     (i32.const 8)
     (i32.const 131072)
    )
    (unreachable)
   )
   (block $block14
    (br_if $block14
     (local.get $4)
    )
    (local.set $9
     (i64.const 0)
    )
    (br $block13)
   )
   (block $block16
    (block $block15
     (br_if $block15
      (i32.eq
       (local.get $3)
       (i32.const 5)
      )
     )
     (local.set $1
      (i32.const 0)
     )
     (local.set $9
      (i64.const 0)
     )
     (local.set $14
      (i64.const 0)
     )
     (br $block16)
    )
    (local.set $1
     (i32.const 0)
    )
    (local.set $9
     (i64.const 0)
    )
    (local.set $14
     (i64.const 0)
    )
    (loop $label4
     (local.set $10
      (i32.const 131072)
     )
     (local.set $8
      (i32.const 0)
     )
     (loop $label3
      (i64.store offset=8
       (local.get $5)
       (i64.load
        (i32.add
         (local.get $6)
         (i32.shl
          (i32.and
           (i32.add
            (local.get $8)
            (i32.and
             (i32.wrap_i64
              (i64.shr_u
               (local.get $14)
               (i64.const 52)
              )
             )
             (i32.const 15)
            )
           )
           (i32.const 16383)
          )
          (i32.const 3)
         )
        )
       )
      )
      (local.set $0
       (i32.add
        (local.get $5)
        (i32.const 8)
       )
      )
      (local.set $8
       (i32.add
        (local.get $8)
        (i32.const 1)
       )
      )
      (local.set $9
       (i64.add
        (local.get $9)
        (local.tee $14
         (i64.reinterpret_f64
          (call_indirect $0 (type $1)
           (f64.load offset=8
            (local.get $5)
           )
           (local.get $11)
          )
         )
        )
       )
      )
      (br_if $label3
       (local.tee $10
        (i32.add
         (local.get $10)
         (i32.const -8)
        )
       )
      )
     )
     (br_if $label4
      (i32.ne
       (local.tee $1
        (i32.add
         (local.get $1)
         (i32.const 1)
        )
       )
       (local.get $4)
      )
     )
     (br $block13)
    )
   )
   (loop $label6
    (local.set $8
     (i32.const 0)
    )
    (loop $label5
     (i64.store offset=8
      (local.get $5)
      (i64.xor
       (i64.load
        (local.tee $0
         (i32.add
          (local.get $6)
          (local.get $8)
         )
        )
       )
       (i64.and
        (local.get $14)
        (i64.const 255)
       )
      )
     )
     (local.set $10
      (i32.add
       (local.get $5)
       (i32.const 8)
      )
     )
     (local.set $12
      (call_indirect $0 (type $1)
       (f64.load offset=8
        (local.get $5)
       )
       (local.get $11)
      )
     )
     (i64.store offset=8
      (local.get $5)
      (i64.xor
       (i64.load
        (i32.add
         (local.get $0)
         (i32.const 8)
        )
       )
       (i64.and
        (local.tee $14
         (i64.reinterpret_f64
          (local.get $12)
         )
        )
        (i64.const 255)
       )
      )
     )
     (local.set $9
      (i64.add
       (i64.add
        (local.get $9)
        (local.get $14)
       )
       (local.tee $14
        (i64.reinterpret_f64
         (call_indirect $0 (type $1)
          (f64.load offset=8
           (local.get $5)
          )
          (local.get $11)
         )
        )
       )
      )
     )
     (br_if $label5
      (i32.ne
       (local.tee $8
        (i32.add
         (local.get $8)
         (i32.const 16)
        )
       )
       (i32.const 131072)
      )
     )
    )
    (br_if $label6
     (i32.ne
      (local.tee $1
       (i32.add
        (local.get $1)
        (i32.const 1)
       )
      )
      (local.get $4)
     )
    )
   )
  )
  (local.set $12
   (call $_RNvNtCscurvdXMHcvM_14exp_experiment3abi8clock_ms)
  )
  (i64.store offset=8
   (local.get $5)
   (local.get $9)
  )
  (local.set $11
   (i32.add
    (local.get $5)
    (i32.const 8)
   )
  )
  (local.set $9
   (i64.load offset=8
    (local.get $5)
   )
  )
  (call $_RNvCs9VHGBS8Gq78_7___rustc14___rust_dealloc
   (local.get $6)
   (i32.const 131072)
   (i32.const 8)
  )
  (call $_RNvNtCscurvdXMHcvM_14exp_experiment3abi6report
   (f64.mul
    (f64.sub
     (local.get $12)
     (local.get $13)
    )
    (f64.const 1e6)
   )
   (local.get $9)
   (i64.shl
    (i64.extend_i32_u
     (local.get $4)
    )
    (i64.const 14)
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $5)
    (i32.const 16)
   )
  )
 )
 (func $unary_bits (param $0 i32) (param $1 i32) (param $2 i64) (result i64)
  (local $3 i32)
  (local.set $3
   (i32.const 1)
  )
  (block $block2
   (block $block1
    (block $block
     (br_table $block $block1 $block2
      (local.get $0)
     )
    )
    (local.set $3
     (select
      (select
       (i32.const 2)
       (i32.const 1)
       (i32.eq
        (local.get $1)
        (i32.const 1)
       )
      )
      (i32.const 2)
      (local.get $1)
     )
    )
    (br $block2)
   )
   (local.set $3
    (select
     (select
      (i32.const 3)
      (i32.const 1)
      (i32.eq
       (local.get $1)
       (i32.const 1)
      )
     )
     (i32.const 3)
     (local.get $1)
    )
   )
  )
  (i64.reinterpret_f64
   (call_indirect $0 (type $1)
    (f64.reinterpret_i64
     (local.get $2)
    )
    (local.get $3)
   )
  )
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc12___rust_alloc (param $0 i32) (param $1 i32) (result i32)
  (return
   (call $_RNvCs9VHGBS8Gq78_7___rustc11___rdl_alloc
    (local.get $0)
    (local.get $1)
   )
  )
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc14___rust_dealloc (param $0 i32) (param $1 i32) (param $2 i32)
  (call $_RNvCs9VHGBS8Gq78_7___rustc13___rdl_dealloc
   (local.get $0)
   (local.get $1)
   (local.get $2)
  )
  (return)
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc14___rust_realloc (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (result i32)
  (return
   (call $_RNvCs9VHGBS8Gq78_7___rustc13___rdl_realloc
    (local.get $0)
    (local.get $1)
    (local.get $2)
    (local.get $3)
   )
  )
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc35___rust_no_alloc_shim_is_unstable_v2
  (return)
 )
 (func $_RINvNvMs5_NtCs7Tc6kFxL613_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs5pJS1yE9e7z_3std (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i32)
  (local $5 i32)
  (local $6 i32)
  (global.set $__stack_pointer
   (local.tee $5
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (block $block
   (br_if $block
    (i32.ge_u
     (local.tee $1
      (i32.add
       (local.get $2)
       (local.get $1)
      )
     )
     (local.get $2)
    )
   )
   (call $_RNvNtCs7Tc6kFxL613_5alloc7raw_vec12handle_error
    (i32.const 0)
    (i32.const 0)
   )
   (unreachable)
  )
  (call $_RNvMs8_NtCs7Tc6kFxL613_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs5pJS1yE9e7z_3std
   (i32.add
    (local.get $5)
    (i32.const 4)
   )
   (local.tee $2
    (i32.load
     (local.get $0)
    )
   )
   (i32.load offset=4
    (local.get $0)
   )
   (local.tee $2
    (select
     (local.tee $6
      (select
       (i32.const 8)
       (i32.const 4)
       (i32.eq
        (local.get $4)
        (i32.const 1)
       )
      )
     )
     (local.tee $2
      (select
       (local.tee $2
        (i32.shl
         (local.get $2)
         (i32.const 1)
        )
       )
       (local.get $1)
       (i32.gt_u
        (local.get $2)
        (local.get $1)
       )
      )
     )
     (i32.gt_u
      (local.get $6)
      (local.get $2)
     )
    )
   )
   (local.get $3)
   (local.get $4)
  )
  (block $block1
   (br_if $block1
    (i32.ne
     (i32.load offset=4
      (local.get $5)
     )
     (i32.const 1)
    )
   )
   (call $_RNvNtCs7Tc6kFxL613_5alloc7raw_vec12handle_error
    (i32.load offset=8
     (local.get $5)
    )
    (i32.load offset=12
     (local.get $5)
    )
   )
   (unreachable)
  )
  (local.set $4
   (i32.load offset=8
    (local.get $5)
   )
  )
  (i32.store
   (local.get $0)
   (local.get $2)
  )
  (i32.store offset=4
   (local.get $0)
   (local.get $4)
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $5)
    (i32.const 16)
   )
  )
 )
 (func $_RINvNtCseWvMq1ZOdSr_4core3ptr9drop_glueNtNtCs7Tc6kFxL613_5alloc6string6StringECs5pJS1yE9e7z_3std (param $0 i32)
  (local $1 i32)
  (block $block
   (br_if $block
    (i32.eqz
     (local.tee $1
      (i32.load
       (local.get $0)
      )
     )
    )
   )
   (call $_RNvCs9VHGBS8Gq78_7___rustc14___rust_dealloc
    (i32.load offset=4
     (local.get $0)
    )
    (local.get $1)
    (i32.const 1)
   )
  )
 )
 (func $_RINvNtCseWvMq1ZOdSr_4core3ptr9drop_glueNtNvNtCs5pJS1yE9e7z_3std9panicking13panic_handler19FormatStringPayloadEBH_ (param $0 i32)
  (local $1 i32)
  (block $block
   (br_if $block
    (i32.lt_s
     (local.tee $1
      (i32.load
       (local.get $0)
      )
     )
     (i32.const 1)
    )
   )
   (call $_RNvCs9VHGBS8Gq78_7___rustc14___rust_dealloc
    (i32.load offset=4
     (local.get $0)
    )
    (local.get $1)
    (i32.const 1)
   )
  )
 )
 (func $_RINvNtNtCs5pJS1yE9e7z_3std3sys9backtrace26___rust_end_short_backtraceNCNvNtB6_5alloc8rust_oom0zEB6_ (param $0 i32)
  (call $_RNCNvNtCs5pJS1yE9e7z_3std5alloc8rust_oom0B5_
   (local.get $0)
  )
  (unreachable)
 )
 (func $_RNCNvNtCs5pJS1yE9e7z_3std5alloc8rust_oom0B5_ (param $0 i32)
  (call_indirect $0 (type $0)
   (i32.load
    (local.get $0)
   )
   (i32.load offset=4
    (local.get $0)
   )
   (select
    (local.tee $0
     (i32.load offset=1053924
      (i32.const 0)
     )
    )
    (i32.const 4)
    (local.get $0)
   )
  )
  (unreachable)
 )
 (func $_RINvNtNtCs5pJS1yE9e7z_3std3sys9backtrace26___rust_end_short_backtraceNCNvNtB6_9panicking13panic_handler0zEB6_ (param $0 i32)
  (call $_RNCNvNtCs5pJS1yE9e7z_3std9panicking13panic_handler0B5_
   (local.get $0)
  )
  (unreachable)
 )
 (func $_RNCNvNtCs5pJS1yE9e7z_3std9panicking13panic_handler0B5_ (param $0 i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (global.set $__stack_pointer
   (local.tee $1
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (block $block
   (br_if $block
    (i32.eqz
     (i32.and
      (local.tee $3
       (i32.load offset=4
        (local.tee $2
         (i32.load
          (local.get $0)
         )
        )
       )
      )
      (i32.const 1)
     )
    )
   )
   (local.set $2
    (i32.load
     (local.get $2)
    )
   )
   (i32.store offset=4
    (local.get $1)
    (i32.shr_u
     (local.get $3)
     (i32.const 1)
    )
   )
   (i32.store
    (local.get $1)
    (local.get $2)
   )
   (call $_RNvNtCs5pJS1yE9e7z_3std9panicking15panic_with_hook
    (local.get $1)
    (i32.const 1048640)
    (i32.load offset=4
     (local.get $0)
    )
    (i32.load8_u offset=8
     (local.tee $0
      (i32.load offset=8
       (local.get $0)
      )
     )
    )
    (i32.load8_u offset=9
     (local.get $0)
    )
   )
   (unreachable)
  )
  (i32.store
   (local.get $1)
   (i32.const -1)
  )
  (i32.store offset=12
   (local.get $1)
   (local.get $0)
  )
  (call $_RNvNtCs5pJS1yE9e7z_3std9panicking15panic_with_hook
   (local.get $1)
   (i32.const 1048668)
   (i32.load offset=4
    (local.get $0)
   )
   (i32.load8_u offset=8
    (local.tee $0
     (i32.load offset=8
      (local.get $0)
     )
    )
   )
   (i32.load8_u offset=9
    (local.get $0)
   )
  )
  (unreachable)
 )
 (func $_RNvMs8_NtCs7Tc6kFxL613_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs5pJS1yE9e7z_3std (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i32) (param $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i64)
  (local.set $6
   (i32.const 1)
  )
  (local.set $7
   (i32.const 4)
  )
  (block $block1
   (block $block
    (br_if $block
     (i32.eqz
      (i32.wrap_i64
       (i64.shr_u
        (local.tee $8
         (i64.mul
          (i64.extend_i32_u
           (local.get $5)
          )
          (i64.extend_i32_u
           (local.get $3)
          )
         )
        )
        (i64.const 32)
       )
      )
     )
    )
    (local.set $3
     (i32.const 0)
    )
    (br $block1)
   )
   (block $block2
    (br_if $block2
     (i32.le_u
      (local.tee $3
       (i32.wrap_i64
        (local.get $8)
       )
      )
      (i32.sub
       (i32.const -2147483648)
       (local.get $4)
      )
     )
    )
    (local.set $3
     (i32.const 0)
    )
    (br $block1)
   )
   (block $block7
    (block $block6
     (block $block4
      (block $block3
       (br_if $block3
        (i32.eqz
         (local.get $1)
        )
       )
       (local.set $7
        (call $_RNvCs9VHGBS8Gq78_7___rustc14___rust_realloc
         (local.get $2)
         (i32.mul
          (local.get $5)
          (local.get $1)
         )
         (local.get $4)
         (local.get $3)
        )
       )
       (br $block4)
      )
      (block $block5
       (br_if $block5
        (local.get $3)
       )
       (local.set $7
        (local.get $4)
       )
       (br $block6)
      )
      (call $_RNvCs9VHGBS8Gq78_7___rustc35___rust_no_alloc_shim_is_unstable_v2)
      (local.set $7
       (call $_RNvCs9VHGBS8Gq78_7___rustc12___rust_alloc
        (local.get $3)
        (local.get $4)
       )
      )
     )
     (br_if $block6
      (local.get $7)
     )
     (i32.store offset=4
      (local.get $0)
      (local.get $4)
     )
     (br $block7)
    )
    (i32.store offset=4
     (local.get $0)
     (local.get $7)
    )
    (local.set $6
     (i32.const 0)
    )
   )
   (local.set $7
    (i32.const 8)
   )
  )
  (i32.store
   (i32.add
    (local.get $0)
    (local.get $7)
   )
   (local.get $3)
  )
  (i32.store
   (local.get $0)
   (local.get $6)
  )
 )
 (func $_RNvNtCs5pJS1yE9e7z_3std9panicking15panic_with_hook (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (param $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (global.set $__stack_pointer
   (local.tee $5
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (block $block7
   (block $block6
    (block $block3
     (block $block
      (block $block5
       (block $block4
        (block $block1
         (block $block2
          (br_table $block $block1 $block2 $block1
           (i32.and
            (call $_RNvNtNtCs5pJS1yE9e7z_3std9panicking11panic_count8increase
             (i32.const 1)
            )
            (i32.const 255)
           )
          )
         )
         (br_if $block
          (i32.le_s
           (local.tee $6
            (i32.load offset=1053928
             (i32.const 0)
            )
           )
           (i32.const -1)
          )
         )
         (br_if $block3
          (i32.lt_s
           (local.tee $7
            (i32.add
             (local.get $6)
             (i32.const 1)
            )
           )
           (local.get $6)
          )
         )
         (i32.store offset=1053928
          (i32.const 0)
          (local.get $7)
         )
         (br_if $block4
          (i32.load offset=1053932
           (i32.const 0)
          )
         )
         (i32.store offset=1053928
          (i32.const 0)
          (i32.add
           (local.get $7)
           (i32.const -1)
          )
         )
         (br $block5)
        )
        (call_indirect $0 (type $0)
         (local.get $5)
         (local.get $0)
         (i32.load offset=24
          (local.get $1)
         )
        )
        (unreachable)
       )
       (call_indirect $0 (type $0)
        (i32.add
         (local.get $5)
         (i32.const 8)
        )
        (local.get $0)
        (i32.load offset=20
         (local.get $1)
        )
       )
       (i32.store8 offset=29
        (local.get $5)
        (local.get $4)
       )
       (i32.store8 offset=28
        (local.get $5)
        (local.get $3)
       )
       (i32.store offset=24
        (local.get $5)
        (local.get $2)
       )
       (i64.store offset=16 align=4
        (local.get $5)
        (i64.load offset=8
         (local.get $5)
        )
       )
       (call_indirect $0 (type $0)
        (i32.load offset=1053932
         (i32.const 0)
        )
        (i32.add
         (local.get $5)
         (i32.const 16)
        )
        (i32.load offset=20
         (i32.load offset=1053936
          (i32.const 0)
         )
        )
       )
       (i32.store offset=1053928
        (i32.const 0)
        (i32.add
         (local.tee $5
          (i32.load offset=1053928
           (i32.const 0)
          )
         )
         (i32.const -1)
        )
       )
       (br_if $block6
        (i32.le_s
         (local.get $5)
         (i32.const 0)
        )
       )
      )
      (i32.store8 offset=1053920
       (i32.const 0)
       (i32.const 0)
      )
      (br_if $block7
       (local.get $3)
      )
     )
     (unreachable)
    )
    (call $_RNvNtCseWvMq1ZOdSr_4core6option13expect_failed
     (i32.const 1049148)
     (i32.const 28)
     (i32.const 1049176)
    )
    (unreachable)
   )
   (call $_RNvNtCseWvMq1ZOdSr_4core9panicking9panic_fmt
    (i32.const 1049224)
    (i32.const 77)
    (i32.const 1049264)
   )
   (unreachable)
  )
  (call $_RNvCs9VHGBS8Gq78_7___rustc10rust_panic
   (local.get $0)
   (local.get $1)
  )
  (unreachable)
 )
 (func $_RNvNtCs5pJS1yE9e7z_3std5alloc24default_alloc_error_hook (param $0 i32) (param $1 i32)
  (i32.store8 offset=1053944
   (i32.const 0)
   (i32.const 1)
  )
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc10rust_panic (param $0 i32) (param $1 i32)
  (drop
   (call $_RNvCs9VHGBS8Gq78_7___rustc18___rust_start_panic
    (local.get $0)
    (local.get $1)
   )
  )
  (unreachable)
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc11___rdl_alloc (param $0 i32) (param $1 i32) (result i32)
  (block $block
   (br_if $block
    (i32.lt_u
     (local.get $1)
     (i32.const 9)
    )
   )
   (return
    (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE8memalignCs5pJS1yE9e7z_3std
     (local.get $1)
     (local.get $0)
    )
   )
  )
  (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE6mallocCs5pJS1yE9e7z_3std
   (local.get $0)
  )
 )
 (func $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE8memalignCs5pJS1yE9e7z_3std (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local.set $2
   (i32.const 0)
  )
  (block $block
   (br_if $block
    (i32.ge_u
     (local.get $1)
     (i32.sub
      (select
       (local.tee $3
        (i32.add
         (i32.and
          (i32.sub
           (i32.const -48)
           (i32.load offset=1053908
            (i32.const 0)
           )
          )
          (i32.const -9)
         )
         (i32.const -3)
        )
       )
       (i32.const -64)
       (i32.lt_u
        (local.get $3)
        (i32.const -64)
       )
      )
      (local.tee $0
       (select
        (local.get $0)
        (i32.const 16)
        (i32.gt_u
         (local.get $0)
         (i32.const 16)
        )
       )
      )
     )
    )
   )
   (br_if $block
    (i32.eqz
     (local.tee $1
      (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE6mallocCs5pJS1yE9e7z_3std
       (i32.add
        (i32.add
         (local.get $0)
         (local.tee $3
          (select
           (i32.const 16)
           (i32.and
            (i32.add
             (local.get $1)
             (i32.const 11)
            )
            (i32.const -8)
           )
           (i32.lt_u
            (local.get $1)
            (i32.const 11)
           )
          )
         )
        )
        (i32.const 12)
       )
      )
     )
    )
   )
   (local.set $2
    (i32.add
     (local.get $1)
     (i32.const -8)
    )
   )
   (block $block2
    (block $block1
     (br_if $block1
      (i32.and
       (local.tee $4
        (i32.add
         (local.get $0)
         (i32.const -1)
        )
       )
       (local.get $1)
      )
     )
     (local.set $0
      (local.get $2)
     )
     (br $block2)
    )
    (local.set $4
     (i32.sub
      (i32.and
       (local.tee $6
        (i32.load
         (local.tee $5
          (i32.add
           (local.get $1)
           (i32.const -4)
          )
         )
        )
       )
       (i32.const -8)
      )
      (local.tee $1
       (i32.sub
        (local.tee $0
         (i32.add
          (local.tee $1
           (i32.add
            (i32.and
             (i32.add
              (local.get $4)
              (local.get $1)
             )
             (i32.sub
              (i32.const 0)
              (local.get $0)
             )
            )
            (i32.const -8)
           )
          )
          (select
           (i32.const 0)
           (local.get $0)
           (i32.gt_u
            (i32.sub
             (local.get $1)
             (local.get $2)
            )
            (i32.const 16)
           )
          )
         )
        )
        (local.get $2)
       )
      )
     )
    )
    (block $block3
     (br_if $block3
      (i32.eqz
       (i32.and
        (local.get $6)
        (i32.const 3)
       )
      )
     )
     (i32.store offset=4
      (local.get $0)
      (i32.or
       (i32.or
        (local.get $4)
        (i32.and
         (i32.load offset=4
          (local.get $0)
         )
         (i32.const 1)
        )
       )
       (i32.const 2)
      )
     )
     (i32.store offset=4
      (local.tee $4
       (i32.add
        (local.get $0)
        (local.get $4)
       )
      )
      (i32.or
       (i32.load offset=4
        (local.get $4)
       )
       (i32.const 1)
      )
     )
     (i32.store
      (local.get $5)
      (i32.or
       (i32.or
        (local.get $1)
        (i32.and
         (i32.load
          (local.get $5)
         )
         (i32.const 1)
        )
       )
       (i32.const 2)
      )
     )
     (i32.store offset=4
      (local.tee $4
       (i32.add
        (local.get $2)
        (local.get $1)
       )
      )
      (i32.or
       (i32.load offset=4
        (local.get $4)
       )
       (i32.const 1)
      )
     )
     (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE13dispose_chunkCs5pJS1yE9e7z_3std
      (local.get $2)
      (local.get $1)
     )
     (br $block2)
    )
    (local.set $2
     (i32.load
      (local.get $2)
     )
    )
    (i32.store offset=4
     (local.get $0)
     (local.get $4)
    )
    (i32.store
     (local.get $0)
     (i32.add
      (local.get $2)
      (local.get $1)
     )
    )
   )
   (block $block4
    (br_if $block4
     (i32.eqz
      (i32.and
       (local.tee $1
        (i32.load offset=4
         (local.get $0)
        )
       )
       (i32.const 3)
      )
     )
    )
    (br_if $block4
     (i32.le_u
      (local.tee $2
       (i32.and
        (local.get $1)
        (i32.const -8)
       )
      )
      (i32.add
       (local.get $3)
       (i32.const 16)
      )
     )
    )
    (i32.store offset=4
     (local.get $0)
     (i32.or
      (i32.or
       (local.get $3)
       (i32.and
        (local.get $1)
        (i32.const 1)
       )
      )
      (i32.const 2)
     )
    )
    (i32.store offset=4
     (local.tee $1
      (i32.add
       (local.get $0)
       (local.get $3)
      )
     )
     (i32.or
      (local.tee $3
       (i32.sub
        (local.get $2)
        (local.get $3)
       )
      )
      (i32.const 3)
     )
    )
    (i32.store offset=4
     (local.tee $2
      (i32.add
       (local.get $0)
       (local.get $2)
      )
     )
     (i32.or
      (i32.load offset=4
       (local.get $2)
      )
      (i32.const 1)
     )
    )
    (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE13dispose_chunkCs5pJS1yE9e7z_3std
     (local.get $1)
     (local.get $3)
    )
   )
   (local.set $2
    (i32.add
     (local.get $0)
     (i32.const 8)
    )
   )
  )
  (local.get $2)
 )
 (func $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE6mallocCs5pJS1yE9e7z_3std (param $0 i32) (result i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i64)
  (global.set $__stack_pointer
   (local.tee $1
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (block $block1
   (block $block2
    (block $block3
     (block $block
      (br_if $block
       (i32.lt_u
        (local.get $0)
        (i32.const 245)
       )
      )
      (local.set $2
       (i32.const 0)
      )
      (br_if $block1
       (i32.ge_u
        (local.get $0)
        (select
         (local.tee $3
          (i32.add
           (i32.and
            (i32.sub
             (i32.const -48)
             (i32.load offset=1053908
              (i32.const 0)
             )
            )
            (i32.const -9)
           )
           (i32.const -3)
          )
         )
         (i32.const -64)
         (i32.lt_u
          (local.get $3)
          (i32.const -64)
         )
        )
       )
      )
      (local.set $3
       (i32.and
        (local.tee $2
         (i32.add
          (local.get $0)
          (i32.const 11)
         )
        )
        (i32.const -8)
       )
      )
      (br_if $block2
       (i32.eqz
        (local.tee $4
         (i32.load offset=1053868
          (i32.const 0)
         )
        )
       )
      )
      (local.set $5
       (i32.const 31)
      )
      (br_if $block3
       (i32.ge_u
        (local.get $0)
        (i32.const 16777205)
       )
      )
      (local.set $5
       (i32.add
        (i32.sub
         (i32.and
          (i32.shr_u
           (local.get $3)
           (i32.sub
            (i32.const 38)
            (local.tee $0
             (i32.clz
              (i32.shr_u
               (local.get $2)
               (i32.const 8)
              )
             )
            )
           )
          )
          (i32.const 1)
         )
         (i32.shl
          (local.get $0)
          (i32.const 1)
         )
        )
        (i32.const 62)
       )
      )
      (br $block3)
     )
     (block $block13
      (block $block17
       (block $block21
        (block $block6
         (block $block5
          (block $block4
           (br_if $block4
            (i32.eqz
             (i32.and
              (local.tee $0
               (i32.shr_u
                (local.tee $6
                 (i32.load offset=1053864
                  (i32.const 0)
                 )
                )
                (local.tee $2
                 (i32.shr_u
                  (local.tee $3
                   (select
                    (i32.const 16)
                    (i32.and
                     (i32.add
                      (local.get $0)
                      (i32.const 11)
                     )
                     (i32.const 504)
                    )
                    (i32.lt_u
                     (local.get $0)
                     (i32.const 11)
                    )
                   )
                  )
                  (i32.const 3)
                 )
                )
               )
              )
              (i32.const 3)
             )
            )
           )
           (br_if $block5
            (i32.eq
             (local.tee $2
              (i32.add
               (local.tee $0
                (i32.shl
                 (local.tee $7
                  (i32.add
                   (i32.and
                    (i32.xor
                     (local.get $0)
                     (i32.const -1)
                    )
                    (i32.const 1)
                   )
                   (local.get $2)
                  )
                 )
                 (i32.const 3)
                )
               )
               (i32.const 1053600)
              )
             )
             (local.tee $8
              (i32.load offset=8
               (local.tee $3
                (i32.load
                 (i32.add
                  (local.get $0)
                  (i32.const 1053608)
                 )
                )
               )
              )
             )
            )
           )
           (i32.store offset=12
            (local.get $8)
            (local.get $2)
           )
           (i32.store offset=8
            (local.get $2)
            (local.get $8)
           )
           (br $block6)
          )
          (br_if $block2
           (i32.le_u
            (local.get $3)
            (i32.load offset=1053872
             (i32.const 0)
            )
           )
          )
          (block $block7
           (br_if $block7
            (local.get $0)
           )
           (br_if $block2
            (i32.eqz
             (local.tee $0
              (i32.load offset=1053868
               (i32.const 0)
              )
             )
            )
           )
           (local.set $2
            (i32.sub
             (i32.and
              (i32.load offset=4
               (local.tee $8
                (i32.load
                 (i32.add
                  (i32.shl
                   (i32.ctz
                    (local.get $0)
                   )
                   (i32.const 2)
                  )
                  (i32.const 1053456)
                 )
                )
               )
              )
              (i32.const -8)
             )
             (local.get $3)
            )
           )
           (local.set $6
            (local.get $8)
           )
           (block $block9
            (loop $label
             (block $block8
              (br_if $block8
               (local.tee $0
                (i32.load offset=16
                 (local.get $8)
                )
               )
              )
              (br_if $block9
               (i32.eqz
                (local.tee $0
                 (i32.load offset=20
                  (local.get $8)
                 )
                )
               )
              )
             )
             (local.set $2
              (select
               (local.tee $8
                (i32.sub
                 (i32.and
                  (i32.load offset=4
                   (local.get $0)
                  )
                  (i32.const -8)
                 )
                 (local.get $3)
                )
               )
               (local.get $2)
               (local.tee $8
                (i32.lt_u
                 (local.get $8)
                 (local.get $2)
                )
               )
              )
             )
             (local.set $6
              (select
               (local.get $0)
               (local.get $6)
               (local.get $8)
              )
             )
             (local.set $8
              (local.get $0)
             )
             (br $label)
            )
           )
           (local.set $5
            (i32.load offset=24
             (local.get $6)
            )
           )
           (block $block12
            (block $block11
             (block $block10
              (br_if $block10
               (i32.ne
                (local.get $6)
                (local.tee $0
                 (i32.load offset=12
                  (local.get $6)
                 )
                )
               )
              )
              (br_if $block11
               (local.tee $8
                (i32.load
                 (i32.add
                  (local.get $6)
                  (select
                   (i32.const 20)
                   (i32.const 16)
                   (local.tee $0
                    (i32.load offset=20
                     (local.get $6)
                    )
                   )
                  )
                 )
                )
               )
              )
              (local.set $0
               (i32.const 0)
              )
              (br $block12)
             )
             (i32.store offset=12
              (local.tee $8
               (i32.load offset=8
                (local.get $6)
               )
              )
              (local.get $0)
             )
             (i32.store offset=8
              (local.get $0)
              (local.get $8)
             )
             (br $block12)
            )
            (local.set $7
             (select
              (i32.add
               (local.get $6)
               (i32.const 20)
              )
              (i32.add
               (local.get $6)
               (i32.const 16)
              )
              (local.get $0)
             )
            )
            (loop $label1
             (local.set $9
              (local.get $7)
             )
             (local.set $7
              (select
               (i32.add
                (local.tee $0
                 (local.get $8)
                )
                (i32.const 20)
               )
               (i32.add
                (local.get $0)
                (i32.const 16)
               )
               (local.tee $8
                (i32.load offset=20
                 (local.get $0)
                )
               )
              )
             )
             (br_if $label1
              (local.tee $8
               (i32.load
                (i32.add
                 (local.get $0)
                 (select
                  (i32.const 20)
                  (i32.const 16)
                  (local.get $8)
                 )
                )
               )
              )
             )
            )
            (i32.store
             (local.get $9)
             (i32.const 0)
            )
           )
           (br_if $block13
            (i32.eqz
             (local.get $5)
            )
           )
           (block $block16
            (block $block14
             (br_if $block14
              (i32.eq
               (local.get $6)
               (i32.load
                (local.tee $8
                 (i32.add
                  (i32.shl
                   (i32.load offset=28
                    (local.get $6)
                   )
                   (i32.const 2)
                  )
                  (i32.const 1053456)
                 )
                )
               )
              )
             )
             (block $block15
              (br_if $block15
               (i32.eq
                (local.get $6)
                (i32.load offset=16
                 (local.get $5)
                )
               )
              )
              (i32.store offset=20
               (local.get $5)
               (local.get $0)
              )
              (br_if $block16
               (local.get $0)
              )
              (br $block13)
             )
             (i32.store offset=16
              (local.get $5)
              (local.get $0)
             )
             (br_if $block16
              (local.get $0)
             )
             (br $block13)
            )
            (i32.store
             (local.get $8)
             (local.get $0)
            )
            (br_if $block17
             (i32.eqz
              (local.get $0)
             )
            )
           )
           (i32.store offset=24
            (local.get $0)
            (local.get $5)
           )
           (block $block18
            (br_if $block18
             (i32.eqz
              (local.tee $8
               (i32.load offset=16
                (local.get $6)
               )
              )
             )
            )
            (i32.store offset=16
             (local.get $0)
             (local.get $8)
            )
            (i32.store offset=24
             (local.get $8)
             (local.get $0)
            )
           )
           (br_if $block13
            (i32.eqz
             (local.tee $8
              (i32.load offset=20
               (local.get $6)
              )
             )
            )
           )
           (i32.store offset=20
            (local.get $0)
            (local.get $8)
           )
           (i32.store offset=24
            (local.get $8)
            (local.get $0)
           )
           (br $block13)
          )
          (block $block20
           (block $block19
            (br_if $block19
             (i32.eq
              (local.tee $8
               (i32.add
                (local.tee $2
                 (i32.shl
                  (local.tee $9
                   (i32.ctz
                    (i32.and
                     (i32.shl
                      (local.get $0)
                      (local.get $2)
                     )
                     (i32.or
                      (local.tee $0
                       (i32.shl
                        (i32.const 2)
                        (local.get $2)
                       )
                      )
                      (i32.sub
                       (i32.const 0)
                       (local.get $0)
                      )
                     )
                    )
                   )
                  )
                  (i32.const 3)
                 )
                )
                (i32.const 1053600)
               )
              )
              (local.tee $7
               (i32.load offset=8
                (local.tee $0
                 (i32.load
                  (i32.add
                   (local.get $2)
                   (i32.const 1053608)
                  )
                 )
                )
               )
              )
             )
            )
            (i32.store offset=12
             (local.get $7)
             (local.get $8)
            )
            (i32.store offset=8
             (local.get $8)
             (local.get $7)
            )
            (br $block20)
           )
           (i32.store offset=1053864
            (i32.const 0)
            (i32.and
             (local.get $6)
             (i32.rotl
              (i32.const -2)
              (local.get $9)
             )
            )
           )
          )
          (i32.store offset=4
           (local.get $0)
           (i32.or
            (local.get $3)
            (i32.const 3)
           )
          )
          (i32.store
           (i32.add
            (local.get $0)
            (local.get $2)
           )
           (local.tee $8
            (i32.sub
             (local.get $2)
             (local.get $3)
            )
           )
          )
          (i32.store offset=4
           (local.tee $6
            (i32.add
             (local.get $0)
             (local.get $3)
            )
           )
           (i32.or
            (local.get $8)
            (i32.const 1)
           )
          )
          (br_if $block21
           (i32.eqz
            (local.tee $3
             (i32.load offset=1053872
              (i32.const 0)
             )
            )
           )
          )
          (local.set $2
           (i32.load offset=1053880
            (i32.const 0)
           )
          )
          (block $block23
           (block $block22
            (br_if $block22
             (i32.and
              (local.tee $7
               (i32.load offset=1053864
                (i32.const 0)
               )
              )
              (local.tee $9
               (i32.shl
                (i32.const 1)
                (i32.shr_u
                 (local.get $3)
                 (i32.const 3)
                )
               )
              )
             )
            )
            (i32.store offset=1053864
             (i32.const 0)
             (i32.or
              (local.get $7)
              (local.get $9)
             )
            )
            (local.set $7
             (local.tee $3
              (i32.add
               (i32.and
                (local.get $3)
                (i32.const -8)
               )
               (i32.const 1053600)
              )
             )
            )
            (br $block23)
           )
           (local.set $7
            (i32.add
             (local.tee $3
              (i32.and
               (local.get $3)
               (i32.const -8)
              )
             )
             (i32.const 1053600)
            )
           )
           (local.set $3
            (i32.load
             (i32.add
              (local.get $3)
              (i32.const 1053608)
             )
            )
           )
          )
          (i32.store offset=8
           (local.get $7)
           (local.get $2)
          )
          (i32.store offset=12
           (local.get $3)
           (local.get $2)
          )
          (i32.store offset=12
           (local.get $2)
           (local.get $7)
          )
          (i32.store offset=8
           (local.get $2)
           (local.get $3)
          )
          (br $block21)
         )
         (i32.store offset=1053864
          (i32.const 0)
          (i32.and
           (local.get $6)
           (i32.rotl
            (i32.const -2)
            (local.get $7)
           )
          )
         )
        )
        (local.set $2
         (i32.add
          (local.get $3)
          (i32.const 8)
         )
        )
        (i32.store offset=4
         (local.get $3)
         (i32.or
          (local.get $0)
          (i32.const 3)
         )
        )
        (i32.store offset=4
         (local.tee $0
          (i32.add
           (local.get $3)
           (local.get $0)
          )
         )
         (i32.or
          (i32.load offset=4
           (local.get $0)
          )
          (i32.const 1)
         )
        )
        (br $block1)
       )
       (local.set $2
        (i32.add
         (local.get $0)
         (i32.const 8)
        )
       )
       (i32.store offset=1053880
        (i32.const 0)
        (local.get $6)
       )
       (i32.store offset=1053872
        (i32.const 0)
        (local.get $8)
       )
       (br $block1)
      )
      (i32.store offset=1053868
       (i32.const 0)
       (i32.and
        (i32.load offset=1053868
         (i32.const 0)
        )
        (i32.rotl
         (i32.const -2)
         (i32.load offset=28
          (local.get $6)
         )
        )
       )
      )
     )
     (block $block28
      (block $block25
       (block $block24
        (br_if $block24
         (i32.lt_u
          (local.get $2)
          (i32.const 16)
         )
        )
        (i32.store offset=4
         (local.get $6)
         (i32.or
          (local.get $3)
          (i32.const 3)
         )
        )
        (i32.store offset=4
         (local.tee $8
          (i32.add
           (local.get $6)
           (local.get $3)
          )
         )
         (i32.or
          (local.get $2)
          (i32.const 1)
         )
        )
        (i32.store
         (i32.add
          (local.get $8)
          (local.get $2)
         )
         (local.get $2)
        )
        (br_if $block25
         (i32.eqz
          (local.tee $7
           (i32.load offset=1053872
            (i32.const 0)
           )
          )
         )
        )
        (local.set $0
         (i32.load offset=1053880
          (i32.const 0)
         )
        )
        (block $block27
         (block $block26
          (br_if $block26
           (i32.and
            (local.tee $9
             (i32.load offset=1053864
              (i32.const 0)
             )
            )
            (local.tee $5
             (i32.shl
              (i32.const 1)
              (i32.shr_u
               (local.get $7)
               (i32.const 3)
              )
             )
            )
           )
          )
          (i32.store offset=1053864
           (i32.const 0)
           (i32.or
            (local.get $9)
            (local.get $5)
           )
          )
          (local.set $9
           (local.tee $7
            (i32.add
             (i32.and
              (local.get $7)
              (i32.const -8)
             )
             (i32.const 1053600)
            )
           )
          )
          (br $block27)
         )
         (local.set $9
          (i32.add
           (local.tee $7
            (i32.and
             (local.get $7)
             (i32.const -8)
            )
           )
           (i32.const 1053600)
          )
         )
         (local.set $7
          (i32.load
           (i32.add
            (local.get $7)
            (i32.const 1053608)
           )
          )
         )
        )
        (i32.store offset=8
         (local.get $9)
         (local.get $0)
        )
        (i32.store offset=12
         (local.get $7)
         (local.get $0)
        )
        (i32.store offset=12
         (local.get $0)
         (local.get $9)
        )
        (i32.store offset=8
         (local.get $0)
         (local.get $7)
        )
        (br $block25)
       )
       (i32.store offset=4
        (local.get $6)
        (i32.or
         (local.tee $0
          (i32.add
           (local.get $2)
           (local.get $3)
          )
         )
         (i32.const 3)
        )
       )
       (i32.store offset=4
        (local.tee $0
         (i32.add
          (local.get $6)
          (local.get $0)
         )
        )
        (i32.or
         (i32.load offset=4
          (local.get $0)
         )
         (i32.const 1)
        )
       )
       (br $block28)
      )
      (i32.store offset=1053880
       (i32.const 0)
       (local.get $8)
      )
      (i32.store offset=1053872
       (i32.const 0)
       (local.get $2)
      )
     )
     (br_if $block2
      (i32.eqz
       (local.tee $2
        (i32.add
         (local.get $6)
         (i32.const 8)
        )
       )
      )
     )
     (br $block1)
    )
    (local.set $2
     (i32.sub
      (i32.const 0)
      (local.get $3)
     )
    )
    (block $block34
     (block $block32
      (block $block30
       (block $block29
        (br_if $block29
         (local.tee $6
          (i32.load
           (i32.add
            (i32.shl
             (local.get $5)
             (i32.const 2)
            )
            (i32.const 1053456)
           )
          )
         )
        )
        (local.set $8
         (i32.const 0)
        )
        (local.set $0
         (i32.const 0)
        )
        (br $block30)
       )
       (local.set $8
        (i32.const 0)
       )
       (local.set $7
        (i32.shl
         (local.get $3)
         (select
          (i32.const 0)
          (i32.sub
           (i32.const 25)
           (i32.shr_u
            (local.get $5)
            (i32.const 1)
           )
          )
          (i32.eq
           (local.get $5)
           (i32.const 31)
          )
         )
        )
       )
       (local.set $0
        (i32.const 0)
       )
       (loop $label2
        (block $block31
         (br_if $block31
          (i32.lt_u
           (local.tee $9
            (i32.and
             (i32.load offset=4
              (local.tee $6
               (local.get $6)
              )
             )
             (i32.const -8)
            )
           )
           (local.get $3)
          )
         )
         (br_if $block31
          (i32.ge_u
           (local.tee $9
            (i32.sub
             (local.get $9)
             (local.get $3)
            )
           )
           (local.get $2)
          )
         )
         (local.set $8
          (local.get $6)
         )
         (local.set $2
          (local.get $9)
         )
         (br_if $block31
          (local.get $9)
         )
         (local.set $2
          (i32.const 0)
         )
         (local.set $0
          (local.get $6)
         )
         (local.set $8
          (local.get $6)
         )
         (br $block32)
        )
        (local.set $0
         (select
          (select
           (local.tee $9
            (i32.load offset=20
             (local.get $6)
            )
           )
           (local.get $0)
           (i32.ne
            (local.get $9)
            (local.tee $6
             (i32.load offset=16
              (i32.add
               (local.get $6)
               (i32.and
                (i32.shr_u
                 (local.get $7)
                 (i32.const 29)
                )
                (i32.const 4)
               )
              )
             )
            )
           )
          )
          (local.get $0)
          (local.get $9)
         )
        )
        (local.set $7
         (i32.shl
          (local.get $7)
          (i32.const 1)
         )
        )
        (br_if $label2
         (local.get $6)
        )
       )
      )
      (block $block33
       (br_if $block33
        (i32.or
         (local.get $0)
         (local.get $8)
        )
       )
       (local.set $8
        (i32.const 0)
       )
       (br_if $block2
        (i32.eqz
         (local.tee $0
          (i32.and
           (i32.or
            (local.tee $0
             (i32.shl
              (i32.const 2)
              (local.get $5)
             )
            )
            (i32.sub
             (i32.const 0)
             (local.get $0)
            )
           )
           (local.get $4)
          )
         )
        )
       )
       (local.set $0
        (i32.load
         (i32.add
          (i32.shl
           (i32.ctz
            (local.get $0)
           )
           (i32.const 2)
          )
          (i32.const 1053456)
         )
        )
       )
      )
      (br_if $block34
       (i32.eqz
        (local.get $0)
       )
      )
     )
     (loop $label3
      (local.set $9
       (select
        (local.tee $6
         (i32.sub
          (local.tee $7
           (i32.and
            (i32.load offset=4
             (local.get $0)
            )
            (i32.const -8)
           )
          )
          (local.get $3)
         )
        )
        (local.get $2)
        (i32.lt_u
         (local.get $6)
         (local.get $2)
        )
       )
      )
      (local.set $7
       (i32.lt_u
        (local.get $7)
        (local.get $3)
       )
      )
      (local.set $5
       (select
        (local.get $8)
        (local.get $0)
        (i32.ge_u
         (local.get $6)
         (local.get $2)
        )
       )
      )
      (block $block35
       (br_if $block35
        (local.tee $6
         (i32.load offset=16
          (local.get $0)
         )
        )
       )
       (local.set $6
        (i32.load offset=20
         (local.get $0)
        )
       )
      )
      (local.set $2
       (select
        (local.get $2)
        (local.get $9)
        (local.get $7)
       )
      )
      (local.set $8
       (select
        (local.get $8)
        (local.get $5)
        (local.get $7)
       )
      )
      (local.set $0
       (local.get $6)
      )
      (br_if $label3
       (local.get $6)
      )
     )
    )
    (br_if $block2
     (i32.eqz
      (local.get $8)
     )
    )
    (block $block36
     (br_if $block36
      (i32.lt_u
       (local.tee $0
        (i32.load offset=1053872
         (i32.const 0)
        )
       )
       (local.get $3)
      )
     )
     (br_if $block2
      (i32.ge_u
       (local.get $2)
       (i32.sub
        (local.get $0)
        (local.get $3)
       )
      )
     )
    )
    (local.set $5
     (i32.load offset=24
      (local.get $8)
     )
    )
    (block $block39
     (block $block38
      (block $block37
       (br_if $block37
        (i32.ne
         (local.get $8)
         (local.tee $0
          (i32.load offset=12
           (local.get $8)
          )
         )
        )
       )
       (br_if $block38
        (local.tee $6
         (i32.load
          (i32.add
           (local.get $8)
           (select
            (i32.const 20)
            (i32.const 16)
            (local.tee $0
             (i32.load offset=20
              (local.get $8)
             )
            )
           )
          )
         )
        )
       )
       (local.set $0
        (i32.const 0)
       )
       (br $block39)
      )
      (i32.store offset=12
       (local.tee $6
        (i32.load offset=8
         (local.get $8)
        )
       )
       (local.get $0)
      )
      (i32.store offset=8
       (local.get $0)
       (local.get $6)
      )
      (br $block39)
     )
     (local.set $7
      (select
       (i32.add
        (local.get $8)
        (i32.const 20)
       )
       (i32.add
        (local.get $8)
        (i32.const 16)
       )
       (local.get $0)
      )
     )
     (loop $label4
      (local.set $9
       (local.get $7)
      )
      (local.set $7
       (select
        (i32.add
         (local.tee $0
          (local.get $6)
         )
         (i32.const 20)
        )
        (i32.add
         (local.get $0)
         (i32.const 16)
        )
        (local.tee $6
         (i32.load offset=20
          (local.get $0)
         )
        )
       )
      )
      (br_if $label4
       (local.tee $6
        (i32.load
         (i32.add
          (local.get $0)
          (select
           (i32.const 20)
           (i32.const 16)
           (local.get $6)
          )
         )
        )
       )
      )
     )
     (i32.store
      (local.get $9)
      (i32.const 0)
     )
    )
    (block $block40
     (br_if $block40
      (i32.eqz
       (local.get $5)
      )
     )
     (block $block44
      (block $block43
       (block $block41
        (br_if $block41
         (i32.eq
          (local.get $8)
          (i32.load
           (local.tee $6
            (i32.add
             (i32.shl
              (i32.load offset=28
               (local.get $8)
              )
              (i32.const 2)
             )
             (i32.const 1053456)
            )
           )
          )
         )
        )
        (block $block42
         (br_if $block42
          (i32.eq
           (local.get $8)
           (i32.load offset=16
            (local.get $5)
           )
          )
         )
         (i32.store offset=20
          (local.get $5)
          (local.get $0)
         )
         (br_if $block43
          (local.get $0)
         )
         (br $block40)
        )
        (i32.store offset=16
         (local.get $5)
         (local.get $0)
        )
        (br_if $block43
         (local.get $0)
        )
        (br $block40)
       )
       (i32.store
        (local.get $6)
        (local.get $0)
       )
       (br_if $block44
        (i32.eqz
         (local.get $0)
        )
       )
      )
      (i32.store offset=24
       (local.get $0)
       (local.get $5)
      )
      (block $block45
       (br_if $block45
        (i32.eqz
         (local.tee $6
          (i32.load offset=16
           (local.get $8)
          )
         )
        )
       )
       (i32.store offset=16
        (local.get $0)
        (local.get $6)
       )
       (i32.store offset=24
        (local.get $6)
        (local.get $0)
       )
      )
      (br_if $block40
       (i32.eqz
        (local.tee $6
         (i32.load offset=20
          (local.get $8)
         )
        )
       )
      )
      (i32.store offset=20
       (local.get $0)
       (local.get $6)
      )
      (i32.store offset=24
       (local.get $6)
       (local.get $0)
      )
      (br $block40)
     )
     (i32.store offset=1053868
      (i32.const 0)
      (i32.and
       (i32.load offset=1053868
        (i32.const 0)
       )
       (i32.rotl
        (i32.const -2)
        (i32.load offset=28
         (local.get $8)
        )
       )
      )
     )
    )
    (block $block48
     (block $block46
      (br_if $block46
       (i32.lt_u
        (local.get $2)
        (i32.const 16)
       )
      )
      (i32.store offset=4
       (local.get $8)
       (i32.or
        (local.get $3)
        (i32.const 3)
       )
      )
      (i32.store offset=4
       (local.tee $0
        (i32.add
         (local.get $8)
         (local.get $3)
        )
       )
       (i32.or
        (local.get $2)
        (i32.const 1)
       )
      )
      (i32.store
       (i32.add
        (local.get $0)
        (local.get $2)
       )
       (local.get $2)
      )
      (block $block47
       (br_if $block47
        (i32.lt_u
         (local.get $2)
         (i32.const 256)
        )
       )
       (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE18insert_large_chunkCs5pJS1yE9e7z_3std
        (local.get $0)
        (local.get $2)
       )
       (br $block48)
      )
      (block $block50
       (block $block49
        (br_if $block49
         (i32.and
          (local.tee $6
           (i32.load offset=1053864
            (i32.const 0)
           )
          )
          (local.tee $7
           (i32.shl
            (i32.const 1)
            (i32.shr_u
             (local.get $2)
             (i32.const 3)
            )
           )
          )
         )
        )
        (i32.store offset=1053864
         (i32.const 0)
         (i32.or
          (local.get $6)
          (local.get $7)
         )
        )
        (local.set $6
         (local.tee $2
          (i32.add
           (i32.and
            (local.get $2)
            (i32.const 248)
           )
           (i32.const 1053600)
          )
         )
        )
        (br $block50)
       )
       (local.set $6
        (i32.add
         (local.tee $2
          (i32.and
           (local.get $2)
           (i32.const 248)
          )
         )
         (i32.const 1053600)
        )
       )
       (local.set $2
        (i32.load
         (i32.add
          (local.get $2)
          (i32.const 1053608)
         )
        )
       )
      )
      (i32.store offset=8
       (local.get $6)
       (local.get $0)
      )
      (i32.store offset=12
       (local.get $2)
       (local.get $0)
      )
      (i32.store offset=12
       (local.get $0)
       (local.get $6)
      )
      (i32.store offset=8
       (local.get $0)
       (local.get $2)
      )
      (br $block48)
     )
     (i32.store offset=4
      (local.get $8)
      (i32.or
       (local.tee $0
        (i32.add
         (local.get $2)
         (local.get $3)
        )
       )
       (i32.const 3)
      )
     )
     (i32.store offset=4
      (local.tee $0
       (i32.add
        (local.get $8)
        (local.get $0)
       )
      )
      (i32.or
       (i32.load offset=4
        (local.get $0)
       )
       (i32.const 1)
      )
     )
    )
    (br_if $block1
     (local.tee $2
      (i32.add
       (local.get $8)
       (i32.const 8)
      )
     )
    )
   )
   (block $block71
    (block $block57
     (block $block68
      (block $block56
       (block $block65
        (block $block64
         (block $block58
          (block $block51
           (br_if $block51
            (i32.ge_u
             (local.tee $0
              (i32.load offset=1053872
               (i32.const 0)
              )
             )
             (local.get $3)
            )
           )
           (block $block52
            (br_if $block52
             (i32.gt_u
              (local.tee $0
               (i32.load offset=1053876
                (i32.const 0)
               )
              )
              (local.get $3)
             )
            )
            (local.set $2
             (i32.const 0)
            )
            (call $_RNvXs_NtCscztyJPgK1NC_8dlmalloc3sysNtB4_6SystemNtB6_9Allocator5alloc
             (i32.add
              (local.get $1)
              (i32.const 4)
             )
             (i32.const 1053916)
             (i32.and
              (i32.add
               (i32.add
                (local.get $3)
                (local.tee $0
                 (i32.load offset=1053908
                  (i32.const 0)
                 )
                )
               )
               (i32.const 47)
              )
              (i32.sub
               (i32.const 0)
               (local.get $0)
              )
             )
            )
            (br_if $block1
             (i32.eqz
              (local.tee $6
               (i32.load offset=4
                (local.get $1)
               )
              )
             )
            )
            (local.set $5
             (i32.load offset=12
              (local.get $1)
             )
            )
            (i32.store offset=1053888
             (i32.const 0)
             (local.tee $0
              (i32.add
               (i32.load offset=1053888
                (i32.const 0)
               )
               (local.tee $9
                (i32.load offset=8
                 (local.get $1)
                )
               )
              )
             )
            )
            (i32.store offset=1053892
             (i32.const 0)
             (select
              (local.tee $2
               (i32.load offset=1053892
                (i32.const 0)
               )
              )
              (local.get $0)
              (i32.gt_u
               (local.get $2)
               (local.get $0)
              )
             )
            )
            (block $block55
             (block $block54
              (block $block53
               (br_if $block53
                (i32.eqz
                 (local.tee $2
                  (i32.load offset=1053884
                   (i32.const 0)
                  )
                 )
                )
               )
               (local.set $0
                (i32.const 1053584)
               )
               (loop $label5
                (br_if $block54
                 (i32.eq
                  (local.get $6)
                  (i32.add
                   (local.tee $8
                    (i32.load
                     (local.get $0)
                    )
                   )
                   (local.tee $7
                    (i32.load offset=4
                     (local.get $0)
                    )
                   )
                  )
                 )
                )
                (br_if $label5
                 (local.tee $0
                  (i32.load offset=8
                   (local.get $0)
                  )
                 )
                )
                (br $block55)
               )
              )
              (br_if $block56
               (i32.eqz
                (local.tee $0
                 (i32.load offset=1053900
                  (i32.const 0)
                 )
                )
               )
              )
              (br_if $block56
               (i32.lt_u
                (local.get $6)
                (local.get $0)
               )
              )
              (br $block57)
             )
             (br_if $block55
              (i32.ge_u
               (local.get $2)
               (local.get $6)
              )
             )
             (br_if $block55
              (i32.gt_u
               (local.get $8)
               (local.get $2)
              )
             )
             (br_if $block55
              (i32.and
               (local.tee $8
                (i32.load offset=12
                 (local.get $0)
                )
               )
               (i32.const 1)
              )
             )
             (br_if $block58
              (i32.eq
               (local.get $5)
               (i32.shr_u
                (local.get $8)
                (i32.const 1)
               )
              )
             )
            )
            (i32.store offset=1053900
             (i32.const 0)
             (select
              (local.tee $0
               (i32.load offset=1053900
                (i32.const 0)
               )
              )
              (local.get $6)
              (i32.lt_u
               (local.get $0)
               (local.get $6)
              )
             )
            )
            (local.set $8
             (i32.add
              (local.get $6)
              (local.get $9)
             )
            )
            (local.set $0
             (i32.const 1053584)
            )
            (block $block63
             (block $block61
              (block $block60
               (block $block59
                (loop $label6
                 (br_if $block59
                  (i32.eq
                   (local.tee $7
                    (i32.load
                     (local.get $0)
                    )
                   )
                   (local.get $8)
                  )
                 )
                 (br_if $label6
                  (local.tee $0
                   (i32.load offset=8
                    (local.get $0)
                   )
                  )
                 )
                 (br $block60)
                )
               )
               (br_if $block60
                (i32.and
                 (local.tee $8
                  (i32.load offset=12
                   (local.get $0)
                  )
                 )
                 (i32.const 1)
                )
               )
               (br_if $block61
                (i32.eq
                 (local.get $5)
                 (i32.shr_u
                  (local.get $8)
                  (i32.const 1)
                 )
                )
               )
              )
              (local.set $0
               (i32.const 1053584)
              )
              (loop $label7
               (block $block62
                (br_if $block62
                 (i32.gt_u
                  (local.tee $8
                   (i32.load
                    (local.get $0)
                   )
                  )
                  (local.get $2)
                 )
                )
                (br_if $block63
                 (i32.lt_u
                  (local.get $2)
                  (local.tee $8
                   (i32.add
                    (local.get $8)
                    (i32.load offset=4
                     (local.get $0)
                    )
                   )
                  )
                 )
                )
               )
               (local.set $0
                (i32.load offset=8
                 (local.get $0)
                )
               )
               (br $label7)
              )
             )
             (i32.store
              (local.get $0)
              (local.get $6)
             )
             (i32.store offset=4
              (local.get $0)
              (i32.add
               (i32.load offset=4
                (local.get $0)
               )
               (local.get $9)
              )
             )
             (i32.store offset=4
              (local.tee $6
               (i32.add
                (i32.and
                 (i32.add
                  (local.get $6)
                  (i32.const 15)
                 )
                 (i32.const -8)
                )
                (i32.const -8)
               )
              )
              (i32.or
               (local.get $3)
               (i32.const 3)
              )
             )
             (local.set $2
              (i32.sub
               (local.tee $8
                (i32.add
                 (i32.and
                  (i32.add
                   (local.get $7)
                   (i32.const 15)
                  )
                  (i32.const -8)
                 )
                 (i32.const -8)
                )
               )
               (local.tee $0
                (i32.add
                 (local.get $6)
                 (local.get $3)
                )
               )
              )
             )
             (br_if $block64
              (i32.eq
               (local.get $8)
               (i32.load offset=1053884
                (i32.const 0)
               )
              )
             )
             (br_if $block65
              (i32.eq
               (local.get $8)
               (i32.load offset=1053880
                (i32.const 0)
               )
              )
             )
             (block $block66
              (br_if $block66
               (i32.ne
                (i32.and
                 (local.tee $3
                  (i32.load offset=4
                   (local.get $8)
                  )
                 )
                 (i32.const 3)
                )
                (i32.const 1)
               )
              )
              (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE12unlink_chunkCs5pJS1yE9e7z_3std
               (local.get $8)
               (local.tee $3
                (i32.and
                 (local.get $3)
                 (i32.const -8)
                )
               )
              )
              (local.set $2
               (i32.add
                (local.get $3)
                (local.get $2)
               )
              )
              (local.set $3
               (i32.load offset=4
                (local.tee $8
                 (i32.add
                  (local.get $8)
                  (local.get $3)
                 )
                )
               )
              )
             )
             (i32.store offset=4
              (local.get $8)
              (i32.and
               (local.get $3)
               (i32.const -2)
              )
             )
             (i32.store offset=4
              (local.get $0)
              (i32.or
               (local.get $2)
               (i32.const 1)
              )
             )
             (i32.store
              (i32.add
               (local.get $0)
               (local.get $2)
              )
              (local.get $2)
             )
             (block $block67
              (br_if $block67
               (i32.lt_u
                (local.get $2)
                (i32.const 256)
               )
              )
              (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE18insert_large_chunkCs5pJS1yE9e7z_3std
               (local.get $0)
               (local.get $2)
              )
              (br $block68)
             )
             (block $block70
              (block $block69
               (br_if $block69
                (i32.and
                 (local.tee $3
                  (i32.load offset=1053864
                   (i32.const 0)
                  )
                 )
                 (local.tee $8
                  (i32.shl
                   (i32.const 1)
                   (i32.shr_u
                    (local.get $2)
                    (i32.const 3)
                   )
                  )
                 )
                )
               )
               (i32.store offset=1053864
                (i32.const 0)
                (i32.or
                 (local.get $3)
                 (local.get $8)
                )
               )
               (local.set $3
                (local.tee $2
                 (i32.add
                  (i32.and
                   (local.get $2)
                   (i32.const 248)
                  )
                  (i32.const 1053600)
                 )
                )
               )
               (br $block70)
              )
              (local.set $3
               (i32.add
                (local.tee $2
                 (i32.and
                  (local.get $2)
                  (i32.const 248)
                 )
                )
                (i32.const 1053600)
               )
              )
              (local.set $2
               (i32.load
                (i32.add
                 (local.get $2)
                 (i32.const 1053608)
                )
               )
              )
             )
             (i32.store offset=8
              (local.get $3)
              (local.get $0)
             )
             (i32.store offset=12
              (local.get $2)
              (local.get $0)
             )
             (i32.store offset=12
              (local.get $0)
              (local.get $3)
             )
             (i32.store offset=8
              (local.get $0)
              (local.get $2)
             )
             (br $block68)
            )
            (i32.store offset=1053884
             (i32.const 0)
             (local.tee $7
              (i32.add
               (local.tee $0
                (i32.and
                 (i32.add
                  (local.get $6)
                  (i32.const 15)
                 )
                 (i32.const -8)
                )
               )
               (i32.const -8)
              )
             )
            )
            (i32.store offset=1053876
             (i32.const 0)
             (local.tee $4
              (i32.add
               (i32.add
                (i32.sub
                 (local.get $6)
                 (local.get $0)
                )
                (local.tee $0
                 (i32.add
                  (local.get $9)
                  (i32.const -40)
                 )
                )
               )
               (i32.const 8)
              )
             )
            )
            (i32.store offset=4
             (local.get $7)
             (i32.or
              (local.get $4)
              (i32.const 1)
             )
            )
            (i32.store offset=4
             (i32.add
              (local.get $6)
              (local.get $0)
             )
             (i32.const 40)
            )
            (i32.store offset=1053896
             (i32.const 0)
             (i32.const 2097152)
            )
            (i32.store offset=4
             (local.tee $7
              (select
               (local.get $2)
               (local.tee $0
                (i32.add
                 (i32.and
                  (i32.add
                   (local.get $8)
                   (i32.const -32)
                  )
                  (i32.const -8)
                 )
                 (i32.const -8)
                )
               )
               (i32.lt_u
                (local.get $0)
                (i32.add
                 (local.get $2)
                 (i32.const 16)
                )
               )
              )
             )
             (i32.const 27)
            )
            (local.set $10
             (i64.load offset=1053584 align=4
              (i32.const 0)
             )
            )
            (i64.store align=4
             (i32.add
              (local.get $7)
              (i32.const 16)
             )
             (i64.load offset=1053592 align=4
              (i32.const 0)
             )
            )
            (i64.store align=4
             (local.tee $0
              (i32.add
               (local.get $7)
               (i32.const 8)
              )
             )
             (local.get $10)
            )
            (i32.store offset=1053596
             (i32.const 0)
             (local.get $5)
            )
            (i32.store offset=1053588
             (i32.const 0)
             (local.get $9)
            )
            (i32.store offset=1053584
             (i32.const 0)
             (local.get $6)
            )
            (i32.store offset=1053592
             (i32.const 0)
             (local.get $0)
            )
            (local.set $0
             (i32.add
              (local.get $7)
              (i32.const 28)
             )
            )
            (loop $label8
             (i32.store
              (local.get $0)
              (i32.const 7)
             )
             (br_if $label8
              (i32.lt_u
               (local.tee $0
                (i32.add
                 (local.get $0)
                 (i32.const 4)
                )
               )
               (local.get $8)
              )
             )
            )
            (br_if $block71
             (i32.eq
              (local.get $2)
              (local.get $7)
             )
            )
            (i32.store offset=4
             (local.get $7)
             (i32.and
              (i32.load offset=4
               (local.get $7)
              )
              (i32.const -2)
             )
            )
            (i32.store offset=4
             (local.get $2)
             (i32.or
              (local.tee $0
               (i32.sub
                (local.get $7)
                (local.get $2)
               )
              )
              (i32.const 1)
             )
            )
            (i32.store
             (local.get $7)
             (local.get $0)
            )
            (block $block72
             (br_if $block72
              (i32.lt_u
               (local.get $0)
               (i32.const 256)
              )
             )
             (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE18insert_large_chunkCs5pJS1yE9e7z_3std
              (local.get $2)
              (local.get $0)
             )
             (br $block71)
            )
            (block $block74
             (block $block73
              (br_if $block73
               (i32.and
                (local.tee $8
                 (i32.load offset=1053864
                  (i32.const 0)
                 )
                )
                (local.tee $6
                 (i32.shl
                  (i32.const 1)
                  (i32.shr_u
                   (local.get $0)
                   (i32.const 3)
                  )
                 )
                )
               )
              )
              (i32.store offset=1053864
               (i32.const 0)
               (i32.or
                (local.get $8)
                (local.get $6)
               )
              )
              (local.set $8
               (local.tee $0
                (i32.add
                 (i32.and
                  (local.get $0)
                  (i32.const 248)
                 )
                 (i32.const 1053600)
                )
               )
              )
              (br $block74)
             )
             (local.set $8
              (i32.add
               (local.tee $0
                (i32.and
                 (local.get $0)
                 (i32.const 248)
                )
               )
               (i32.const 1053600)
              )
             )
             (local.set $0
              (i32.load
               (i32.add
                (local.get $0)
                (i32.const 1053608)
               )
              )
             )
            )
            (i32.store offset=8
             (local.get $8)
             (local.get $2)
            )
            (i32.store offset=12
             (local.get $0)
             (local.get $2)
            )
            (i32.store offset=12
             (local.get $2)
             (local.get $8)
            )
            (i32.store offset=8
             (local.get $2)
             (local.get $0)
            )
            (br $block71)
           )
           (i32.store offset=1053876
            (i32.const 0)
            (local.tee $2
             (i32.sub
              (local.get $0)
              (local.get $3)
             )
            )
           )
           (i32.store offset=1053884
            (i32.const 0)
            (local.tee $8
             (i32.add
              (local.tee $0
               (i32.load offset=1053884
                (i32.const 0)
               )
              )
              (local.get $3)
             )
            )
           )
           (i32.store offset=4
            (local.get $8)
            (i32.or
             (local.get $2)
             (i32.const 1)
            )
           )
           (i32.store offset=4
            (local.get $0)
            (i32.or
             (local.get $3)
             (i32.const 3)
            )
           )
           (local.set $2
            (i32.add
             (local.get $0)
             (i32.const 8)
            )
           )
           (br $block1)
          )
          (local.set $2
           (i32.load offset=1053880
            (i32.const 0)
           )
          )
          (block $block76
           (block $block75
            (br_if $block75
             (i32.gt_u
              (local.tee $8
               (i32.sub
                (local.get $0)
                (local.get $3)
               )
              )
              (i32.const 15)
             )
            )
            (i32.store offset=1053880
             (i32.const 0)
             (i32.const 0)
            )
            (i32.store offset=1053872
             (i32.const 0)
             (i32.const 0)
            )
            (i32.store offset=4
             (local.get $2)
             (i32.or
              (local.get $0)
              (i32.const 3)
             )
            )
            (i32.store offset=4
             (local.tee $0
              (i32.add
               (local.get $2)
               (local.get $0)
              )
             )
             (i32.or
              (i32.load offset=4
               (local.get $0)
              )
              (i32.const 1)
             )
            )
            (br $block76)
           )
           (i32.store offset=1053872
            (i32.const 0)
            (local.get $8)
           )
           (i32.store offset=1053880
            (i32.const 0)
            (local.tee $6
             (i32.add
              (local.get $2)
              (local.get $3)
             )
            )
           )
           (i32.store offset=4
            (local.get $6)
            (i32.or
             (local.get $8)
             (i32.const 1)
            )
           )
           (i32.store
            (i32.add
             (local.get $2)
             (local.get $0)
            )
            (local.get $8)
           )
           (i32.store offset=4
            (local.get $2)
            (i32.or
             (local.get $3)
             (i32.const 3)
            )
           )
          )
          (local.set $2
           (i32.add
            (local.get $2)
            (i32.const 8)
           )
          )
          (br $block1)
         )
         (i32.store offset=4
          (local.get $0)
          (i32.add
           (local.get $7)
           (local.get $9)
          )
         )
         (i32.store offset=1053884
          (i32.const 0)
          (local.tee $8
           (i32.add
            (local.tee $2
             (i32.and
              (i32.add
               (local.tee $0
                (i32.load offset=1053884
                 (i32.const 0)
                )
               )
               (i32.const 15)
              )
              (i32.const -8)
             )
            )
            (i32.const -8)
           )
          )
         )
         (i32.store offset=1053876
          (i32.const 0)
          (local.tee $6
           (i32.add
            (i32.add
             (i32.sub
              (local.get $0)
              (local.get $2)
             )
             (local.tee $2
              (i32.add
               (i32.load offset=1053876
                (i32.const 0)
               )
               (local.get $9)
              )
             )
            )
            (i32.const 8)
           )
          )
         )
         (i32.store offset=4
          (local.get $8)
          (i32.or
           (local.get $6)
           (i32.const 1)
          )
         )
         (i32.store offset=4
          (i32.add
           (local.get $0)
           (local.get $2)
          )
          (i32.const 40)
         )
         (i32.store offset=1053896
          (i32.const 0)
          (i32.const 2097152)
         )
         (br $block71)
        )
        (i32.store offset=1053884
         (i32.const 0)
         (local.get $0)
        )
        (i32.store offset=1053876
         (i32.const 0)
         (local.tee $2
          (i32.add
           (i32.load offset=1053876
            (i32.const 0)
           )
           (local.get $2)
          )
         )
        )
        (i32.store offset=4
         (local.get $0)
         (i32.or
          (local.get $2)
          (i32.const 1)
         )
        )
        (br $block68)
       )
       (i32.store offset=1053880
        (i32.const 0)
        (local.get $0)
       )
       (i32.store offset=1053872
        (i32.const 0)
        (local.tee $2
         (i32.add
          (i32.load offset=1053872
           (i32.const 0)
          )
          (local.get $2)
         )
        )
       )
       (i32.store offset=4
        (local.get $0)
        (i32.or
         (local.get $2)
         (i32.const 1)
        )
       )
       (i32.store
        (i32.add
         (local.get $0)
         (local.get $2)
        )
        (local.get $2)
       )
       (br $block68)
      )
      (i32.store offset=1053900
       (i32.const 0)
       (local.get $6)
      )
      (br $block57)
     )
     (local.set $2
      (i32.add
       (local.get $6)
       (i32.const 8)
      )
     )
     (br $block1)
    )
    (i32.store offset=1053596
     (i32.const 0)
     (local.get $5)
    )
    (i32.store offset=1053588
     (i32.const 0)
     (local.get $9)
    )
    (i32.store offset=1053584
     (i32.const 0)
     (local.get $6)
    )
    (i32.store offset=1053612
     (i32.const 0)
     (i32.const 1053600)
    )
    (i32.store offset=1053620
     (i32.const 0)
     (i32.const 1053608)
    )
    (i32.store offset=1053608
     (i32.const 0)
     (i32.const 1053600)
    )
    (i32.store offset=1053628
     (i32.const 0)
     (i32.const 1053616)
    )
    (i32.store offset=1053616
     (i32.const 0)
     (i32.const 1053608)
    )
    (i32.store offset=1053636
     (i32.const 0)
     (i32.const 1053624)
    )
    (i32.store offset=1053624
     (i32.const 0)
     (i32.const 1053616)
    )
    (i32.store offset=1053644
     (i32.const 0)
     (i32.const 1053632)
    )
    (i32.store offset=1053632
     (i32.const 0)
     (i32.const 1053624)
    )
    (i32.store offset=1053652
     (i32.const 0)
     (i32.const 1053640)
    )
    (i32.store offset=1053640
     (i32.const 0)
     (i32.const 1053632)
    )
    (i32.store offset=1053660
     (i32.const 0)
     (i32.const 1053648)
    )
    (i32.store offset=1053648
     (i32.const 0)
     (i32.const 1053640)
    )
    (i32.store offset=1053668
     (i32.const 0)
     (i32.const 1053656)
    )
    (i32.store offset=1053656
     (i32.const 0)
     (i32.const 1053648)
    )
    (i32.store offset=1053904
     (i32.const 0)
     (select
      (local.tee $0
       (i32.load offset=1053912
        (i32.const 0)
       )
      )
      (i32.const -1)
      (local.get $0)
     )
    )
    (i32.store offset=1053676
     (i32.const 0)
     (i32.const 1053664)
    )
    (i32.store offset=1053664
     (i32.const 0)
     (i32.const 1053656)
    )
    (i32.store offset=1053672
     (i32.const 0)
     (i32.const 1053664)
    )
    (i32.store offset=1053684
     (i32.const 0)
     (i32.const 1053672)
    )
    (i32.store offset=1053680
     (i32.const 0)
     (i32.const 1053672)
    )
    (i32.store offset=1053692
     (i32.const 0)
     (i32.const 1053680)
    )
    (i32.store offset=1053688
     (i32.const 0)
     (i32.const 1053680)
    )
    (i32.store offset=1053700
     (i32.const 0)
     (i32.const 1053688)
    )
    (i32.store offset=1053696
     (i32.const 0)
     (i32.const 1053688)
    )
    (i32.store offset=1053708
     (i32.const 0)
     (i32.const 1053696)
    )
    (i32.store offset=1053704
     (i32.const 0)
     (i32.const 1053696)
    )
    (i32.store offset=1053716
     (i32.const 0)
     (i32.const 1053704)
    )
    (i32.store offset=1053712
     (i32.const 0)
     (i32.const 1053704)
    )
    (i32.store offset=1053724
     (i32.const 0)
     (i32.const 1053712)
    )
    (i32.store offset=1053732
     (i32.const 0)
     (i32.const 1053720)
    )
    (i32.store offset=1053720
     (i32.const 0)
     (i32.const 1053712)
    )
    (i32.store offset=1053728
     (i32.const 0)
     (i32.const 1053720)
    )
    (i32.store offset=1053740
     (i32.const 0)
     (i32.const 1053728)
    )
    (i32.store offset=1053748
     (i32.const 0)
     (i32.const 1053736)
    )
    (i32.store offset=1053736
     (i32.const 0)
     (i32.const 1053728)
    )
    (i32.store offset=1053744
     (i32.const 0)
     (i32.const 1053736)
    )
    (i32.store offset=1053756
     (i32.const 0)
     (i32.const 1053744)
    )
    (i32.store offset=1053752
     (i32.const 0)
     (i32.const 1053744)
    )
    (i32.store offset=1053764
     (i32.const 0)
     (i32.const 1053752)
    )
    (i32.store offset=1053760
     (i32.const 0)
     (i32.const 1053752)
    )
    (i32.store offset=1053772
     (i32.const 0)
     (i32.const 1053760)
    )
    (i32.store offset=1053768
     (i32.const 0)
     (i32.const 1053760)
    )
    (i32.store offset=1053780
     (i32.const 0)
     (i32.const 1053768)
    )
    (i32.store offset=1053776
     (i32.const 0)
     (i32.const 1053768)
    )
    (i32.store offset=1053788
     (i32.const 0)
     (i32.const 1053776)
    )
    (i32.store offset=1053784
     (i32.const 0)
     (i32.const 1053776)
    )
    (i32.store offset=1053796
     (i32.const 0)
     (i32.const 1053784)
    )
    (i32.store offset=1053792
     (i32.const 0)
     (i32.const 1053784)
    )
    (i32.store offset=1053804
     (i32.const 0)
     (i32.const 1053792)
    )
    (i32.store offset=1053800
     (i32.const 0)
     (i32.const 1053792)
    )
    (i32.store offset=1053812
     (i32.const 0)
     (i32.const 1053800)
    )
    (i32.store offset=1053820
     (i32.const 0)
     (i32.const 1053808)
    )
    (i32.store offset=1053808
     (i32.const 0)
     (i32.const 1053800)
    )
    (i32.store offset=1053828
     (i32.const 0)
     (i32.const 1053816)
    )
    (i32.store offset=1053816
     (i32.const 0)
     (i32.const 1053808)
    )
    (i32.store offset=1053836
     (i32.const 0)
     (i32.const 1053824)
    )
    (i32.store offset=1053824
     (i32.const 0)
     (i32.const 1053816)
    )
    (i32.store offset=1053844
     (i32.const 0)
     (i32.const 1053832)
    )
    (i32.store offset=1053832
     (i32.const 0)
     (i32.const 1053824)
    )
    (i32.store offset=1053852
     (i32.const 0)
     (i32.const 1053840)
    )
    (i32.store offset=1053840
     (i32.const 0)
     (i32.const 1053832)
    )
    (i32.store offset=1053860
     (i32.const 0)
     (i32.const 1053848)
    )
    (i32.store offset=1053848
     (i32.const 0)
     (i32.const 1053840)
    )
    (i32.store offset=1053884
     (i32.const 0)
     (local.tee $2
      (i32.add
       (local.tee $0
        (i32.and
         (i32.add
          (local.get $6)
          (i32.const 15)
         )
         (i32.const -8)
        )
       )
       (i32.const -8)
      )
     )
    )
    (i32.store offset=1053856
     (i32.const 0)
     (i32.const 1053848)
    )
    (i32.store offset=1053876
     (i32.const 0)
     (local.tee $8
      (i32.add
       (i32.add
        (i32.sub
         (local.get $6)
         (local.get $0)
        )
        (local.tee $0
         (i32.add
          (local.get $9)
          (i32.const -40)
         )
        )
       )
       (i32.const 8)
      )
     )
    )
    (i32.store offset=4
     (local.get $2)
     (i32.or
      (local.get $8)
      (i32.const 1)
     )
    )
    (i32.store offset=4
     (i32.add
      (local.get $6)
      (local.get $0)
     )
     (i32.const 40)
    )
    (i32.store offset=1053896
     (i32.const 0)
     (i32.const 2097152)
    )
   )
   (local.set $2
    (i32.const 0)
   )
   (br_if $block1
    (i32.le_u
     (local.tee $0
      (i32.load offset=1053876
       (i32.const 0)
      )
     )
     (local.get $3)
    )
   )
   (i32.store offset=1053876
    (i32.const 0)
    (local.tee $2
     (i32.sub
      (local.get $0)
      (local.get $3)
     )
    )
   )
   (i32.store offset=1053884
    (i32.const 0)
    (local.tee $8
     (i32.add
      (local.tee $0
       (i32.load offset=1053884
        (i32.const 0)
       )
      )
      (local.get $3)
     )
    )
   )
   (i32.store offset=4
    (local.get $8)
    (i32.or
     (local.get $2)
     (i32.const 1)
    )
   )
   (i32.store offset=4
    (local.get $0)
    (i32.or
     (local.get $3)
     (i32.const 3)
    )
   )
   (local.set $2
    (i32.add
     (local.get $0)
     (i32.const 8)
    )
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $1)
    (i32.const 16)
   )
  )
  (local.get $2)
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc12___rust_abort
  (unreachable)
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc13___rdl_dealloc (param $0 i32) (param $1 i32) (param $2 i32)
  (local $3 i32)
  (local $4 i32)
  (block $block2
   (block $block
    (br_if $block
     (i32.lt_u
      (local.tee $4
       (i32.and
        (local.tee $3
         (i32.load
          (i32.add
           (local.get $0)
           (i32.const -4)
          )
         )
        )
        (i32.const -8)
       )
      )
      (i32.add
       (select
        (i32.const 4)
        (i32.const 8)
        (local.tee $3
         (i32.and
          (local.get $3)
          (i32.const 3)
         )
        )
       )
       (local.get $1)
      )
     )
    )
    (block $block1
     (br_if $block1
      (i32.eqz
       (local.get $3)
      )
     )
     (br_if $block2
      (i32.gt_u
       (local.get $4)
       (i32.add
        (local.get $1)
        (i32.const 39)
       )
      )
     )
    )
    (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE4freeCs5pJS1yE9e7z_3std
     (local.get $0)
    )
    (return)
   )
   (call $_RNvNtCseWvMq1ZOdSr_4core9panicking5panic
    (i32.const 1049005)
    (i32.const 46)
    (i32.const 1049052)
   )
   (unreachable)
  )
  (call $_RNvNtCseWvMq1ZOdSr_4core9panicking5panic
   (i32.const 1049068)
   (i32.const 46)
   (i32.const 1049116)
  )
  (unreachable)
 )
 (func $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE4freeCs5pJS1yE9e7z_3std (param $0 i32)
  (local $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local.set $3
   (i32.add
    (local.tee $1
     (i32.add
      (local.get $0)
      (i32.const -8)
     )
    )
    (local.tee $0
     (i32.and
      (local.tee $2
       (i32.load
        (i32.add
         (local.get $0)
         (i32.const -4)
        )
       )
      )
      (i32.const -8)
     )
    )
   )
  )
  (block $block1
   (block $block
    (br_if $block
     (i32.and
      (local.get $2)
      (i32.const 1)
     )
    )
    (br_if $block1
     (i32.eqz
      (i32.and
       (local.get $2)
       (i32.const 2)
      )
     )
    )
    (local.set $0
     (i32.add
      (local.tee $2
       (i32.load
        (local.get $1)
       )
      )
      (local.get $0)
     )
    )
    (block $block2
     (br_if $block2
      (i32.ne
       (local.tee $1
        (i32.sub
         (local.get $1)
         (local.get $2)
        )
       )
       (i32.load offset=1053880
        (i32.const 0)
       )
      )
     )
     (br_if $block
      (i32.ne
       (i32.and
        (i32.load offset=4
         (local.get $3)
        )
        (i32.const 3)
       )
       (i32.const 3)
      )
     )
     (i32.store offset=1053872
      (i32.const 0)
      (local.get $0)
     )
     (i32.store offset=4
      (local.get $3)
      (i32.and
       (i32.load offset=4
        (local.get $3)
       )
       (i32.const -2)
      )
     )
     (i32.store offset=4
      (local.get $1)
      (i32.or
       (local.get $0)
       (i32.const 1)
      )
     )
     (i32.store
      (local.get $3)
      (local.get $0)
     )
     (return)
    )
    (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE12unlink_chunkCs5pJS1yE9e7z_3std
     (local.get $1)
     (local.get $2)
    )
   )
   (block $block10
    (block $block11
     (block $block5
      (block $block8
       (block $block7
        (block $block4
         (block $block6
          (block $block3
           (br_if $block3
            (i32.and
             (local.tee $2
              (i32.load offset=4
               (local.get $3)
              )
             )
             (i32.const 2)
            )
           )
           (br_if $block4
            (i32.eq
             (local.get $3)
             (i32.load offset=1053884
              (i32.const 0)
             )
            )
           )
           (br_if $block5
            (i32.eq
             (local.get $3)
             (i32.load offset=1053880
              (i32.const 0)
             )
            )
           )
           (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE12unlink_chunkCs5pJS1yE9e7z_3std
            (local.get $3)
            (local.tee $2
             (i32.and
              (local.get $2)
              (i32.const -8)
             )
            )
           )
           (i32.store offset=4
            (local.get $1)
            (i32.or
             (local.tee $0
              (i32.add
               (local.get $2)
               (local.get $0)
              )
             )
             (i32.const 1)
            )
           )
           (i32.store
            (i32.add
             (local.get $1)
             (local.get $0)
            )
            (local.get $0)
           )
           (br_if $block6
            (i32.ne
             (local.get $1)
             (i32.load offset=1053880
              (i32.const 0)
             )
            )
           )
           (i32.store offset=1053872
            (i32.const 0)
            (local.get $0)
           )
           (return)
          )
          (i32.store offset=4
           (local.get $3)
           (i32.and
            (local.get $2)
            (i32.const -2)
           )
          )
          (i32.store offset=4
           (local.get $1)
           (i32.or
            (local.get $0)
            (i32.const 1)
           )
          )
          (i32.store
           (i32.add
            (local.get $1)
            (local.get $0)
           )
           (local.get $0)
          )
         )
         (br_if $block7
          (i32.lt_u
           (local.get $0)
           (i32.const 256)
          )
         )
         (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE18insert_large_chunkCs5pJS1yE9e7z_3std
          (local.get $1)
          (local.get $0)
         )
         (local.set $1
          (i32.const 0)
         )
         (i32.store offset=1053904
          (i32.const 0)
          (local.tee $0
           (i32.add
            (i32.load offset=1053904
             (i32.const 0)
            )
            (i32.const -1)
           )
          )
         )
         (br_if $block8
          (i32.eqz
           (local.get $0)
          )
         )
         (br $block1)
        )
        (i32.store offset=1053884
         (i32.const 0)
         (local.get $1)
        )
        (i32.store offset=1053876
         (i32.const 0)
         (local.tee $0
          (i32.add
           (i32.load offset=1053876
            (i32.const 0)
           )
           (local.get $0)
          )
         )
        )
        (i32.store offset=4
         (local.get $1)
         (i32.or
          (local.get $0)
          (i32.const 1)
         )
        )
        (block $block9
         (br_if $block9
          (i32.ne
           (local.get $1)
           (i32.load offset=1053880
            (i32.const 0)
           )
          )
         )
         (i32.store offset=1053872
          (i32.const 0)
          (i32.const 0)
         )
         (i32.store offset=1053880
          (i32.const 0)
          (i32.const 0)
         )
        )
        (br_if $block1
         (i32.le_u
          (local.get $0)
          (local.tee $4
           (i32.load offset=1053896
            (i32.const 0)
           )
          )
         )
        )
        (br_if $block1
         (i32.eq
          (i32.and
           (i32.sub
            (i32.const -48)
            (local.tee $1
             (i32.load offset=1053908
              (i32.const 0)
             )
            )
           )
           (i32.const -9)
          )
          (i32.const 3)
         )
        )
        (br_if $block1
         (i32.eqz
          (local.tee $0
           (i32.load offset=1053884
            (i32.const 0)
           )
          )
         )
        )
        (local.set $2
         (i32.const 0)
        )
        (br_if $block10
         (i32.lt_u
          (local.tee $5
           (i32.load offset=1053876
            (i32.const 0)
           )
          )
          (i32.const 41)
         )
        )
        (br_if $block11
         (i32.eqz
          (local.get $1)
         )
        )
        (local.set $1
         (i32.const 1053584)
        )
        (loop $label
         (block $block12
          (br_if $block12
           (i32.gt_u
            (local.tee $3
             (i32.load
              (local.get $1)
             )
            )
            (local.get $0)
           )
          )
          (br_if $block10
           (i32.lt_u
            (local.get $0)
            (i32.add
             (local.get $3)
             (i32.load offset=4
              (local.get $1)
             )
            )
           )
          )
         )
         (local.set $1
          (i32.load offset=8
           (local.get $1)
          )
         )
         (br $label)
        )
       )
       (block $block14
        (block $block13
         (br_if $block13
          (i32.and
           (local.tee $3
            (i32.load offset=1053864
             (i32.const 0)
            )
           )
           (local.tee $2
            (i32.shl
             (i32.const 1)
             (i32.shr_u
              (local.get $0)
              (i32.const 3)
             )
            )
           )
          )
         )
         (i32.store offset=1053864
          (i32.const 0)
          (i32.or
           (local.get $3)
           (local.get $2)
          )
         )
         (local.set $3
          (local.tee $0
           (i32.add
            (i32.and
             (local.get $0)
             (i32.const 248)
            )
            (i32.const 1053600)
           )
          )
         )
         (br $block14)
        )
        (local.set $3
         (i32.add
          (local.tee $0
           (i32.and
            (local.get $0)
            (i32.const 248)
           )
          )
          (i32.const 1053600)
         )
        )
        (local.set $0
         (i32.load
          (i32.add
           (local.get $0)
           (i32.const 1053608)
          )
         )
        )
       )
       (i32.store offset=8
        (local.get $3)
        (local.get $1)
       )
       (i32.store offset=12
        (local.get $0)
        (local.get $1)
       )
       (i32.store offset=12
        (local.get $1)
        (local.get $3)
       )
       (i32.store offset=8
        (local.get $1)
        (local.get $0)
       )
       (return)
      )
      (block $block15
       (br_if $block15
        (i32.eqz
         (local.tee $0
          (i32.load offset=1053592
           (i32.const 0)
          )
         )
        )
       )
       (local.set $1
        (i32.const 0)
       )
       (loop $label1
        (local.set $1
         (i32.add
          (local.get $1)
          (i32.const 1)
         )
        )
        (br_if $label1
         (local.tee $0
          (i32.load offset=8
           (local.get $0)
          )
         )
        )
       )
      )
      (i32.store offset=1053904
       (i32.const 0)
       (select
        (select
         (local.get $1)
         (local.tee $0
          (i32.load offset=1053912
           (i32.const 0)
          )
         )
         (i32.gt_u
          (local.get $1)
          (local.get $0)
         )
        )
        (i32.const -1)
        (local.get $0)
       )
      )
      (return)
     )
     (i32.store offset=1053880
      (i32.const 0)
      (local.get $1)
     )
     (i32.store offset=1053872
      (i32.const 0)
      (local.tee $0
       (i32.add
        (i32.load offset=1053872
         (i32.const 0)
        )
        (local.get $0)
       )
      )
     )
     (i32.store offset=4
      (local.get $1)
      (i32.or
       (local.get $0)
       (i32.const 1)
      )
     )
     (i32.store
      (i32.add
       (local.get $1)
       (local.get $0)
      )
      (local.get $0)
     )
     (return)
    )
    (call $_RNvNtNtCseWvMq1ZOdSr_4core9panicking11panic_const23panic_const_div_by_zero
     (i32.const 1049132)
    )
    (unreachable)
   )
   (block $block16
    (br_if $block16
     (i32.eqz
      (local.tee $1
       (i32.load offset=1053592
        (i32.const 0)
       )
      )
     )
    )
    (local.set $2
     (i32.const 0)
    )
    (loop $label2
     (local.set $2
      (i32.add
       (local.get $2)
       (i32.const 1)
      )
     )
     (br_if $label2
      (local.tee $1
       (i32.load offset=8
        (local.get $1)
       )
      )
     )
    )
   )
   (i32.store offset=1053904
    (i32.const 0)
    (select
     (select
      (local.get $2)
      (local.tee $1
       (i32.load offset=1053912
        (i32.const 0)
       )
      )
      (i32.gt_u
       (local.get $2)
       (local.get $1)
      )
     )
     (i32.const -1)
     (local.get $1)
    )
   )
   (br_if $block1
    (i32.le_u
     (local.get $5)
     (local.get $4)
    )
   )
   (i32.store offset=1053896
    (i32.const 0)
    (i32.const -1)
   )
   (return)
  )
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc13___rdl_realloc (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (result i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (block $block9
   (block $block7
    (block $block14
     (block $block16
      (block $block19
       (block $block8
        (block $block6
         (block $block2
          (block $block
           (br_if $block
            (i32.lt_u
             (local.tee $6
              (i32.and
               (local.tee $5
                (i32.load
                 (local.tee $4
                  (i32.add
                   (local.get $0)
                   (i32.const -4)
                  )
                 )
                )
               )
               (i32.const -8)
              )
             )
             (i32.add
              (select
               (i32.const 4)
               (i32.const 8)
               (local.tee $7
                (i32.and
                 (local.get $5)
                 (i32.const 3)
                )
               )
              )
              (local.get $1)
             )
            )
           )
           (local.set $8
            (i32.add
             (local.get $1)
             (i32.const 39)
            )
           )
           (block $block1
            (br_if $block1
             (i32.eqz
              (local.get $7)
             )
            )
            (br_if $block2
             (i32.gt_u
              (local.get $6)
              (local.get $8)
             )
            )
           )
           (block $block3
            (br_if $block3
             (i32.lt_u
              (local.get $2)
              (i32.const 9)
             )
            )
            (block $block4
             (br_if $block4
              (local.tee $2
               (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE8memalignCs5pJS1yE9e7z_3std
                (local.get $2)
                (local.get $3)
               )
              )
             )
             (return
              (i32.const 0)
             )
            )
            (block $block5
             (br_if $block5
              (i32.eqz
               (local.tee $3
                (select
                 (local.get $1)
                 (local.get $3)
                 (i32.lt_u
                  (local.get $1)
                  (local.get $3)
                 )
                )
               )
              )
             )
             (memory.copy
              (local.get $2)
              (local.get $0)
              (local.get $3)
             )
            )
            (br_if $block6
             (i32.lt_u
              (local.tee $7
               (i32.and
                (local.tee $3
                 (i32.load
                  (local.get $4)
                 )
                )
                (i32.const -8)
               )
              )
              (i32.add
               (select
                (i32.const 4)
                (i32.const 8)
                (local.tee $3
                 (i32.and
                  (local.get $3)
                  (i32.const 3)
                 )
                )
               )
               (local.get $1)
              )
             )
            )
            (br_if $block7
             (i32.eqz
              (local.get $3)
             )
            )
            (br_if $block8
             (i32.gt_u
              (local.get $7)
              (local.get $8)
             )
            )
            (br $block7)
           )
           (local.set $2
            (i32.const 0)
           )
           (br_if $block9
            (i32.ge_u
             (local.get $3)
             (select
              (local.tee $1
               (i32.add
                (i32.and
                 (i32.sub
                  (i32.const -48)
                  (local.tee $9
                   (i32.load offset=1053908
                    (i32.const 0)
                   )
                  )
                 )
                 (i32.const -9)
                )
                (i32.const -3)
               )
              )
              (i32.const -64)
              (i32.lt_u
               (local.get $1)
               (i32.const -64)
              )
             )
            )
           )
           (local.set $1
            (select
             (i32.const 16)
             (i32.and
              (i32.add
               (local.get $3)
               (i32.const 11)
              )
              (i32.const -8)
             )
             (i32.lt_u
              (local.get $3)
              (i32.const 11)
             )
            )
           )
           (local.set $8
            (i32.add
             (local.get $0)
             (i32.const -8)
            )
           )
           (block $block12
            (block $block11
             (block $block13
              (block $block15
               (block $block10
                (br_if $block10
                 (i32.eqz
                  (local.get $7)
                 )
                )
                (local.set $7
                 (i32.add
                  (local.get $8)
                  (local.get $6)
                 )
                )
                (br_if $block11
                 (i32.ge_u
                  (local.get $6)
                  (local.get $1)
                 )
                )
                (br_if $block12
                 (i32.eq
                  (local.get $7)
                  (i32.load offset=1053884
                   (i32.const 0)
                  )
                 )
                )
                (br_if $block13
                 (i32.eq
                  (local.get $7)
                  (i32.load offset=1053880
                   (i32.const 0)
                  )
                 )
                )
                (br_if $block14
                 (i32.and
                  (local.tee $5
                   (i32.load offset=4
                    (local.get $7)
                   )
                  )
                  (i32.const 2)
                 )
                )
                (br_if $block14
                 (i32.lt_u
                  (local.tee $5
                   (i32.add
                    (local.tee $9
                     (i32.and
                      (local.get $5)
                      (i32.const -8)
                     )
                    )
                    (local.get $6)
                   )
                  )
                  (local.get $1)
                 )
                )
                (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE12unlink_chunkCs5pJS1yE9e7z_3std
                 (local.get $7)
                 (local.get $9)
                )
                (br_if $block15
                 (i32.lt_u
                  (local.tee $7
                   (i32.sub
                    (local.get $5)
                    (local.get $1)
                   )
                  )
                  (i32.const 16)
                 )
                )
                (i32.store
                 (local.get $4)
                 (i32.or
                  (i32.or
                   (local.get $1)
                   (i32.and
                    (i32.load
                     (local.get $4)
                    )
                    (i32.const 1)
                   )
                  )
                  (i32.const 2)
                 )
                )
                (i32.store offset=4
                 (local.tee $1
                  (i32.add
                   (local.get $8)
                   (local.get $1)
                  )
                 )
                 (i32.or
                  (local.get $7)
                  (i32.const 3)
                 )
                )
                (i32.store offset=4
                 (local.tee $5
                  (i32.add
                   (local.get $8)
                   (local.get $5)
                  )
                 )
                 (i32.or
                  (i32.load offset=4
                   (local.get $5)
                  )
                  (i32.const 1)
                 )
                )
                (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE13dispose_chunkCs5pJS1yE9e7z_3std
                 (local.get $1)
                 (local.get $7)
                )
                (br $block16)
               )
               (br_if $block14
                (i32.lt_u
                 (local.get $1)
                 (i32.const 256)
                )
               )
               (br_if $block14
                (i32.le_u
                 (local.get $6)
                 (local.get $1)
                )
               )
               (br_if $block14
                (i32.eqz
                 (local.get $8)
                )
               )
               (br_if $block14
                (i32.gt_u
                 (i32.sub
                  (local.get $6)
                  (local.get $1)
                 )
                 (i32.shl
                  (local.get $9)
                  (i32.const 1)
                 )
                )
               )
               (return
                (local.get $0)
               )
              )
              (i32.store
               (local.get $4)
               (i32.or
                (i32.or
                 (local.get $5)
                 (i32.and
                  (i32.load
                   (local.get $4)
                  )
                  (i32.const 1)
                 )
                )
                (i32.const 2)
               )
              )
              (i32.store offset=4
               (local.tee $1
                (i32.add
                 (local.get $8)
                 (local.get $5)
                )
               )
               (i32.or
                (i32.load offset=4
                 (local.get $1)
                )
                (i32.const 1)
               )
              )
              (br $block16)
             )
             (br_if $block14
              (i32.lt_u
               (local.tee $7
                (i32.add
                 (i32.load offset=1053872
                  (i32.const 0)
                 )
                 (local.get $6)
                )
               )
               (local.get $1)
              )
             )
             (block $block18
              (block $block17
               (br_if $block17
                (i32.gt_u
                 (local.tee $6
                  (i32.sub
                   (local.get $7)
                   (local.get $1)
                  )
                 )
                 (i32.const 15)
                )
               )
               (i32.store
                (local.get $4)
                (i32.or
                 (i32.or
                  (i32.and
                   (local.get $5)
                   (i32.const 1)
                  )
                  (local.get $7)
                 )
                 (i32.const 2)
                )
               )
               (i32.store offset=4
                (local.tee $1
                 (i32.add
                  (local.get $8)
                  (local.get $7)
                 )
                )
                (i32.or
                 (i32.load offset=4
                  (local.get $1)
                 )
                 (i32.const 1)
                )
               )
               (local.set $6
                (i32.const 0)
               )
               (local.set $1
                (i32.const 0)
               )
               (br $block18)
              )
              (i32.store
               (local.get $4)
               (i32.or
                (i32.or
                 (local.get $1)
                 (i32.and
                  (local.get $5)
                  (i32.const 1)
                 )
                )
                (i32.const 2)
               )
              )
              (i32.store offset=4
               (local.tee $1
                (i32.add
                 (local.get $8)
                 (local.get $1)
                )
               )
               (i32.or
                (local.get $6)
                (i32.const 1)
               )
              )
              (i32.store
               (local.tee $7
                (i32.add
                 (local.get $8)
                 (local.get $7)
                )
               )
               (local.get $6)
              )
              (i32.store offset=4
               (local.get $7)
               (i32.and
                (i32.load offset=4
                 (local.get $7)
                )
                (i32.const -2)
               )
              )
             )
             (i32.store offset=1053880
              (i32.const 0)
              (local.get $1)
             )
             (i32.store offset=1053872
              (i32.const 0)
              (local.get $6)
             )
             (br $block16)
            )
            (br_if $block16
             (i32.le_u
              (local.tee $6
               (i32.sub
                (local.get $6)
                (local.get $1)
               )
              )
              (i32.const 15)
             )
            )
            (i32.store
             (local.get $4)
             (i32.or
              (i32.or
               (local.get $1)
               (i32.and
                (local.get $5)
                (i32.const 1)
               )
              )
              (i32.const 2)
             )
            )
            (i32.store offset=4
             (local.tee $1
              (i32.add
               (local.get $8)
               (local.get $1)
              )
             )
             (i32.or
              (local.get $6)
              (i32.const 3)
             )
            )
            (i32.store offset=4
             (local.get $7)
             (i32.or
              (i32.load offset=4
               (local.get $7)
              )
              (i32.const 1)
             )
            )
            (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE13dispose_chunkCs5pJS1yE9e7z_3std
             (local.get $1)
             (local.get $6)
            )
            (br $block16)
           )
           (br_if $block19
            (i32.gt_u
             (local.tee $7
              (i32.add
               (i32.load offset=1053876
                (i32.const 0)
               )
               (local.get $6)
              )
             )
             (local.get $1)
            )
           )
           (br $block14)
          )
          (call $_RNvNtCseWvMq1ZOdSr_4core9panicking5panic
           (i32.const 1049005)
           (i32.const 46)
           (i32.const 1049052)
          )
          (unreachable)
         )
         (call $_RNvNtCseWvMq1ZOdSr_4core9panicking5panic
          (i32.const 1049068)
          (i32.const 46)
          (i32.const 1049116)
         )
         (unreachable)
        )
        (call $_RNvNtCseWvMq1ZOdSr_4core9panicking5panic
         (i32.const 1049005)
         (i32.const 46)
         (i32.const 1049052)
        )
        (unreachable)
       )
       (call $_RNvNtCseWvMq1ZOdSr_4core9panicking5panic
        (i32.const 1049068)
        (i32.const 46)
        (i32.const 1049116)
       )
       (unreachable)
      )
      (i32.store
       (local.get $4)
       (i32.or
        (i32.or
         (local.get $1)
         (i32.and
          (local.get $5)
          (i32.const 1)
         )
        )
        (i32.const 2)
       )
      )
      (i32.store offset=4
       (local.tee $5
        (i32.add
         (local.get $8)
         (local.get $1)
        )
       )
       (i32.or
        (local.tee $1
         (i32.sub
          (local.get $7)
          (local.get $1)
         )
        )
        (i32.const 1)
       )
      )
      (i32.store offset=1053876
       (i32.const 0)
       (local.get $1)
      )
      (i32.store offset=1053884
       (i32.const 0)
       (local.get $5)
      )
     )
     (br_if $block14
      (i32.eqz
       (local.get $8)
      )
     )
     (return
      (local.get $0)
     )
    )
    (br_if $block9
     (i32.eqz
      (local.tee $1
       (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE6mallocCs5pJS1yE9e7z_3std
        (local.get $3)
       )
      )
     )
    )
    (block $block20
     (br_if $block20
      (local.tee $3
       (select
        (local.tee $2
         (i32.add
          (select
           (i32.const -4)
           (i32.const -8)
           (i32.and
            (local.tee $2
             (i32.load
              (local.get $4)
             )
            )
            (i32.const 3)
           )
          )
          (i32.and
           (local.get $2)
           (i32.const -8)
          )
         )
        )
        (local.get $3)
        (i32.lt_u
         (local.get $2)
         (local.get $3)
        )
       )
      )
     )
     (local.set $2
      (local.get $1)
     )
     (br $block7)
    )
    (memory.copy
     (local.get $1)
     (local.get $0)
     (local.get $3)
    )
    (local.set $2
     (local.get $1)
    )
   )
   (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE4freeCs5pJS1yE9e7z_3std
    (local.get $0)
   )
  )
  (local.get $2)
 )
 (func $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE12unlink_chunkCs5pJS1yE9e7z_3std (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local.set $2
   (i32.load offset=12
    (local.get $0)
   )
  )
  (block $block8
   (block $block4
    (block $block7
     (block $block
      (br_if $block
       (i32.lt_u
        (local.get $1)
        (i32.const 256)
       )
      )
      (local.set $3
       (i32.load offset=24
        (local.get $0)
       )
      )
      (block $block3
       (block $block2
        (block $block1
         (br_if $block1
          (i32.ne
           (local.get $0)
           (local.get $2)
          )
         )
         (br_if $block2
          (local.tee $1
           (i32.load
            (i32.add
             (local.get $0)
             (select
              (i32.const 20)
              (i32.const 16)
              (local.tee $2
               (i32.load offset=20
                (local.get $0)
               )
              )
             )
            )
           )
          )
         )
         (local.set $2
          (i32.const 0)
         )
         (br $block3)
        )
        (i32.store offset=12
         (local.tee $1
          (i32.load offset=8
           (local.get $0)
          )
         )
         (local.get $2)
        )
        (i32.store offset=8
         (local.get $2)
         (local.get $1)
        )
        (br $block3)
       )
       (local.set $4
        (select
         (i32.add
          (local.get $0)
          (i32.const 20)
         )
         (i32.add
          (local.get $0)
          (i32.const 16)
         )
         (local.get $2)
        )
       )
       (loop $label
        (local.set $5
         (local.get $4)
        )
        (local.set $4
         (select
          (i32.add
           (local.tee $2
            (local.get $1)
           )
           (i32.const 20)
          )
          (i32.add
           (local.get $2)
           (i32.const 16)
          )
          (local.tee $1
           (i32.load offset=20
            (local.get $2)
           )
          )
         )
        )
        (br_if $label
         (local.tee $1
          (i32.load
           (i32.add
            (local.get $2)
            (select
             (i32.const 20)
             (i32.const 16)
             (local.get $1)
            )
           )
          )
         )
        )
       )
       (i32.store
        (local.get $5)
        (i32.const 0)
       )
      )
      (br_if $block4
       (i32.eqz
        (local.get $3)
       )
      )
      (block $block6
       (block $block5
        (br_if $block5
         (i32.eq
          (local.get $0)
          (i32.load
           (local.tee $1
            (i32.add
             (i32.shl
              (i32.load offset=28
               (local.get $0)
              )
              (i32.const 2)
             )
             (i32.const 1053456)
            )
           )
          )
         )
        )
        (br_if $block6
         (i32.eq
          (local.get $0)
          (i32.load offset=16
           (local.get $3)
          )
         )
        )
        (i32.store offset=20
         (local.get $3)
         (local.get $2)
        )
        (br_if $block7
         (local.get $2)
        )
        (br $block4)
       )
       (i32.store
        (local.get $1)
        (local.get $2)
       )
       (br_if $block8
        (i32.eqz
         (local.get $2)
        )
       )
       (br $block7)
      )
      (i32.store offset=16
       (local.get $3)
       (local.get $2)
      )
      (br_if $block7
       (local.get $2)
      )
      (br $block4)
     )
     (block $block9
      (br_if $block9
       (i32.eq
        (local.tee $4
         (i32.load offset=8
          (local.get $0)
         )
        )
        (local.get $2)
       )
      )
      (i32.store offset=12
       (local.get $4)
       (local.get $2)
      )
      (i32.store offset=8
       (local.get $2)
       (local.get $4)
      )
      (return)
     )
     (i32.store offset=1053864
      (i32.const 0)
      (i32.and
       (i32.load offset=1053864
        (i32.const 0)
       )
       (i32.rotl
        (i32.const -2)
        (i32.shr_u
         (local.get $1)
         (i32.const 3)
        )
       )
      )
     )
     (return)
    )
    (i32.store offset=24
     (local.get $2)
     (local.get $3)
    )
    (block $block10
     (br_if $block10
      (i32.eqz
       (local.tee $1
        (i32.load offset=16
         (local.get $0)
        )
       )
      )
     )
     (i32.store offset=16
      (local.get $2)
      (local.get $1)
     )
     (i32.store offset=24
      (local.get $1)
      (local.get $2)
     )
    )
    (br_if $block4
     (i32.eqz
      (local.tee $1
       (i32.load offset=20
        (local.get $0)
       )
      )
     )
    )
    (i32.store offset=20
     (local.get $2)
     (local.get $1)
    )
    (i32.store offset=24
     (local.get $1)
     (local.get $2)
    )
    (return)
   )
   (return)
  )
  (i32.store offset=1053868
   (i32.const 0)
   (i32.and
    (i32.load offset=1053868
     (i32.const 0)
    )
    (i32.rotl
     (i32.const -2)
     (i32.load offset=28
      (local.get $0)
     )
    )
   )
  )
 )
 (func $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE13dispose_chunkCs5pJS1yE9e7z_3std (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local.set $2
   (i32.add
    (local.get $0)
    (local.get $1)
   )
  )
  (block $block5
   (block $block1
    (block $block
     (br_if $block
      (i32.and
       (local.tee $3
        (i32.load offset=4
         (local.get $0)
        )
       )
       (i32.const 1)
      )
     )
     (br_if $block1
      (i32.eqz
       (i32.and
        (local.get $3)
        (i32.const 2)
       )
      )
     )
     (local.set $1
      (i32.add
       (local.tee $3
        (i32.load
         (local.get $0)
        )
       )
       (local.get $1)
      )
     )
     (block $block2
      (br_if $block2
       (i32.ne
        (local.tee $0
         (i32.sub
          (local.get $0)
          (local.get $3)
         )
        )
        (i32.load offset=1053880
         (i32.const 0)
        )
       )
      )
      (br_if $block
       (i32.ne
        (i32.and
         (i32.load offset=4
          (local.get $2)
         )
         (i32.const 3)
        )
        (i32.const 3)
       )
      )
      (i32.store offset=1053872
       (i32.const 0)
       (local.get $1)
      )
      (i32.store offset=4
       (local.get $2)
       (i32.and
        (i32.load offset=4
         (local.get $2)
        )
        (i32.const -2)
       )
      )
      (i32.store offset=4
       (local.get $0)
       (i32.or
        (local.get $1)
        (i32.const 1)
       )
      )
      (i32.store
       (local.get $2)
       (local.get $1)
      )
      (return)
     )
     (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE12unlink_chunkCs5pJS1yE9e7z_3std
      (local.get $0)
      (local.get $3)
     )
    )
    (block $block4
     (block $block6
      (block $block3
       (br_if $block3
        (i32.and
         (local.tee $3
          (i32.load offset=4
           (local.get $2)
          )
         )
         (i32.const 2)
        )
       )
       (br_if $block4
        (i32.eq
         (local.get $2)
         (i32.load offset=1053884
          (i32.const 0)
         )
        )
       )
       (br_if $block5
        (i32.eq
         (local.get $2)
         (i32.load offset=1053880
          (i32.const 0)
         )
        )
       )
       (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE12unlink_chunkCs5pJS1yE9e7z_3std
        (local.get $2)
        (local.tee $3
         (i32.and
          (local.get $3)
          (i32.const -8)
         )
        )
       )
       (i32.store offset=4
        (local.get $0)
        (i32.or
         (local.tee $1
          (i32.add
           (local.get $3)
           (local.get $1)
          )
         )
         (i32.const 1)
        )
       )
       (i32.store
        (i32.add
         (local.get $0)
         (local.get $1)
        )
        (local.get $1)
       )
       (br_if $block6
        (i32.ne
         (local.get $0)
         (i32.load offset=1053880
          (i32.const 0)
         )
        )
       )
       (i32.store offset=1053872
        (i32.const 0)
        (local.get $1)
       )
       (return)
      )
      (i32.store offset=4
       (local.get $2)
       (i32.and
        (local.get $3)
        (i32.const -2)
       )
      )
      (i32.store offset=4
       (local.get $0)
       (i32.or
        (local.get $1)
        (i32.const 1)
       )
      )
      (i32.store
       (i32.add
        (local.get $0)
        (local.get $1)
       )
       (local.get $1)
      )
     )
     (block $block7
      (br_if $block7
       (i32.lt_u
        (local.get $1)
        (i32.const 256)
       )
      )
      (call $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE18insert_large_chunkCs5pJS1yE9e7z_3std
       (local.get $0)
       (local.get $1)
      )
      (return)
     )
     (block $block9
      (block $block8
       (br_if $block8
        (i32.and
         (local.tee $2
          (i32.load offset=1053864
           (i32.const 0)
          )
         )
         (local.tee $3
          (i32.shl
           (i32.const 1)
           (i32.shr_u
            (local.get $1)
            (i32.const 3)
           )
          )
         )
        )
       )
       (i32.store offset=1053864
        (i32.const 0)
        (i32.or
         (local.get $2)
         (local.get $3)
        )
       )
       (local.set $2
        (local.tee $1
         (i32.add
          (i32.and
           (local.get $1)
           (i32.const 248)
          )
          (i32.const 1053600)
         )
        )
       )
       (br $block9)
      )
      (local.set $2
       (i32.add
        (local.tee $1
         (i32.and
          (local.get $1)
          (i32.const 248)
         )
        )
        (i32.const 1053600)
       )
      )
      (local.set $1
       (i32.load
        (i32.add
         (local.get $1)
         (i32.const 1053608)
        )
       )
      )
     )
     (i32.store offset=8
      (local.get $2)
      (local.get $0)
     )
     (i32.store offset=12
      (local.get $1)
      (local.get $0)
     )
     (i32.store offset=12
      (local.get $0)
      (local.get $2)
     )
     (i32.store offset=8
      (local.get $0)
      (local.get $1)
     )
     (return)
    )
    (i32.store offset=1053884
     (i32.const 0)
     (local.get $0)
    )
    (i32.store offset=1053876
     (i32.const 0)
     (local.tee $1
      (i32.add
       (i32.load offset=1053876
        (i32.const 0)
       )
       (local.get $1)
      )
     )
    )
    (i32.store offset=4
     (local.get $0)
     (i32.or
      (local.get $1)
      (i32.const 1)
     )
    )
    (br_if $block1
     (i32.ne
      (local.get $0)
      (i32.load offset=1053880
       (i32.const 0)
      )
     )
    )
    (i32.store offset=1053872
     (i32.const 0)
     (i32.const 0)
    )
    (i32.store offset=1053880
     (i32.const 0)
     (i32.const 0)
    )
   )
   (return)
  )
  (i32.store offset=1053880
   (i32.const 0)
   (local.get $0)
  )
  (i32.store offset=1053872
   (i32.const 0)
   (local.tee $1
    (i32.add
     (i32.load offset=1053872
      (i32.const 0)
     )
     (local.get $1)
    )
   )
  )
  (i32.store offset=4
   (local.get $0)
   (i32.or
    (local.get $1)
    (i32.const 1)
   )
  )
  (i32.store
   (i32.add
    (local.get $0)
    (local.get $1)
   )
   (local.get $1)
  )
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc17rust_begin_unwind (param $0 i32)
  (local $1 i32)
  (local $2 i64)
  (global.set $__stack_pointer
   (local.tee $1
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (local.set $2
   (i64.load align=4
    (local.get $0)
   )
  )
  (i32.store offset=12
   (local.get $1)
   (local.get $0)
  )
  (i64.store offset=4 align=4
   (local.get $1)
   (local.get $2)
  )
  (call $_RINvNtNtCs5pJS1yE9e7z_3std3sys9backtrace26___rust_end_short_backtraceNCNvNtB6_9panicking13panic_handler0zEB6_
   (i32.add
    (local.get $1)
    (i32.const 4)
   )
  )
  (unreachable)
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc26___rust_alloc_error_handler (param $0 i32) (param $1 i32)
  (call $_RNvNtCs5pJS1yE9e7z_3std5alloc8rust_oom
   (local.get $1)
   (local.get $0)
  )
  (unreachable)
 )
 (func $_RNvNtCs5pJS1yE9e7z_3std5alloc8rust_oom (param $0 i32) (param $1 i32)
  (local $2 i32)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (i32.store offset=12
   (local.get $2)
   (local.get $1)
  )
  (i32.store offset=8
   (local.get $2)
   (local.get $0)
  )
  (call $_RINvNtNtCs5pJS1yE9e7z_3std3sys9backtrace26___rust_end_short_backtraceNCNvNtB6_5alloc8rust_oom0zEB6_
   (i32.add
    (local.get $2)
    (i32.const 8)
   )
  )
  (unreachable)
 )
 (func $_RNvMs0_NtCscztyJPgK1NC_8dlmalloc8dlmallocINtB5_8DlmallocNtNtB7_3sys6SystemE18insert_large_chunkCs5pJS1yE9e7z_3std (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local.set $2
   (i32.const 0)
  )
  (block $block
   (br_if $block
    (i32.eqz
     (local.tee $3
      (i32.shr_u
       (local.get $1)
       (i32.const 8)
      )
     )
    )
   )
   (local.set $2
    (i32.const 31)
   )
   (br_if $block
    (i32.ge_u
     (local.get $1)
     (i32.const 16777216)
    )
   )
   (local.set $2
    (i32.xor
     (i32.or
      (i32.and
       (i32.shr_u
        (local.get $1)
        (i32.sub
         (i32.const 38)
         (local.tee $2
          (i32.clz
           (local.get $3)
          )
         )
        )
       )
       (i32.const 1)
      )
      (i32.shl
       (local.get $2)
       (i32.const 1)
      )
     )
     (i32.const 62)
    )
   )
  )
  (i64.store offset=16 align=4
   (local.get $0)
   (i64.const 0)
  )
  (i32.store offset=28
   (local.get $0)
   (local.get $2)
  )
  (local.set $3
   (i32.add
    (i32.shl
     (local.get $2)
     (i32.const 2)
    )
    (i32.const 1053456)
   )
  )
  (block $block1
   (br_if $block1
    (i32.and
     (i32.load offset=1053868
      (i32.const 0)
     )
     (local.tee $4
      (i32.shl
       (i32.const 1)
       (local.get $2)
      )
     )
    )
   )
   (i32.store
    (local.get $3)
    (local.get $0)
   )
   (i32.store offset=24
    (local.get $0)
    (local.get $3)
   )
   (i32.store offset=12
    (local.get $0)
    (local.get $0)
   )
   (i32.store offset=8
    (local.get $0)
    (local.get $0)
   )
   (i32.store offset=1053868
    (i32.const 0)
    (i32.or
     (i32.load offset=1053868
      (i32.const 0)
     )
     (local.get $4)
    )
   )
   (return)
  )
  (block $block4
   (block $block3
    (block $block2
     (br_if $block2
      (i32.ne
       (local.get $1)
       (i32.and
        (i32.load offset=4
         (local.tee $4
          (i32.load
           (local.get $3)
          )
         )
        )
        (i32.const -8)
       )
      )
     )
     (local.set $2
      (local.get $4)
     )
     (br $block3)
    )
    (local.set $3
     (i32.shl
      (local.get $1)
      (select
       (i32.const 0)
       (i32.sub
        (i32.const 25)
        (i32.shr_u
         (local.get $2)
         (i32.const 1)
        )
       )
       (i32.eq
        (local.get $2)
        (i32.const 31)
       )
      )
     )
    )
    (loop $label
     (br_if $block4
      (i32.eqz
       (local.tee $2
        (i32.load offset=16
         (local.tee $5
          (i32.add
           (local.get $4)
           (i32.and
            (i32.shr_u
             (local.get $3)
             (i32.const 29)
            )
            (i32.const 4)
           )
          )
         )
        )
       )
      )
     )
     (local.set $3
      (i32.shl
       (local.get $3)
       (i32.const 1)
      )
     )
     (local.set $4
      (local.get $2)
     )
     (br_if $label
      (i32.ne
       (local.get $1)
       (i32.and
        (i32.load offset=4
         (local.get $2)
        )
        (i32.const -8)
       )
      )
     )
    )
   )
   (i32.store offset=12
    (local.tee $3
     (i32.load offset=8
      (local.get $2)
     )
    )
    (local.get $0)
   )
   (i32.store offset=8
    (local.get $2)
    (local.get $0)
   )
   (i32.store offset=24
    (local.get $0)
    (i32.const 0)
   )
   (i32.store offset=12
    (local.get $0)
    (local.get $2)
   )
   (i32.store offset=8
    (local.get $0)
    (local.get $3)
   )
   (return)
  )
  (i32.store
   (i32.add
    (local.get $5)
    (i32.const 16)
   )
   (local.get $0)
  )
  (i32.store offset=24
   (local.get $0)
   (local.get $4)
  )
  (i32.store offset=12
   (local.get $0)
   (local.get $0)
  )
  (i32.store offset=8
   (local.get $0)
   (local.get $0)
  )
 )
 (func $_RNvNtNtCs5pJS1yE9e7z_3std9panicking11panic_count8increase (param $0 i32) (result i32)
  (local $1 i32)
  (local $2 i32)
  (local.set $1
   (i32.const 0)
  )
  (i32.store offset=1053940
   (i32.const 0)
   (i32.add
    (local.tee $2
     (i32.load offset=1053940
      (i32.const 0)
     )
    )
    (i32.const 1)
   )
  )
  (block $block
   (br_if $block
    (i32.lt_s
     (local.get $2)
     (i32.const 0)
    )
   )
   (local.set $1
    (i32.const 1)
   )
   (br_if $block
    (i32.load8_u offset=1053920
     (i32.const 0)
    )
   )
   (i32.store8 offset=1053920
    (i32.const 0)
    (local.get $0)
   )
   (i32.store offset=1053916
    (i32.const 0)
    (i32.add
     (i32.load offset=1053916
      (i32.const 0)
     )
     (i32.const 1)
    )
   )
   (local.set $1
    (i32.const 2)
   )
  )
  (local.get $1)
 )
 (func $_RNvXNtCseWvMq1ZOdSr_4core3anyNtNtCs7Tc6kFxL613_5alloc6string6StringNtB2_3Any7type_idCs5pJS1yE9e7z_3std (param $0 i32) (param $1 i32)
  (i64.store offset=8 align=4
   (local.get $0)
   (i64.load offset=1048720 align=4
    (i32.const 0)
   )
  )
  (i64.store align=4
   (local.get $0)
   (i64.load offset=1048712 align=4
    (i32.const 0)
   )
  )
 )
 (func $_RNvXNtCseWvMq1ZOdSr_4core3anyReNtB2_3Any7type_idCs5pJS1yE9e7z_3std (param $0 i32) (param $1 i32)
  (i64.store offset=8 align=4
   (local.get $0)
   (i64.load offset=1048704 align=4
    (i32.const 0)
   )
  )
  (i64.store align=4
   (local.get $0)
   (i64.load offset=1048696 align=4
    (i32.const 0)
   )
  )
 )
 (func $_RNvXs0_NvNtCs5pJS1yE9e7z_3std9panicking13panic_handlerNtB5_19FormatStringPayloadNtNtCseWvMq1ZOdSr_4core3fmt7Display3fmt (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (block $block
   (br_if $block
    (i32.eq
     (i32.load
      (local.get $0)
     )
     (i32.const -1)
    )
   )
   (return
    (call $_RNvMsa_NtCseWvMq1ZOdSr_4core3fmtNtB5_9Formatter9write_str
     (local.get $1)
     (i32.load offset=4
      (local.get $0)
     )
     (i32.load offset=8
      (local.get $0)
     )
    )
   )
  )
  (local.set $2
   (i32.load offset=4
    (local.get $1)
   )
  )
  (local.set $1
   (i32.load
    (local.get $1)
   )
  )
  (local.set $3
   (i32.load
    (local.tee $0
     (i32.load
      (i32.load offset=12
       (local.get $0)
      )
     )
    )
   )
  )
  (block $block1
   (br_if $block1
    (i32.eqz
     (i32.and
      (local.tee $0
       (i32.load offset=4
        (local.get $0)
       )
      )
      (i32.const 1)
     )
    )
   )
   (return
    (call_indirect $0 (type $3)
     (local.get $1)
     (local.get $3)
     (i32.shr_u
      (local.get $0)
      (i32.const 1)
     )
     (i32.load offset=12
      (local.get $2)
     )
    )
   )
  )
  (call $_RNvNtCseWvMq1ZOdSr_4core3fmt5write
   (local.get $1)
   (local.get $2)
   (local.get $3)
   (local.get $0)
  )
 )
 (func $_RNvXs15_NtCs7Tc6kFxL613_5alloc6stringNtB6_6StringNtNtCseWvMq1ZOdSr_4core3fmt5Write10write_char (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local.set $2
   (i32.load offset=8
    (local.get $0)
   )
  )
  (block $block1
   (block $block
    (br_if $block
     (i32.ge_u
      (local.get $1)
      (i32.const 128)
     )
    )
    (local.set $3
     (i32.const 1)
    )
    (br $block1)
   )
   (block $block2
    (br_if $block2
     (i32.ge_u
      (local.get $1)
      (i32.const 2048)
     )
    )
    (local.set $3
     (i32.const 2)
    )
    (br $block1)
   )
   (local.set $3
    (select
     (i32.const 3)
     (i32.const 4)
     (i32.lt_u
      (local.get $1)
      (i32.const 65536)
     )
    )
   )
  )
  (block $block3
   (br_if $block3
    (i32.le_u
     (local.get $3)
     (i32.sub
      (i32.load
       (local.get $0)
      )
      (local.get $2)
     )
    )
   )
   (call $_RINvNvMs5_NtCs7Tc6kFxL613_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs5pJS1yE9e7z_3std
    (local.get $0)
    (local.get $2)
    (local.get $3)
    (i32.const 1)
    (i32.const 1)
   )
  )
  (local.set $4
   (i32.add
    (i32.load offset=4
     (local.get $0)
    )
    (local.get $2)
   )
  )
  (block $block6
   (block $block4
    (br_if $block4
     (i32.lt_u
      (local.get $1)
      (i32.const 128)
     )
    )
    (local.set $5
     (i32.or
      (i32.and
       (local.get $1)
       (i32.const 63)
      )
      (i32.const -128)
     )
    )
    (local.set $6
     (i32.shr_u
      (local.get $1)
      (i32.const 6)
     )
    )
    (block $block5
     (br_if $block5
      (i32.ge_u
       (local.get $1)
       (i32.const 2048)
      )
     )
     (i32.store8 offset=1
      (local.get $4)
      (local.get $5)
     )
     (i32.store8
      (local.get $4)
      (i32.or
       (local.get $6)
       (i32.const 192)
      )
     )
     (br $block6)
    )
    (local.set $7
     (i32.shr_u
      (local.get $1)
      (i32.const 12)
     )
    )
    (local.set $6
     (i32.or
      (i32.and
       (local.get $6)
       (i32.const 63)
      )
      (i32.const -128)
     )
    )
    (block $block7
     (br_if $block7
      (i32.gt_u
       (local.get $1)
       (i32.const 65535)
      )
     )
     (i32.store8 offset=2
      (local.get $4)
      (local.get $5)
     )
     (i32.store8 offset=1
      (local.get $4)
      (local.get $6)
     )
     (i32.store8
      (local.get $4)
      (i32.or
       (local.get $7)
       (i32.const 224)
      )
     )
     (br $block6)
    )
    (i32.store8 offset=3
     (local.get $4)
     (local.get $5)
    )
    (i32.store8 offset=2
     (local.get $4)
     (local.get $6)
    )
    (i32.store8 offset=1
     (local.get $4)
     (i32.or
      (i32.and
       (local.get $7)
       (i32.const 63)
      )
      (i32.const -128)
     )
    )
    (i32.store8
     (local.get $4)
     (i32.or
      (i32.shr_u
       (local.get $1)
       (i32.const 18)
      )
      (i32.const -16)
     )
    )
    (br $block6)
   )
   (i32.store8
    (local.get $4)
    (local.get $1)
   )
  )
  (i32.store offset=8
   (local.get $0)
   (i32.add
    (local.get $3)
    (local.get $2)
   )
  )
  (i32.const 0)
 )
 (func $_RNvXs15_NtCs7Tc6kFxL613_5alloc6stringNtB6_6StringNtNtCseWvMq1ZOdSr_4core3fmt5Write9write_str (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (local $3 i32)
  (block $block2
   (block $block1
    (block $block
     (br_if $block
      (i32.le_u
       (local.get $2)
       (i32.sub
        (i32.load
         (local.get $0)
        )
        (local.tee $3
         (i32.load offset=8
          (local.get $0)
         )
        )
       )
      )
     )
     (call $_RINvNvMs5_NtCs7Tc6kFxL613_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs5pJS1yE9e7z_3std
      (local.get $0)
      (local.get $3)
      (local.get $2)
      (i32.const 1)
      (i32.const 1)
     )
     (local.set $3
      (i32.load offset=8
       (local.get $0)
      )
     )
     (br $block1)
    )
    (br_if $block2
     (i32.eqz
      (local.get $2)
     )
    )
   )
   (br_if $block2
    (i32.eqz
     (local.get $2)
    )
   )
   (memory.copy
    (i32.add
     (i32.load offset=4
      (local.get $0)
     )
     (local.get $3)
    )
    (local.get $1)
    (local.get $2)
   )
  )
  (i32.store offset=8
   (local.get $0)
   (i32.add
    (local.get $3)
    (local.get $2)
   )
  )
  (i32.const 0)
 )
 (func $_RNvXs1_NvNtCs5pJS1yE9e7z_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCs7Tc6kFxL613_5alloc9panicking12PanicPayload3get (param $0 i32) (param $1 i32)
  (i32.store offset=4
   (local.get $0)
   (i32.const 1049192)
  )
  (i32.store
   (local.get $0)
   (local.get $1)
  )
 )
 (func $_RNvXs1_NvNtCs5pJS1yE9e7z_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCs7Tc6kFxL613_5alloc9panicking12PanicPayload6as_str (param $0 i32) (param $1 i32)
  (i64.store
   (local.get $0)
   (i64.load align=4
    (local.get $1)
   )
  )
 )
 (func $_RNvXs1_NvNtCs5pJS1yE9e7z_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCs7Tc6kFxL613_5alloc9panicking12PanicPayload8take_box (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local.set $2
   (i32.load offset=4
    (local.get $1)
   )
  )
  (local.set $3
   (i32.load
    (local.get $1)
   )
  )
  (call $_RNvCs9VHGBS8Gq78_7___rustc35___rust_no_alloc_shim_is_unstable_v2)
  (block $block
   (br_if $block
    (local.tee $1
     (call $_RNvCs9VHGBS8Gq78_7___rustc12___rust_alloc
      (i32.const 8)
      (i32.const 4)
     )
    )
   )
   (call $_RNvNtCs7Tc6kFxL613_5alloc5alloc18handle_alloc_error
    (i32.const 4)
    (i32.const 8)
   )
   (unreachable)
  )
  (i32.store offset=4
   (local.get $1)
   (local.get $2)
  )
  (i32.store
   (local.get $1)
   (local.get $3)
  )
  (i32.store offset=4
   (local.get $0)
   (i32.const 1049192)
  )
  (i32.store
   (local.get $0)
   (local.get $1)
  )
 )
 (func $_RNvXs2_NvNtCs5pJS1yE9e7z_3std9panicking13panic_handlerNtB5_16StaticStrPayloadNtNtCseWvMq1ZOdSr_4core3fmt7Display3fmt (param $0 i32) (param $1 i32) (result i32)
  (call $_RNvMsa_NtCseWvMq1ZOdSr_4core3fmtNtB5_9Formatter9write_str
   (local.get $1)
   (i32.load
    (local.get $0)
   )
   (i32.load offset=4
    (local.get $0)
   )
  )
 )
 (func $_RNvXs_NvNtCs5pJS1yE9e7z_3std9panicking13panic_handlerNtB4_19FormatStringPayloadNtNtCs7Tc6kFxL613_5alloc9panicking12PanicPayload3get (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i64)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (block $block
   (br_if $block
    (i32.ne
     (i32.load
      (local.get $1)
     )
     (i32.const -1)
    )
   )
   (local.set $3
    (i32.load offset=12
     (local.get $1)
    )
   )
   (local.set $4
    (i32.const 0)
   )
   (i32.store offset=28
    (local.get $2)
    (i32.const 0)
   )
   (i64.store offset=20 align=4
    (local.get $2)
    (i64.const 4294967296)
   )
   (local.set $5
    (i32.load
     (local.tee $3
      (i32.load
       (local.get $3)
      )
     )
    )
   )
   (block $block3
    (block $block1
     (br_if $block1
      (i32.eqz
       (i32.and
        (local.tee $3
         (i32.load offset=4
          (local.get $3)
         )
        )
        (i32.const 1)
       )
      )
     )
     (block $block2
      (br_if $block2
       (i32.eqz
        (local.tee $3
         (i32.shr_u
          (local.get $3)
          (i32.const 1)
         )
        )
       )
      )
      (call $_RINvNvMs5_NtCs7Tc6kFxL613_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs5pJS1yE9e7z_3std
       (i32.add
        (local.get $2)
        (i32.const 20)
       )
       (i32.const 0)
       (local.get $3)
       (i32.const 1)
       (i32.const 1)
      )
      (local.set $4
       (i32.load offset=28
        (local.get $2)
       )
      )
      (br_if $block2
       (i32.eqz
        (local.get $3)
       )
      )
      (memory.copy
       (i32.add
        (i32.load offset=24
         (local.get $2)
        )
        (local.get $4)
       )
       (local.get $5)
       (local.get $3)
      )
     )
     (i32.store offset=28
      (local.get $2)
      (i32.add
       (local.get $4)
       (local.get $3)
      )
     )
     (br $block3)
    )
    (drop
     (call $_RNvNtCseWvMq1ZOdSr_4core3fmt5write
      (i32.add
       (local.get $2)
       (i32.const 20)
      )
      (i32.const 1048728)
      (local.get $5)
      (local.get $3)
     )
    )
   )
   (i32.store offset=16
    (local.get $2)
    (local.tee $3
     (i32.load offset=28
      (local.get $2)
     )
    )
   )
   (i64.store offset=8
    (local.get $2)
    (local.tee $6
     (i64.load offset=20 align=4
      (local.get $2)
     )
    )
   )
   (i32.store offset=8
    (local.get $1)
    (local.get $3)
   )
   (i64.store align=4
    (local.get $1)
    (local.get $6)
   )
  )
  (i32.store offset=4
   (local.get $0)
   (i32.const 1049208)
  )
  (i32.store
   (local.get $0)
   (local.get $1)
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 32)
   )
  )
 )
 (func $_RNvXs_NvNtCs5pJS1yE9e7z_3std9panicking13panic_handlerNtB4_19FormatStringPayloadNtNtCs7Tc6kFxL613_5alloc9panicking12PanicPayload8take_box (param $0 i32) (param $1 i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i64)
  (global.set $__stack_pointer
   (local.tee $2
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (block $block
   (br_if $block
    (i32.ne
     (i32.load
      (local.get $1)
     )
     (i32.const -1)
    )
   )
   (local.set $3
    (i32.load offset=12
     (local.get $1)
    )
   )
   (local.set $4
    (i32.const 0)
   )
   (i32.store offset=24
    (local.get $2)
    (i32.const 0)
   )
   (i64.store offset=16 align=4
    (local.get $2)
    (i64.const 4294967296)
   )
   (local.set $5
    (i32.load
     (local.tee $3
      (i32.load
       (local.get $3)
      )
     )
    )
   )
   (block $block3
    (block $block1
     (br_if $block1
      (i32.eqz
       (i32.and
        (local.tee $3
         (i32.load offset=4
          (local.get $3)
         )
        )
        (i32.const 1)
       )
      )
     )
     (block $block2
      (br_if $block2
       (i32.eqz
        (local.tee $3
         (i32.shr_u
          (local.get $3)
          (i32.const 1)
         )
        )
       )
      )
      (call $_RINvNvMs5_NtCs7Tc6kFxL613_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs5pJS1yE9e7z_3std
       (i32.add
        (local.get $2)
        (i32.const 16)
       )
       (i32.const 0)
       (local.get $3)
       (i32.const 1)
       (i32.const 1)
      )
      (local.set $4
       (i32.load offset=24
        (local.get $2)
       )
      )
      (br_if $block2
       (i32.eqz
        (local.get $3)
       )
      )
      (memory.copy
       (i32.add
        (i32.load offset=20
         (local.get $2)
        )
        (local.get $4)
       )
       (local.get $5)
       (local.get $3)
      )
     )
     (i32.store offset=24
      (local.get $2)
      (i32.add
       (local.get $4)
       (local.get $3)
      )
     )
     (br $block3)
    )
    (drop
     (call $_RNvNtCseWvMq1ZOdSr_4core3fmt5write
      (i32.add
       (local.get $2)
       (i32.const 16)
      )
      (i32.const 1048728)
      (local.get $5)
      (local.get $3)
     )
    )
   )
   (i32.store offset=8
    (local.get $2)
    (local.tee $3
     (i32.load offset=24
      (local.get $2)
     )
    )
   )
   (i64.store
    (local.get $2)
    (local.tee $6
     (i64.load offset=16 align=4
      (local.get $2)
     )
    )
   )
   (i32.store offset=8
    (local.get $1)
    (local.get $3)
   )
   (i64.store align=4
    (local.get $1)
    (local.get $6)
   )
  )
  (local.set $3
   (i32.load offset=8
    (local.get $1)
   )
  )
  (i32.store offset=8
   (local.get $1)
   (i32.const 0)
  )
  (local.set $6
   (i64.load align=4
    (local.get $1)
   )
  )
  (i64.store align=4
   (local.get $1)
   (i64.const 4294967296)
  )
  (i32.store offset=24
   (local.get $2)
   (local.get $3)
  )
  (i64.store offset=16
   (local.get $2)
   (local.get $6)
  )
  (call $_RNvCs9VHGBS8Gq78_7___rustc35___rust_no_alloc_shim_is_unstable_v2)
  (block $block4
   (br_if $block4
    (local.tee $1
     (call $_RNvCs9VHGBS8Gq78_7___rustc12___rust_alloc
      (i32.const 12)
      (i32.const 4)
     )
    )
   )
   (call $_RNvNtCs7Tc6kFxL613_5alloc5alloc18handle_alloc_error
    (i32.const 4)
    (i32.const 12)
   )
   (unreachable)
  )
  (i32.store offset=8
   (local.get $1)
   (i32.load offset=24
    (local.get $2)
   )
  )
  (i64.store align=4
   (local.get $1)
   (i64.load offset=16
    (local.get $2)
   )
  )
  (i32.store offset=4
   (local.get $0)
   (i32.const 1049208)
  )
  (i32.store
   (local.get $0)
   (local.get $1)
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $2)
    (i32.const 32)
   )
  )
 )
 (func $_RNvYINtNvNtCs5pJS1yE9e7z_3std9panicking11begin_panic7PayloadReENtNtCs7Tc6kFxL613_5alloc9panicking12PanicPayload6as_strB9_ (param $0 i32) (param $1 i32)
  (i32.store
   (local.get $0)
   (i32.const 0)
  )
 )
 (func $_RNvYNtNtCs7Tc6kFxL613_5alloc6string6StringNtNtCseWvMq1ZOdSr_4core3fmt5Write9write_fmtCs5pJS1yE9e7z_3std (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (local $3 i32)
  (block $block
   (br_if $block
    (i32.eqz
     (i32.and
      (local.get $2)
      (i32.const 1)
     )
    )
   )
   (block $block3
    (block $block2
     (block $block1
      (br_if $block1
       (i32.le_u
        (local.tee $2
         (i32.shr_u
          (local.get $2)
          (i32.const 1)
         )
        )
        (i32.sub
         (i32.load
          (local.get $0)
         )
         (local.tee $3
          (i32.load offset=8
           (local.get $0)
          )
         )
        )
       )
      )
      (call $_RINvNvMs5_NtCs7Tc6kFxL613_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs5pJS1yE9e7z_3std
       (local.get $0)
       (local.get $3)
       (local.get $2)
       (i32.const 1)
       (i32.const 1)
      )
      (local.set $3
       (i32.load offset=8
        (local.get $0)
       )
      )
      (br $block2)
     )
     (br_if $block3
      (i32.eqz
       (local.get $2)
      )
     )
    )
    (br_if $block3
     (i32.eqz
      (local.get $2)
     )
    )
    (memory.copy
     (i32.add
      (i32.load offset=4
       (local.get $0)
      )
      (local.get $3)
     )
     (local.get $1)
     (local.get $2)
    )
   )
   (i32.store offset=8
    (local.get $0)
    (i32.add
     (local.get $3)
     (local.get $2)
    )
   )
   (return
    (i32.const 0)
   )
  )
  (call $_RNvNtCseWvMq1ZOdSr_4core3fmt5write
   (local.get $0)
   (i32.const 1048728)
   (local.get $1)
   (local.get $2)
  )
 )
 (func $_RNvCs9VHGBS8Gq78_7___rustc18___rust_start_panic (param $0 i32) (param $1 i32) (result i32)
  (call $_RNvCs9VHGBS8Gq78_7___rustc12___rust_abort)
  (unreachable)
 )
 (func $_RNvXs_NtCscztyJPgK1NC_8dlmalloc3sysNtB4_6SystemNtB6_9Allocator5alloc (param $0 i32) (param $1 i32) (param $2 i32)
  (local $3 i32)
  (local $4 i32)
  (block $block1
   (block $block
    (br_if $block
     (i32.eqz
      (local.get $2)
     )
    )
    (local.set $3
     (i32.load8_u offset=1053945
      (i32.const 0)
     )
    )
    (i32.store8 offset=1053945
     (i32.const 0)
     (i32.const 1)
    )
    (local.set $4
     (i32.const 1053952)
    )
    (br_if $block
     (i32.le_u
      (i32.const 1114112)
      (i32.const 1053952)
     )
    )
    (br_if $block
     (i32.gt_u
      (local.get $2)
      (i32.sub
       (i32.const 1114112)
       (i32.const 1053952)
      )
     )
    )
    (br_if $block
     (i32.and
      (local.get $3)
      (i32.const 255)
     )
    )
    (local.set $2
     (i32.sub
      (i32.const 1114112)
      (i32.const 1053952)
     )
    )
    (br $block1)
   )
   (local.set $4
    (i32.const 0)
   )
   (block $block2
    (br_if $block2
     (i32.ne
      (local.tee $3
       (memory.grow
        (local.tee $2
         (i32.add
          (i32.shr_u
           (local.get $2)
           (i32.const 16)
          )
          (i32.ne
           (i32.and
            (local.get $2)
            (i32.const 65535)
           )
           (i32.const 0)
          )
         )
        )
       )
      )
      (i32.const -1)
     )
    )
    (local.set $2
     (i32.const 0)
    )
    (br $block1)
   )
   (local.set $2
    (select
     (i32.add
      (local.tee $2
       (i32.shl
        (local.get $2)
        (i32.const 16)
       )
      )
      (i32.const -16)
     )
     (local.get $2)
     (i32.eq
      (local.tee $4
       (i32.shl
        (local.get $3)
        (i32.const 16)
       )
      )
      (i32.sub
       (i32.const 0)
       (local.get $2)
      )
     )
    )
   )
  )
  (i32.store offset=8
   (local.get $0)
   (i32.const 0)
  )
  (i32.store offset=4
   (local.get $0)
   (local.get $2)
  )
  (i32.store
   (local.get $0)
   (local.get $4)
  )
 )
 (func $_RNvNtCs7Tc6kFxL613_5alloc7raw_vec12handle_error (param $0 i32) (param $1 i32)
  (block $block
   (br_if $block
    (i32.eqz
     (local.get $0)
    )
   )
   (call $_RNvNtCs7Tc6kFxL613_5alloc5alloc18handle_alloc_error
    (local.get $0)
    (local.get $1)
   )
   (unreachable)
  )
  (call $_RNvNtCs7Tc6kFxL613_5alloc7raw_vec17capacity_overflow)
  (unreachable)
 )
 (func $_RNvNtCs7Tc6kFxL613_5alloc5alloc18handle_alloc_error (param $0 i32) (param $1 i32)
  (call $_RNvCs9VHGBS8Gq78_7___rustc26___rust_alloc_error_handler
   (local.get $1)
   (local.get $0)
  )
  (unreachable)
 )
 (func $_RNvNtCs7Tc6kFxL613_5alloc7raw_vec17capacity_overflow
  (call $_RNvNtCseWvMq1ZOdSr_4core9panicking9panic_fmt
   (i32.const 1049280)
   (i32.const 35)
   (i32.const 1049300)
  )
  (unreachable)
 )
 (func $_RNvNtCseWvMq1ZOdSr_4core9panicking5panic (param $0 i32) (param $1 i32) (param $2 i32)
  (call $_RNvNtCseWvMq1ZOdSr_4core9panicking9panic_fmt
   (local.get $0)
   (i32.or
    (i32.shl
     (local.get $1)
     (i32.const 1)
    )
    (i32.const 1)
   )
   (local.get $2)
  )
  (unreachable)
 )
 (func $_RNvXs1i_NtCseWvMq1ZOdSr_4core3fmtReNtB6_7Display3fmtB8_ (param $0 i32) (param $1 i32) (result i32)
  (call $_RNvMsa_NtCseWvMq1ZOdSr_4core3fmtNtB5_9Formatter3pad
   (local.get $1)
   (i32.load
    (local.get $0)
   )
   (i32.load offset=4
    (local.get $0)
   )
  )
 )
 (func $_RNvNtCseWvMq1ZOdSr_4core3fmt5write (param $0 i32) (param $1 i32) (param $2 i32) (param $3 i32) (result i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (local $11 i32)
  (global.set $__stack_pointer
   (local.tee $4
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (block $block2
   (block $block1
    (block $block
     (br_if $block
      (i32.and
       (local.get $3)
       (i32.const 1)
      )
     )
     (br_if $block1
      (local.tee $5
       (i32.load8_u
        (local.get $2)
       )
      )
     )
     (local.set $5
      (i32.const 0)
     )
     (br $block2)
    )
    (local.set $5
     (call_indirect $0 (type $3)
      (local.get $0)
      (local.get $2)
      (i32.shr_u
       (local.get $3)
       (i32.const 1)
      )
      (i32.load offset=12
       (local.get $1)
      )
     )
    )
    (br $block2)
   )
   (local.set $6
    (i32.load offset=12
     (local.get $1)
    )
   )
   (local.set $7
    (i32.const 0)
   )
   (loop $label
    (local.set $8
     (i32.add
      (local.get $2)
      (i32.const 1)
     )
    )
    (block $block8
     (block $block5
      (block $block6
       (block $block4
        (block $block3
         (br_if $block3
          (i32.gt_s
           (i32.extend8_s
            (local.get $5)
           )
           (i32.const -1)
          )
         )
         (br_if $block4
          (i32.eq
           (local.tee $9
            (i32.and
             (local.get $5)
             (i32.const 255)
            )
           )
           (i32.const 128)
          )
         )
         (br_if $block5
          (i32.ne
           (local.get $9)
           (i32.const 192)
          )
         )
         (i32.store offset=4
          (local.get $4)
          (local.get $1)
         )
         (i32.store
          (local.get $4)
          (local.get $0)
         )
         (i64.store offset=8 align=4
          (local.get $4)
          (i64.const 1610612768)
         )
         (br_if $block6
          (i32.eqz
           (call_indirect $0 (type $2)
            (i32.load
             (local.tee $5
              (i32.add
               (local.get $3)
               (i32.shl
                (local.get $7)
                (i32.const 3)
               )
              )
             )
            )
            (local.get $4)
            (i32.load offset=4
             (local.get $5)
            )
           )
          )
         )
         (local.set $5
          (i32.const 1)
         )
         (br $block2)
        )
        (block $block7
         (br_if $block7
          (call_indirect $0 (type $3)
           (local.get $0)
           (local.get $8)
           (local.tee $5
            (i32.and
             (local.get $5)
             (i32.const 255)
            )
           )
           (local.get $6)
          )
         )
         (local.set $2
          (i32.add
           (local.get $8)
           (local.get $5)
          )
         )
         (br $block8)
        )
        (local.set $5
         (i32.const 1)
        )
        (br $block2)
       )
       (block $block9
        (br_if $block9
         (call_indirect $0 (type $3)
          (local.get $0)
          (local.tee $5
           (i32.add
            (local.get $2)
            (i32.const 3)
           )
          )
          (local.tee $2
           (i32.load16_u offset=1 align=1
            (local.get $2)
           )
          )
          (local.get $6)
         )
        )
        (local.set $2
         (i32.add
          (local.get $5)
          (local.get $2)
         )
        )
        (br $block8)
       )
       (local.set $5
        (i32.const 1)
       )
       (br $block2)
      )
      (local.set $7
       (i32.add
        (local.get $7)
        (i32.const 1)
       )
      )
      (local.set $2
       (local.get $8)
      )
      (br $block8)
     )
     (local.set $10
      (i32.const 1610612768)
     )
     (block $block10
      (br_if $block10
       (i32.eqz
        (i32.and
         (local.get $5)
         (i32.const 1)
        )
       )
      )
      (local.set $8
       (i32.add
        (local.get $2)
        (i32.const 5)
       )
      )
      (local.set $10
       (i32.load offset=1 align=1
        (local.get $2)
       )
      )
     )
     (local.set $9
      (i32.const 0)
     )
     (block $block12
      (block $block11
       (br_if $block11
        (i32.and
         (local.get $5)
         (i32.const 2)
        )
       )
       (local.set $11
        (i32.const 0)
       )
       (local.set $2
        (local.get $8)
       )
       (br $block12)
      )
      (local.set $2
       (i32.add
        (local.get $8)
        (i32.const 2)
       )
      )
      (local.set $11
       (i32.load16_u align=1
        (local.get $8)
       )
      )
     )
     (block $block14
      (block $block13
       (br_if $block13
        (i32.and
         (local.get $5)
         (i32.const 4)
        )
       )
       (local.set $8
        (local.get $2)
       )
       (br $block14)
      )
      (local.set $8
       (i32.add
        (local.get $2)
        (i32.const 2)
       )
      )
      (local.set $9
       (i32.load16_u align=1
        (local.get $2)
       )
      )
     )
     (block $block16
      (block $block15
       (br_if $block15
        (i32.and
         (local.get $5)
         (i32.const 8)
        )
       )
       (local.set $2
        (local.get $8)
       )
       (br $block16)
      )
      (local.set $2
       (i32.add
        (local.get $8)
        (i32.const 2)
       )
      )
      (local.set $7
       (i32.load16_u align=1
        (local.get $8)
       )
      )
     )
     (block $block17
      (br_if $block17
       (i32.eqz
        (i32.and
         (local.get $5)
         (i32.const 16)
        )
       )
      )
      (local.set $11
       (i32.load16_u offset=4
        (i32.add
         (local.get $3)
         (i32.shl
          (i32.and
           (local.get $11)
           (i32.const 65535)
          )
          (i32.const 3)
         )
        )
       )
      )
     )
     (block $block18
      (br_if $block18
       (i32.eqz
        (i32.and
         (local.get $5)
         (i32.const 32)
        )
       )
      )
      (local.set $9
       (i32.load16_u offset=4
        (i32.add
         (local.get $3)
         (i32.shl
          (i32.and
           (local.get $9)
           (i32.const 65535)
          )
          (i32.const 3)
         )
        )
       )
      )
     )
     (i32.store16 offset=14
      (local.get $4)
      (local.get $9)
     )
     (i32.store16 offset=12
      (local.get $4)
      (local.get $11)
     )
     (i32.store offset=8
      (local.get $4)
      (local.get $10)
     )
     (i32.store offset=4
      (local.get $4)
      (local.get $1)
     )
     (i32.store
      (local.get $4)
      (local.get $0)
     )
     (block $block19
      (br_if $block19
       (i32.eqz
        (call_indirect $0 (type $2)
         (i32.load
          (local.tee $5
           (i32.add
            (local.get $3)
            (i32.shl
             (local.get $7)
             (i32.const 3)
            )
           )
          )
         )
         (local.get $4)
         (i32.load offset=4
          (local.get $5)
         )
        )
       )
      )
      (local.set $5
       (i32.const 1)
      )
      (br $block2)
     )
     (local.set $7
      (i32.add
       (local.get $7)
       (i32.const 1)
      )
     )
    )
    (br_if $label
     (local.tee $5
      (i32.load8_u
       (local.get $2)
      )
     )
    )
   )
   (local.set $5
    (i32.const 0)
   )
  )
  (global.set $__stack_pointer
   (i32.add
    (local.get $4)
    (i32.const 16)
   )
  )
  (local.get $5)
 )
 (func $_RNvNtCseWvMq1ZOdSr_4core9panicking9panic_fmt (param $0 i32) (param $1 i32) (param $2 i32)
  (local $3 i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 32)
    )
   )
  )
  (i32.store offset=16
   (local.get $3)
   (local.get $1)
  )
  (i32.store offset=12
   (local.get $3)
   (local.get $0)
  )
  (i32.store16 offset=28
   (local.get $3)
   (i32.const 1)
  )
  (i32.store offset=24
   (local.get $3)
   (local.get $2)
  )
  (i32.store offset=20
   (local.get $3)
   (i32.add
    (local.get $3)
    (i32.const 12)
   )
  )
  (call $_RNvCs9VHGBS8Gq78_7___rustc17rust_begin_unwind
   (i32.add
    (local.get $3)
    (i32.const 20)
   )
  )
  (unreachable)
 )
 (func $_RNvNtNtCseWvMq1ZOdSr_4core3str5count14do_count_chars (param $0 i32) (param $1 i32) (result i32)
  (local $2 i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (block $block4
   (block $block
    (br_if $block
     (i32.lt_u
      (local.get $1)
      (local.tee $3
       (i32.sub
        (local.tee $2
         (i32.and
          (i32.add
           (local.get $0)
           (i32.const 3)
          )
          (i32.const -4)
         )
        )
        (local.get $0)
       )
      )
     )
    )
    (br_if $block
     (i32.eqz
      (local.tee $5
       (i32.shr_u
        (local.tee $4
         (i32.sub
          (local.get $1)
          (local.get $3)
         )
        )
        (i32.const 2)
       )
      )
     )
    )
    (local.set $6
     (i32.and
      (local.get $4)
      (i32.const 3)
     )
    )
    (local.set $7
     (i32.const 0)
    )
    (local.set $1
     (i32.const 0)
    )
    (block $block1
     (br_if $block1
      (i32.eq
       (local.get $2)
       (local.get $0)
      )
     )
     (local.set $8
      (i32.const 0)
     )
     (local.set $1
      (i32.const 0)
     )
     (block $block2
      (br_if $block2
       (i32.gt_u
        (local.tee $9
         (i32.sub
          (local.get $0)
          (local.get $2)
         )
        )
        (i32.const -4)
       )
      )
      (local.set $8
       (i32.const 0)
      )
      (local.set $1
       (i32.const 0)
      )
      (loop $label
       (local.set $1
        (i32.add
         (i32.add
          (i32.add
           (i32.add
            (local.get $1)
            (i32.gt_s
             (i32.load8_s
              (local.tee $2
               (i32.add
                (local.get $0)
                (local.get $8)
               )
              )
             )
             (i32.const -65)
            )
           )
           (i32.gt_s
            (i32.load8_s
             (i32.add
              (local.get $2)
              (i32.const 1)
             )
            )
            (i32.const -65)
           )
          )
          (i32.gt_s
           (i32.load8_s
            (i32.add
             (local.get $2)
             (i32.const 2)
            )
           )
           (i32.const -65)
          )
         )
         (i32.gt_s
          (i32.load8_s
           (i32.add
            (local.get $2)
            (i32.const 3)
           )
          )
          (i32.const -65)
         )
        )
       )
       (br_if $label
        (local.tee $8
         (i32.add
          (local.get $8)
          (i32.const 4)
         )
        )
       )
      )
     )
     (local.set $2
      (i32.add
       (local.get $0)
       (local.get $8)
      )
     )
     (loop $label1
      (local.set $1
       (i32.add
        (local.get $1)
        (i32.gt_s
         (i32.load8_s
          (local.get $2)
         )
         (i32.const -65)
        )
       )
      )
      (local.set $2
       (i32.add
        (local.get $2)
        (i32.const 1)
       )
      )
      (br_if $label1
       (local.tee $9
        (i32.add
         (local.get $9)
         (i32.const 1)
        )
       )
      )
     )
    )
    (local.set $9
     (i32.add
      (local.get $0)
      (local.get $3)
     )
    )
    (block $block3
     (br_if $block3
      (i32.eqz
       (local.get $6)
      )
     )
     (local.set $7
      (i32.gt_s
       (i32.load8_s
        (local.tee $2
         (i32.add
          (local.get $9)
          (i32.and
           (local.get $4)
           (i32.const 2147483644)
          )
         )
        )
       )
       (i32.const -65)
      )
     )
     (br_if $block3
      (i32.eq
       (local.get $6)
       (i32.const 1)
      )
     )
     (local.set $7
      (i32.add
       (local.get $7)
       (i32.gt_s
        (i32.load8_s offset=1
         (local.get $2)
        )
        (i32.const -65)
       )
      )
     )
     (br_if $block3
      (i32.eq
       (local.get $6)
       (i32.const 2)
      )
     )
     (local.set $7
      (i32.add
       (local.get $7)
       (i32.gt_s
        (i32.load8_s offset=2
         (local.get $2)
        )
        (i32.const -65)
       )
      )
     )
    )
    (local.set $8
     (i32.add
      (local.get $7)
      (local.get $1)
     )
    )
    (loop $label3
     (local.set $3
      (local.get $9)
     )
     (br_if $block4
      (i32.eqz
       (local.get $5)
      )
     )
     (local.set $6
      (i32.and
       (local.tee $7
        (select
         (local.get $5)
         (i32.const 192)
         (i32.lt_u
          (local.get $5)
          (i32.const 192)
         )
        )
       )
       (i32.const 3)
      )
     )
     (block $block6
      (block $block5
       (br_if $block5
        (local.tee $1
         (i32.and
          (local.tee $4
           (i32.shl
            (local.get $7)
            (i32.const 2)
           )
          )
          (i32.const 1008)
         )
        )
       )
       (local.set $2
        (i32.const 0)
       )
       (br $block6)
      )
      (local.set $0
       (i32.add
        (local.get $3)
        (local.get $1)
       )
      )
      (local.set $2
       (i32.const 0)
      )
      (local.set $1
       (local.get $3)
      )
      (loop $label2
       (local.set $2
        (i32.add
         (i32.and
          (i32.or
           (i32.shr_u
            (i32.xor
             (local.tee $9
              (i32.load
               (i32.add
                (local.get $1)
                (i32.const 12)
               )
              )
             )
             (i32.const -1)
            )
            (i32.const 7)
           )
           (i32.shr_u
            (local.get $9)
            (i32.const 6)
           )
          )
          (i32.const 16843009)
         )
         (i32.add
          (i32.and
           (i32.or
            (i32.shr_u
             (i32.xor
              (local.tee $9
               (i32.load
                (i32.add
                 (local.get $1)
                 (i32.const 8)
                )
               )
              )
              (i32.const -1)
             )
             (i32.const 7)
            )
            (i32.shr_u
             (local.get $9)
             (i32.const 6)
            )
           )
           (i32.const 16843009)
          )
          (i32.add
           (i32.and
            (i32.or
             (i32.shr_u
              (i32.xor
               (local.tee $9
                (i32.load
                 (i32.add
                  (local.get $1)
                  (i32.const 4)
                 )
                )
               )
               (i32.const -1)
              )
              (i32.const 7)
             )
             (i32.shr_u
              (local.get $9)
              (i32.const 6)
             )
            )
            (i32.const 16843009)
           )
           (i32.add
            (i32.and
             (i32.or
              (i32.shr_u
               (i32.xor
                (local.tee $9
                 (i32.load
                  (local.get $1)
                 )
                )
                (i32.const -1)
               )
               (i32.const 7)
              )
              (i32.shr_u
               (local.get $9)
               (i32.const 6)
              )
             )
             (i32.const 16843009)
            )
            (local.get $2)
           )
          )
         )
        )
       )
       (br_if $label2
        (i32.ne
         (local.tee $1
          (i32.add
           (local.get $1)
           (i32.const 16)
          )
         )
         (local.get $0)
        )
       )
      )
     )
     (local.set $5
      (i32.sub
       (local.get $5)
       (local.get $7)
      )
     )
     (local.set $9
      (i32.add
       (local.get $3)
       (local.get $4)
      )
     )
     (local.set $8
      (i32.add
       (i32.shr_u
        (i32.mul
         (i32.add
          (i32.and
           (i32.shr_u
            (local.get $2)
            (i32.const 8)
           )
           (i32.const 16711935)
          )
          (i32.and
           (local.get $2)
           (i32.const 16711935)
          )
         )
         (i32.const 65537)
        )
        (i32.const 16)
       )
       (local.get $8)
      )
     )
     (br_if $label3
      (i32.eqz
       (local.get $6)
      )
     )
    )
    (local.set $1
     (i32.and
      (i32.or
       (i32.shr_u
        (i32.xor
         (local.tee $1
          (i32.load
           (local.tee $2
            (i32.add
             (local.get $3)
             (i32.shl
              (i32.and
               (local.get $7)
               (i32.const 252)
              )
              (i32.const 2)
             )
            )
           )
          )
         )
         (i32.const -1)
        )
        (i32.const 7)
       )
       (i32.shr_u
        (local.get $1)
        (i32.const 6)
       )
      )
      (i32.const 16843009)
     )
    )
    (block $block7
     (br_if $block7
      (i32.eq
       (local.get $6)
       (i32.const 1)
      )
     )
     (local.set $1
      (i32.add
       (i32.and
        (i32.or
         (i32.shr_u
          (i32.xor
           (local.tee $9
            (i32.load offset=4
             (local.get $2)
            )
           )
           (i32.const -1)
          )
          (i32.const 7)
         )
         (i32.shr_u
          (local.get $9)
          (i32.const 6)
         )
        )
        (i32.const 16843009)
       )
       (local.get $1)
      )
     )
     (br_if $block7
      (i32.eq
       (local.get $6)
       (i32.const 2)
      )
     )
     (local.set $1
      (i32.add
       (i32.and
        (i32.or
         (i32.shr_u
          (i32.xor
           (local.tee $2
            (i32.load offset=8
             (local.get $2)
            )
           )
           (i32.const -1)
          )
          (i32.const 7)
         )
         (i32.shr_u
          (local.get $2)
          (i32.const 6)
         )
        )
        (i32.const 16843009)
       )
       (local.get $1)
      )
     )
    )
    (local.set $8
     (i32.add
      (i32.shr_u
       (i32.mul
        (i32.add
         (i32.and
          (i32.shr_u
           (local.get $1)
           (i32.const 8)
          )
          (i32.const 459007)
         )
         (i32.and
          (local.get $1)
          (i32.const 16711935)
         )
        )
        (i32.const 65537)
       )
       (i32.const 16)
      )
      (local.get $8)
     )
    )
    (br $block4)
   )
   (block $block8
    (br_if $block8
     (local.get $1)
    )
    (return
     (i32.const 0)
    )
   )
   (local.set $2
    (i32.and
     (local.get $1)
     (i32.const 3)
    )
   )
   (local.set $9
    (i32.const 0)
   )
   (local.set $8
    (i32.const 0)
   )
   (block $block9
    (br_if $block9
     (i32.lt_u
      (local.get $1)
      (i32.const 4)
     )
    )
    (local.set $5
     (i32.and
      (local.get $1)
      (i32.const -4)
     )
    )
    (local.set $8
     (i32.const 0)
    )
    (local.set $9
     (i32.const 0)
    )
    (loop $label4
     (local.set $8
      (i32.add
       (i32.add
        (i32.add
         (i32.add
          (local.get $8)
          (i32.gt_s
           (i32.load8_s
            (local.tee $1
             (i32.add
              (local.get $0)
              (local.get $9)
             )
            )
           )
           (i32.const -65)
          )
         )
         (i32.gt_s
          (i32.load8_s
           (i32.add
            (local.get $1)
            (i32.const 1)
           )
          )
          (i32.const -65)
         )
        )
        (i32.gt_s
         (i32.load8_s
          (i32.add
           (local.get $1)
           (i32.const 2)
          )
         )
         (i32.const -65)
        )
       )
       (i32.gt_s
        (i32.load8_s
         (i32.add
          (local.get $1)
          (i32.const 3)
         )
        )
        (i32.const -65)
       )
      )
     )
     (br_if $label4
      (i32.ne
       (local.get $5)
       (local.tee $9
        (i32.add
         (local.get $9)
         (i32.const 4)
        )
       )
      )
     )
    )
    (br_if $block4
     (i32.eqz
      (local.get $2)
     )
    )
   )
   (local.set $1
    (i32.add
     (local.get $0)
     (local.get $9)
    )
   )
   (loop $label5
    (local.set $8
     (i32.add
      (local.get $8)
      (i32.gt_s
       (i32.load8_s
        (local.get $1)
       )
       (i32.const -65)
      )
     )
    )
    (local.set $1
     (i32.add
      (local.get $1)
      (i32.const 1)
     )
    )
    (br_if $label5
     (local.tee $2
      (i32.add
       (local.get $2)
       (i32.const -1)
      )
     )
    )
   )
  )
  (local.get $8)
 )
 (func $_RNvMsa_NtCseWvMq1ZOdSr_4core3fmtNtB5_9Formatter3pad (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (local $3 i32)
  (local $4 i32)
  (local $5 i32)
  (local $6 i32)
  (local $7 i32)
  (local $8 i32)
  (local $9 i32)
  (local $10 i32)
  (block $block16
   (block $block
    (br_if $block
     (i32.eqz
      (i32.and
       (local.tee $3
        (i32.load offset=8
         (local.get $0)
        )
       )
       (i32.const 402653184)
      )
     )
    )
    (block $block5
     (block $block8
      (block $block3
       (block $block2
        (block $block1
         (br_if $block1
          (i32.eqz
           (i32.and
            (local.get $3)
            (i32.const 268435456)
           )
          )
         )
         (br_if $block2
          (local.tee $4
           (i32.load16_u offset=14
            (local.get $0)
           )
          )
         )
         (local.set $2
          (i32.const 0)
         )
         (br $block3)
        )
        (block $block4
         (br_if $block4
          (i32.lt_u
           (local.get $2)
           (i32.const 16)
          )
         )
         (local.set $5
          (call $_RNvNtNtCseWvMq1ZOdSr_4core3str5count14do_count_chars
           (local.get $1)
           (local.get $2)
          )
         )
         (br $block5)
        )
        (block $block6
         (br_if $block6
          (local.get $2)
         )
         (local.set $5
          (i32.const 0)
         )
         (br $block5)
        )
        (local.set $6
         (i32.and
          (local.get $2)
          (i32.const 3)
         )
        )
        (local.set $7
         (i32.const 0)
        )
        (local.set $5
         (i32.const 0)
        )
        (block $block7
         (br_if $block7
          (i32.lt_u
           (local.get $2)
           (i32.const 4)
          )
         )
         (local.set $4
          (i32.and
           (local.get $2)
           (i32.const 12)
          )
         )
         (local.set $5
          (i32.const 0)
         )
         (local.set $7
          (i32.const 0)
         )
         (loop $label
          (local.set $5
           (i32.add
            (i32.add
             (i32.add
              (i32.add
               (local.get $5)
               (i32.gt_s
                (i32.load8_s
                 (local.tee $8
                  (i32.add
                   (local.get $1)
                   (local.get $7)
                  )
                 )
                )
                (i32.const -65)
               )
              )
              (i32.gt_s
               (i32.load8_s
                (i32.add
                 (local.get $8)
                 (i32.const 1)
                )
               )
               (i32.const -65)
              )
             )
             (i32.gt_s
              (i32.load8_s
               (i32.add
                (local.get $8)
                (i32.const 2)
               )
              )
              (i32.const -65)
             )
            )
            (i32.gt_s
             (i32.load8_s
              (i32.add
               (local.get $8)
               (i32.const 3)
              )
             )
             (i32.const -65)
            )
           )
          )
          (br_if $label
           (i32.ne
            (local.get $4)
            (local.tee $7
             (i32.add
              (local.get $7)
              (i32.const 4)
             )
            )
           )
          )
         )
         (br_if $block5
          (i32.eqz
           (local.get $6)
          )
         )
        )
        (local.set $8
         (i32.add
          (local.get $1)
          (local.get $7)
         )
        )
        (loop $label1
         (local.set $5
          (i32.add
           (local.get $5)
           (i32.gt_s
            (i32.load8_s
             (local.get $8)
            )
            (i32.const -65)
           )
          )
         )
         (local.set $8
          (i32.add
           (local.get $8)
           (i32.const 1)
          )
         )
         (br_if $label1
          (local.tee $6
           (i32.add
            (local.get $6)
            (i32.const -1)
           )
          )
         )
         (br $block5)
        )
       )
       (local.set $7
        (i32.add
         (local.get $1)
         (local.get $2)
        )
       )
       (local.set $2
        (i32.const 0)
       )
       (local.set $8
        (local.get $1)
       )
       (local.set $6
        (local.get $4)
       )
       (loop $label2
        (br_if $block8
         (i32.eq
          (local.tee $5
           (local.get $8)
          )
          (local.get $7)
         )
        )
        (block $block10
         (block $block9
          (br_if $block9
           (i32.le_s
            (local.tee $8
             (i32.load8_s
              (local.get $5)
             )
            )
            (i32.const -1)
           )
          )
          (local.set $8
           (i32.add
            (local.get $5)
            (i32.const 1)
           )
          )
          (br $block10)
         )
         (block $block11
          (br_if $block11
           (i32.ge_u
            (local.get $8)
            (i32.const -32)
           )
          )
          (local.set $8
           (i32.add
            (local.get $5)
            (i32.const 2)
           )
          )
          (br $block10)
         )
         (local.set $8
          (i32.add
           (local.get $5)
           (select
            (i32.const 4)
            (i32.const 3)
            (i32.gt_u
             (local.get $8)
             (i32.const -17)
            )
           )
          )
         )
        )
        (local.set $2
         (i32.add
          (i32.sub
           (local.get $8)
           (local.get $5)
          )
          (local.get $2)
         )
        )
        (br_if $label2
         (local.tee $6
          (i32.add
           (local.get $6)
           (i32.const -1)
          )
         )
        )
       )
      )
      (local.set $6
       (i32.const 0)
      )
     )
     (local.set $5
      (i32.sub
       (local.get $4)
       (local.get $6)
      )
     )
    )
    (br_if $block
     (i32.ge_u
      (local.get $5)
      (local.tee $8
       (i32.load16_u offset=12
        (local.get $0)
       )
      )
     )
    )
    (local.set $9
     (i32.sub
      (local.get $8)
      (local.get $5)
     )
    )
    (local.set $4
     (i32.const 0)
    )
    (block $block12
     (block $block14
      (block $block13
       (br_table $block12 $block13 $block14 $block12 $block12
        (i32.and
         (i32.shr_u
          (local.get $3)
          (i32.const 29)
         )
         (i32.const 3)
        )
       )
      )
      (local.set $4
       (local.get $9)
      )
      (br $block12)
     )
     (local.set $4
      (i32.shr_u
       (i32.and
        (local.get $9)
        (i32.const 65534)
       )
       (i32.const 1)
      )
     )
    )
    (local.set $6
     (i32.and
      (local.get $3)
      (i32.const 2097151)
     )
    )
    (local.set $10
     (i32.load offset=4
      (local.get $0)
     )
    )
    (local.set $8
     (i32.load
      (local.get $0)
     )
    )
    (block $block15
     (br_if $block15
      (i32.eqz
       (local.tee $7
        (i32.and
         (local.get $4)
         (i32.const 65535)
        )
       )
      )
     )
     (local.set $3
      (i32.load offset=16
       (local.get $10)
      )
     )
     (local.set $5
      (i32.const 0)
     )
     (local.set $0
      (i32.const 1)
     )
     (loop $label3
      (br_if $block16
       (call_indirect $0 (type $2)
        (local.get $8)
        (local.get $6)
        (local.get $3)
       )
      )
      (br_if $label3
       (i32.lt_u
        (i32.and
         (local.tee $5
          (i32.add
           (local.get $5)
           (i32.const 1)
          )
         )
         (i32.const 65535)
        )
        (local.get $7)
       )
      )
     )
    )
    (block $block17
     (br_if $block17
      (i32.eqz
       (call_indirect $0 (type $3)
        (local.get $8)
        (local.get $1)
        (local.get $2)
        (i32.load offset=12
         (local.get $10)
        )
       )
      )
     )
     (return
      (i32.const 1)
     )
    )
    (block $block18
     (br_if $block18
      (i32.ne
       (i32.and
        (local.get $9)
        (i32.const 65535)
       )
       (i32.and
        (local.get $4)
        (i32.const 65535)
       )
      )
     )
     (return
      (i32.const 0)
     )
    )
    (local.set $2
     (i32.load offset=16
      (local.get $10)
     )
    )
    (local.set $5
     (i32.const 0)
    )
    (local.set $7
     (i32.and
      (i32.sub
       (local.get $9)
       (local.get $4)
      )
      (i32.const 65535)
     )
    )
    (loop $label4
     (br_if $block16
      (local.tee $0
       (call_indirect $0 (type $2)
        (local.get $8)
        (local.get $6)
        (local.get $2)
       )
      )
     )
     (br_if $block16
      (i32.ge_u
       (i32.and
        (local.tee $5
         (i32.add
          (local.get $5)
          (i32.const 1)
         )
        )
        (i32.const 65535)
       )
       (local.get $7)
      )
     )
     (br $label4)
    )
   )
   (local.set $0
    (call_indirect $0 (type $3)
     (i32.load
      (local.get $0)
     )
     (local.get $1)
     (local.get $2)
     (i32.load offset=12
      (i32.load offset=4
       (local.get $0)
      )
     )
    )
   )
  )
  (local.get $0)
 )
 (func $_RNvMsa_NtCseWvMq1ZOdSr_4core3fmtNtB5_9Formatter9write_str (param $0 i32) (param $1 i32) (param $2 i32) (result i32)
  (call_indirect $0 (type $3)
   (i32.load
    (local.get $0)
   )
   (local.get $1)
   (local.get $2)
   (i32.load offset=12
    (i32.load offset=4
     (local.get $0)
    )
   )
  )
 )
 (func $_RNvNtCseWvMq1ZOdSr_4core6option13expect_failed (param $0 i32) (param $1 i32) (param $2 i32)
  (local $3 i32)
  (global.set $__stack_pointer
   (local.tee $3
    (i32.sub
     (global.get $__stack_pointer)
     (i32.const 16)
    )
   )
  )
  (i32.store offset=4
   (local.get $3)
   (local.get $1)
  )
  (i32.store
   (local.get $3)
   (local.get $0)
  )
  (i64.store offset=8
   (local.get $3)
   (i64.or
    (i64.shl
     (i64.extend_i32_u
      (i32.const 20)
     )
     (i64.const 32)
    )
    (i64.extend_i32_u
     (local.get $3)
    )
   )
  )
  (call $_RNvNtCseWvMq1ZOdSr_4core9panicking9panic_fmt
   (i32.const 1048752)
   (i32.add
    (local.get $3)
    (i32.const 8)
   )
   (local.get $2)
  )
  (unreachable)
 )
 (func $_RNvNtNtCseWvMq1ZOdSr_4core9panicking11panic_const23panic_const_div_by_zero (param $0 i32)
  (call $_RNvNtCseWvMq1ZOdSr_4core9panicking9panic_fmt
   (i32.const 1049316)
   (i32.const 51)
   (local.get $0)
  )
  (unreachable)
 )
 (func $_RNvNtNtNtCs5cUd4OADQLd_17compiler_builtins4math9libm_math3exp3exp (param $0 f64) (result f64)
  (local $1 i32)
  (local $2 i64)
  (local $3 i32)
  (local $4 i32)
  (local $5 f64)
  (local $6 f64)
  (local $7 f64)
  (local.set $1
   (i32.sub
    (global.get $__stack_pointer)
    (i32.const 16)
   )
  )
  (local.set $3
   (i32.wrap_i64
    (i64.shr_u
     (local.tee $2
      (i64.reinterpret_f64
       (local.get $0)
      )
     )
     (i64.const 63)
    )
   )
  )
  (block $block4
   (block $block7
    (block $block9
     (block $block8
      (block $block6
       (block $block2
        (block $block3
         (block $block
          (br_if $block
           (i32.lt_u
            (local.tee $4
             (i32.and
              (i32.wrap_i64
               (i64.shr_u
                (local.get $2)
                (i64.const 32)
               )
              )
              (i32.const 2147483647)
             )
            )
            (i32.const 1082532651)
           )
          )
          (block $block1
           (br_if $block1
            (f64.eq
             (local.get $0)
             (local.get $0)
            )
           )
           (return
            (local.get $0)
           )
          )
          (br_if $block2
           (f64.gt
            (local.get $0)
            (f64.const 709.782712893384)
           )
          )
          (br_if $block3
           (i32.eqz
            (f64.lt
             (local.get $0)
             (f64.const -708.3964185322641)
            )
           )
          )
          (f32.store offset=4
           (local.get $1)
           (f32.demote_f64
            (f64.div
             (f64.const -1.401298464324817e-45)
             (local.get $0)
            )
           )
          )
          (drop
           (f32.load offset=4
            (local.get $1)
           )
          )
          (local.set $5
           (f64.const 0)
          )
          (br_if $block3
           (i32.eqz
            (f64.lt
             (local.get $0)
             (f64.const -745.1332191019411)
            )
           )
          )
          (br $block4)
         )
         (block $block5
          (br_if $block5
           (i32.gt_u
            (local.get $4)
            (i32.const 1071001154)
           )
          )
          (br_if $block6
           (i32.le_u
            (local.get $4)
            (i32.const 1043333120)
           )
          )
          (local.set $6
           (f64.const 0)
          )
          (local.set $4
           (i32.const 0)
          )
          (local.set $5
           (local.get $0)
          )
          (br $block7)
         )
         (br_if $block8
          (i32.le_u
           (local.get $4)
           (i32.const 1072734897)
          )
         )
        )
        (local.set $4
         (i32.trunc_sat_f64_s
          (f64.add
           (f64.mul
            (local.get $0)
            (f64.const 1.4426950408889634)
           )
           (f64.load offset=1049344
            (i32.shl
             (local.get $3)
             (i32.const 3)
            )
           )
          )
         )
        )
        (br $block9)
       )
       (return
        (f64.mul
         (local.get $0)
         (f64.const 8988465674311579538646525e283)
        )
       )
      )
      (f64.store offset=8
       (local.get $1)
       (f64.add
        (local.get $0)
        (f64.const 8988465674311579538646525e283)
       )
      )
      (drop
       (f64.load offset=8
        (local.get $1)
       )
      )
      (return
       (f64.add
        (local.get $0)
        (f64.const 1)
       )
      )
     )
     (local.set $4
      (i32.sub
       (i32.xor
        (local.get $3)
        (i32.const 1)
       )
       (local.get $3)
      )
     )
    )
    (local.set $5
     (f64.sub
      (local.tee $0
       (f64.add
        (local.get $0)
        (f64.mul
         (local.tee $5
          (f64.convert_i32_s
           (local.get $4)
          )
         )
         (f64.const -0.6931471803691238)
        )
       )
      )
      (local.tee $6
       (f64.mul
        (local.get $5)
        (f64.const 1.9082149292705877e-10)
       )
      )
     )
    )
   )
   (local.set $5
    (f64.add
     (f64.add
      (local.get $0)
      (f64.sub
       (f64.div
        (f64.mul
         (local.get $5)
         (local.tee $7
          (f64.sub
           (local.get $5)
           (f64.mul
            (local.tee $7
             (f64.mul
              (local.get $5)
              (local.get $5)
             )
            )
            (f64.add
             (f64.mul
              (local.get $7)
              (f64.add
               (f64.mul
                (local.get $7)
                (f64.add
                 (f64.mul
                  (local.get $7)
                  (f64.add
                   (f64.mul
                    (local.get $7)
                    (f64.const 4.1381367970572385e-08)
                   )
                   (f64.const -1.6533902205465252e-06)
                  )
                 )
                 (f64.const 6.613756321437934e-05)
                )
               )
               (f64.const -2.7777777777015593e-03)
              )
             )
             (f64.const 0.16666666666666602)
            )
           )
          )
         )
        )
        (f64.sub
         (f64.const 2)
         (local.get $7)
        )
       )
       (local.get $6)
      )
     )
     (f64.const 1)
    )
   )
   (br_if $block4
    (i32.eqz
     (local.get $4)
    )
   )
   (block $block11
    (block $block13
     (block $block12
      (block $block10
       (br_if $block10
        (i32.gt_s
         (local.get $4)
         (i32.const 1023)
        )
       )
       (br_if $block11
        (i32.ge_s
         (local.get $4)
         (i32.const -1022)
        )
       )
       (local.set $5
        (f64.mul
         (local.get $5)
         (f64.const 2.004168360008973e-292)
        )
       )
       (br_if $block12
        (i32.le_u
         (local.get $4)
         (i32.const -1992)
        )
       )
       (local.set $4
        (i32.add
         (local.get $4)
         (i32.const 969)
        )
       )
       (br $block11)
      )
      (local.set $5
       (f64.mul
        (local.get $5)
        (f64.const 8988465674311579538646525e283)
       )
      )
      (br_if $block13
       (i32.gt_u
        (local.get $4)
        (i32.const 2046)
       )
      )
      (local.set $4
       (i32.add
        (local.get $4)
        (i32.const -1023)
       )
      )
      (br $block11)
     )
     (local.set $5
      (f64.mul
       (local.get $5)
       (f64.const 2.004168360008973e-292)
      )
     )
     (local.set $4
      (i32.add
       (select
        (local.get $4)
        (i32.const -2960)
        (i32.gt_u
         (local.get $4)
         (i32.const -2960)
        )
       )
       (i32.const 1938)
      )
     )
     (br $block11)
    )
    (local.set $5
     (f64.mul
      (local.get $5)
      (f64.const 8988465674311579538646525e283)
     )
    )
    (local.set $4
     (i32.add
      (select
       (local.get $4)
       (i32.const 3069)
       (i32.lt_u
        (local.get $4)
        (i32.const 3069)
       )
      )
      (i32.const -2046)
     )
    )
   )
   (local.set $5
    (f64.mul
     (local.get $5)
     (f64.reinterpret_i64
      (i64.shl
       (i64.extend_i32_u
        (i32.add
         (local.get $4)
         (i32.const 1023)
        )
       )
       (i64.const 52)
      )
     )
    )
   )
  )
  (local.get $5)
 )
 (func $_RNvNtNtCs5cUd4OADQLd_17compiler_builtins4math20partial_availability4exp2 (param $0 f64) (result f64)
  (local $1 i32)
  (local $2 i64)
  (local $3 i64)
  (local $4 f64)
  (local $5 i32)
  (local $6 f64)
  (local.set $1
   (i32.sub
    (global.get $__stack_pointer)
    (i32.const 16)
   )
  )
  (block $block1
   (block $block
    (br_if $block
     (i64.gt_u
      (local.tee $3
       (i64.and
        (i64.shr_u
         (local.tee $2
          (i64.reinterpret_f64
           (local.get $0)
          )
         )
         (i64.const 32)
        )
        (i64.const 2147483647)
       )
      )
      (i64.const 1083174911)
     )
    )
    (br_if $block1
     (i64.ge_u
      (local.get $3)
      (i64.const 1016070144)
     )
    )
    (return
     (f64.add
      (local.get $0)
      (f64.const 1)
     )
    )
   )
   (block $block3
    (block $block2
     (br_if $block2
      (i64.lt_s
       (local.get $2)
       (i64.const 0)
      )
     )
     (br_if $block3
      (i64.gt_u
       (local.get $3)
       (i64.const 1083179007)
      )
     )
    )
    (block $block5
     (block $block4
      (br_if $block4
       (i64.gt_u
        (local.get $3)
        (i64.const 2146435071)
       )
      )
      (br_if $block5
       (i64.le_s
        (local.get $2)
        (i64.const -1)
       )
      )
      (br $block1)
     )
     (return
      (f64.div
       (f64.const -1)
       (local.get $0)
      )
     )
    )
    (block $block6
     (br_if $block6
      (i32.eqz
       (f64.le
        (local.get $0)
        (f64.const -1075)
       )
      )
     )
     (f32.store offset=12
      (local.get $1)
      (f32.demote_f64
       (f64.div
        (f64.const -1.401298464324817e-45)
        (local.get $0)
       )
      )
     )
     (drop
      (f32.load offset=12
       (local.get $1)
      )
     )
     (return
      (f64.const 0)
     )
    )
    (br_if $block1
     (f64.eq
      (f64.add
       (f64.add
        (local.get $0)
        (f64.const -4503599627370496)
       )
       (f64.const 4503599627370496)
      )
      (local.get $0)
     )
    )
    (f32.store offset=12
     (local.get $1)
     (f32.demote_f64
      (f64.div
       (f64.const -1.401298464324817e-45)
       (local.get $0)
      )
     )
    )
    (drop
     (f32.load offset=12
      (local.get $1)
     )
    )
    (br $block1)
   )
   (return
    (f64.mul
     (local.get $0)
     (f64.const 8988465674311579538646525e283)
    )
   )
  )
  (local.set $0
   (f64.add
    (local.tee $6
     (f64.load offset=1049360
      (local.tee $5
       (i32.and
        (i32.shl
         (local.tee $1
          (i32.add
           (i32.wrap_i64
            (i64.reinterpret_f64
             (local.tee $4
              (f64.add
               (local.get $0)
               (f64.const 26388279066624)
              )
             )
            )
           )
           (i32.const 128)
          )
         )
         (i32.const 4)
        )
        (i32.const 4080)
       )
      )
     )
    )
    (f64.mul
     (f64.mul
      (local.get $6)
      (local.tee $0
       (f64.sub
        (f64.sub
         (local.get $0)
         (f64.add
          (local.get $4)
          (f64.const -26388279066624)
         )
        )
        (f64.load offset=1049368
         (local.get $5)
        )
       )
      )
     )
     (f64.add
      (f64.mul
       (local.get $0)
       (f64.add
        (f64.mul
         (local.get $0)
         (f64.add
          (f64.mul
           (local.get $0)
           (f64.add
            (f64.mul
             (local.get $0)
             (f64.const 1.3333559164630223e-03)
            )
            (f64.const 0.009618129842126066)
           )
          )
          (f64.const 0.0555041086648214)
         )
        )
        (f64.const 0.2402265069591)
       )
      )
      (f64.const 0.6931471805599453)
     )
    )
   )
  )
  (block $block8
   (block $block10
    (block $block9
     (block $block7
      (br_if $block7
       (i32.gt_s
        (local.tee $1
         (i32.shr_s
          (local.get $1)
          (i32.const 8)
         )
        )
        (i32.const 1023)
       )
      )
      (br_if $block8
       (i32.ge_s
        (local.get $1)
        (i32.const -1022)
       )
      )
      (local.set $0
       (f64.mul
        (local.get $0)
        (f64.const 2.004168360008973e-292)
       )
      )
      (br_if $block9
       (i32.le_u
        (local.get $1)
        (i32.const -1992)
       )
      )
      (local.set $1
       (i32.add
        (local.get $1)
        (i32.const 969)
       )
      )
      (br $block8)
     )
     (local.set $0
      (f64.mul
       (local.get $0)
       (f64.const 8988465674311579538646525e283)
      )
     )
     (br_if $block10
      (i32.gt_u
       (local.get $1)
       (i32.const 2046)
      )
     )
     (local.set $1
      (i32.add
       (local.get $1)
       (i32.const -1023)
      )
     )
     (br $block8)
    )
    (local.set $0
     (f64.mul
      (local.get $0)
      (f64.const 2.004168360008973e-292)
     )
    )
    (local.set $1
     (i32.add
      (select
       (local.get $1)
       (i32.const -2960)
       (i32.gt_u
        (local.get $1)
        (i32.const -2960)
       )
      )
      (i32.const 1938)
     )
    )
    (br $block8)
   )
   (local.set $0
    (f64.mul
     (local.get $0)
     (f64.const 8988465674311579538646525e283)
    )
   )
   (local.set $1
    (i32.add
     (select
      (local.get $1)
      (i32.const 3069)
      (i32.lt_u
       (local.get $1)
       (i32.const 3069)
      )
     )
     (i32.const -2046)
    )
   )
  )
  (f64.mul
   (local.get $0)
   (f64.reinterpret_i64
    (i64.shl
     (i64.extend_i32_u
      (i32.add
       (local.get $1)
       (i32.const 1023)
      )
     )
     (i64.const 52)
    )
   )
  )
 )
 (func $exp (param $0 f64) (result f64)
  (call $_RNvNtNtNtCs5cUd4OADQLd_17compiler_builtins4math9libm_math3exp3exp
   (local.get $0)
  )
 )
 (func $exp2 (param $0 f64) (result f64)
  (call $_RNvNtNtCs5cUd4OADQLd_17compiler_builtins4math20partial_availability4exp2
   (local.get $0)
  )
 )
 ;; custom section "producers", size 60
 ;; features section: mutable-globals, nontrapping-float-to-int, bulk-memory, sign-ext, reference-types, multivalue, bulk-memory-opt, call-indirect-overlong
)

