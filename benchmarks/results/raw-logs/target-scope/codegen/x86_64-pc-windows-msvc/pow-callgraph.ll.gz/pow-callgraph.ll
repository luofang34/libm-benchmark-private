define noundef double @_RNvNtNtCsgbKoC6ieNxQ_4libm4math3pow3pow(double noundef %x, double noundef %y) unnamed_addr #2 !guid !170 {
start:
  %0 = bitcast double %x to i64
  %iy = bitcast double %y to i64
  %_7 = lshr i64 %0, 52
  %topx = trunc nuw nsw i64 %_7 to i32
  %_11 = lshr i64 %iy, 52
  %_10 = trunc nuw nsw i64 %_11 to i32
  %topy = and i32 %_10, 2046
  %1 = add nsw i32 %topx, -2047
  %_12 = icmp ult i32 %1, -2046
  %2 = add nsw i32 %topy, -1086
  %_14 = icmp ult i32 %2, -128
  %or.cond = or i1 %_12, %_14
  br i1 %or.cond, label %bb4, label %bb9

bb9:                                              ; preds = %bb38.i, %bb37.i, %start
  %sign.sroa.0.0 = phi i32 [ 0, %start ], [ %sign.sroa.0.2, %bb37.i ], [ %sign.sroa.0.2, %bb38.i ]
  %ix.sroa.0.0 = phi i64 [ %0, %start ], [ %ix.sroa.0.1, %bb37.i ], [ %_45.i18, %bb38.i ]
  %tmp.i = add i64 %ix.sroa.0.0, -4604531861337669632
  %_5.i = lshr i64 %tmp.i, 45
  %_4.i = and i64 %_5.i, 127
  %_7.i = ashr i64 %tmp.i, 52
  %k.i = sitofp i64 %_7.i to double
  %_10.i = and i64 %tmp.i, -4503599627370496
  %iz.i = sub i64 %ix.sroa.0.0, %_10.i
  %z.i = bitcast i64 %iz.i to double
  %_63.i = getelementptr inbounds nuw [24 x i8], ptr @alloc_e80698c161ac66f7ed57e7a6f8e42266, i64 %_4.i
  %row.sroa.0.0.copyload1.i = load double, ptr %_63.i, align 8
  %row.sroa.4.0._63.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_63.i, i64 8
  %row.sroa.4.0.copyload2.i = load double, ptr %row.sroa.4.0._63.sroa_idx.i, align 8
  %row.sroa.5.0._63.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_63.i, i64 16
  %row.sroa.5.0.copyload3.i = load double, ptr %row.sroa.5.0._63.sroa_idx.i, align 8
  %_22.i = add i64 %iz.i, 2147483648
  %_21.i = and i64 %_22.i, -4294967296
  %zhi.i = bitcast i64 %_21.i to double
  %zlo.i = fsub double %z.i, %zhi.i
  %_25.i = fmul double %row.sroa.0.0.copyload1.i, %zhi.i
  %rhi.i = fadd double %_25.i, -1.000000e+00
  %rlo.i = fmul double %row.sroa.0.0.copyload1.i, %zlo.i
  %r.i = fadd double %rlo.i, %rhi.i
  %_29.i = fmul nnan double %k.i, f0x3FE62E42FEFA3800
  %t1.i = fadd double %row.sroa.4.0.copyload2.i, %_29.i
  %t2.i = fadd double %t1.i, %r.i
  %_32.i = fmul nnan double %k.i, f0x3D2EF35793C76730
  %lo1.i = fadd double %row.sroa.5.0.copyload3.i, %_32.i
  %_34.i = fsub double %t1.i, %t2.i
  %lo2.i = fadd double %r.i, %_34.i
  %ar.i = fmul double %r.i, -5.000000e-01
  %ar2.i = fmul double %r.i, %ar.i
  %ar3.i = fmul double %r.i, %ar2.i
  %arhi.i = fmul double %rhi.i, -5.000000e-01
  %arhi2.i = fmul double %rhi.i, %arhi.i
  %hi.i = fadd double %t2.i, %arhi2.i
  %_42.i = fadd double %arhi.i, %ar.i
  %lo3.i = fmul double %rlo.i, %_42.i
  %_44.i = fsub double %t2.i, %hi.i
  %lo4.i = fadd double %arhi2.i, %_44.i
  %_48.i = fmul double %r.i, f0x3FE0000000000006
  %_47.i = fadd double %_48.i, f0xBFE5555555555560
  %_52.i = fmul double %r.i, f0x3FE555555529A47A
  %3 = fsub double f0x3FE999999959554E, %_52.i
  %_55.i = fmul double %r.i, f0x3FF0002B8B263FC3
  %_54.i = fadd double %_55.i, f0xBFF2495B9B4845E9
  %_53.i = fmul double %ar2.i, %_54.i
  %_50.i = fadd double %3, %_53.i
  %_49.i = fmul double %ar2.i, %_50.i
  %_46.i = fadd double %_47.i, %_49.i
  %p.i = fmul double %ar3.i, %_46.i
  %_59.i = fadd double %lo1.i, %lo2.i
  %_58.i = fadd double %lo3.i, %_59.i
  %_57.i = fadd double %lo4.i, %_58.i
  %lo.i = fadd double %_57.i, %p.i
  %result.i = fadd double %hi.i, %lo.i
  %_62.i = fsub double %hi.i, %result.i
  %_61.i = fadd double %lo.i, %_62.i
  %_25 = and i64 %iy, -134217728
  %yhi = bitcast i64 %_25 to double
  %ylo = fsub double %y, %yhi
  %_29 = bitcast double %result.i to i64
  %_28 = and i64 %_29, -134217728
  %lhi = bitcast i64 %_28 to double
  %_31 = fsub double %result.i, %lhi
  %llo = fadd double %_61.i, %_31
  %_32 = fmul double %yhi, %lhi
  %_34 = fmul double %ylo, %lhi
  %_35 = fmul double %y, %llo
  %_33 = fadd double %_34, %_35
  %_7.i2 = bitcast double %_32 to i64
  %_6.i = lshr i64 %_7.i2, 52
  %_5.i3 = trunc nuw nsw i64 %_6.i to i32
  %abstop.i = and i32 %_5.i3, 2047
  %_8.i = icmp samesign ult i32 %abstop.i, 969
  br i1 %_8.i, label %bb1.i, label %bb5.i

bb5.i:                                            ; preds = %bb9
  %_9.i = icmp samesign ugt i32 %abstop.i, 1032
  br i1 %_9.i, label %bb6.i, label %bb7.i

bb1.i:                                            ; preds = %bb9
  %4 = icmp eq i32 %sign.sroa.0.0, 0
  %..i = select i1 %4, double 1.000000e+00, double -1.000000e+00
  br label %bb12

bb7.i:                                            ; preds = %bb5.i
  %_13.i = fmul double %_32, f0x40671547652B82FE
  %kd.i = fadd double %_13.i, f0x4338000000000000
  %ki.i = bitcast double %kd.i to i64
  %kd1.i = fadd double %kd.i, f0xC338000000000000
  %_19.i = fmul double %kd1.i, f0x3F762E42FEFA0000
  %5 = fsub double %_32, %_19.i
  %_20.i = fmul double %kd1.i, f0x3D0CF79ABC9E3B3A
  %6 = fsub double %5, %_20.i
  %r.i4 = fadd double %_33, %6
  %_24.i = and i64 %ki.i, 127
  %_47.i5 = getelementptr inbounds nuw [16 x i8], ptr @alloc_7eaa181ac7394c04fca5721022e0324f, i64 %_24.i
  %row.sroa.0.0.copyload3.i = load double, ptr %_47.i5, align 8
  %row.sroa.4.0._47.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_47.i5, i64 8
  %row.sroa.4.0.copyload.i = load i64, ptr %row.sroa.4.0._47.sroa_idx.i, align 8
  %_27.i = zext nneg i32 %sign.sroa.0.0 to i64
  %_26.i = add i64 %ki.i, %_27.i
  %top.i = shl i64 %_26.i, 45
  %sbits.i = add i64 %row.sroa.4.0.copyload.i, %top.i
  %r2.i = fmul double %r.i4, %r.i4
  %_33.i = fadd double %r.i4, %row.sroa.0.0.copyload3.i
  %_38.i = fmul double %r.i4, f0x3FC555555555543C
  %_37.i = fadd double %_38.i, f0x3FDFFFFFFFFFFDBD
  %_36.i = fmul double %r2.i, %_37.i
  %_32.i6 = fadd double %_36.i, %_33.i
  %_40.i = fmul double %r2.i, %r2.i
  %_42.i7 = fmul double %r.i4, f0x3F81111167A4D017
  %_41.i = fadd double %_42.i7, f0x3FA55555CF172B91
  %_39.i = fmul double %_40.i, %_41.i
  %tmp.i8 = fadd double %_39.i, %_32.i6
  %_43.i = icmp eq i32 %abstop.i, 1032
  br i1 %_43.i, label %bb14.i, label %bb15.i

bb6.i:                                            ; preds = %bb5.i
  %_11.not.i = icmp sgt i64 %_7.i2, -1
  %.4.i = select i1 %_11.not.i, double +inf, double 0.000000e+00
  %7 = icmp eq i32 %sign.sroa.0.0, 0
  br i1 %7, label %bb12, label %bb11.i

bb15.i:                                           ; preds = %bb7.i
  %scale.i = bitcast i64 %sbits.i to double
  %_45.i = fmul double %tmp.i8, %scale.i
  %8 = fadd double %_45.i, %scale.i
  br label %bb12

bb14.i:                                           ; preds = %bb7.i
  %_4.i.i = and i64 %ki.i, 2147483648
  %9 = icmp eq i64 %_4.i.i, 0
  br i1 %9, label %bb1.i.i, label %bb2.i.i

bb1.i.i:                                          ; preds = %bb14.i
  %_6.i.i = add i64 %sbits.i, -4544132024016830464
  %scale.i.i = bitcast i64 %_6.i.i to double
  %_8.i.i = fmul double %tmp.i8, %scale.i.i
  %_7.i.i = fadd double %_8.i.i, %scale.i.i
  %10 = fmul double %_7.i.i, f0x7F00000000000000
  br label %bb12

bb2.i.i:                                          ; preds = %bb14.i
  %sbits1.i.i = add i64 %sbits.i, 4602678819172646912
  %scale2.i.i = bitcast i64 %sbits1.i.i to double
  %_11.i.i = fmul double %tmp.i8, %scale2.i.i
  %11 = fadd double %_11.i.i, %scale2.i.i
  %12 = tail call double @llvm.fabs.f64(double %11)
  %_13.i.i = bitcast double %12 to i64
  %_12.i.i = icmp samesign ult i64 %_13.i.i, 4607182418800017408
  br i1 %_12.i.i, label %bb3.i.i, label %bb11.i.i

bb3.i.i:                                          ; preds = %bb2.i.i
  %_17.i.i = fcmp olt double %11, 0.000000e+00
  %..i.i = select i1 %_17.i.i, double -1.000000e+00, double 1.000000e+00
  %_20.i.i = fsub double %scale2.i.i, %11
  %lo.i.i = fadd double %_11.i.i, %_20.i.i
  %hi.i.i = fadd double %11, %..i.i
  %_27.i.i = fsub double %..i.i, %hi.i.i
  %_26.i.i = fadd double %11, %_27.i.i
  %lo3.i.i = fadd double %lo.i.i, %_26.i.i
  %_29.i.i = fadd double %hi.i.i, %lo3.i.i
  %13 = fsub double %_29.i.i, %..i.i
  %_30.i.i = fcmp oeq double %13, 0.000000e+00
  br i1 %_30.i.i, label %bb7.i.i, label %bb11.i.i

bb11.i.i:                                         ; preds = %bb7.i.i, %bb3.i.i, %bb2.i.i
  %y.sroa.0.0.i.i = phi double [ %15, %bb7.i.i ], [ %13, %bb3.i.i ], [ %11, %bb2.i.i ]
  %14 = fmul double %y.sroa.0.0.i.i, f0x0010000000000000
  br label %bb12

bb7.i.i:                                          ; preds = %bb3.i.i
  %_33.i.i = and i64 %sbits1.i.i, -9223372036854775808
  %15 = bitcast i64 %_33.i.i to double
  br label %bb11.i.i

bb11.i:                                           ; preds = %bb6.i
  %16 = fneg double %.4.i
  br label %bb12

bb4:                                              ; preds = %start
  %ax2.i = shl i64 %0, 1
  %ay2.i = shl i64 %iy, 1
  %17 = add i64 %ay2.i, 9007199254740992
  %_9.i10 = icmp ult i64 %17, 9007199254740993
  br i1 %_9.i10, label %bb1.i29, label %bb14.i11

bb14.i11:                                         ; preds = %bb4
  %18 = add i64 %ax2.i, 9007199254740992
  %_19.i12 = icmp ult i64 %18, 9007199254740993
  br i1 %_19.i12, label %bb15.i23, label %bb22.i

bb1.i29:                                          ; preds = %bb4
  %19 = icmp eq i64 %ay2.i, 0
  %20 = icmp eq i64 %0, 4607182418800017408
  %or.cond4.i = or i1 %20, %19
  br i1 %or.cond4.i, label %bb12, label %bb5.i30

bb22.i:                                           ; preds = %bb14.i11
  %21 = icmp sgt i64 %0, -1
  br i1 %21, label %bb28.i, label %bb23.i

bb15.i23:                                         ; preds = %bb14.i11
  %22 = fmul double %x, %x
  %23 = icmp sgt i64 %0, -1
  br i1 %23, label %bb18.i, label %bb16.i

bb23.i:                                           ; preds = %bb22.i
  %_61.i13 = and i64 %_11, 2047
  %_63.i14 = icmp samesign ult i64 %_61.i13, 1023
  br i1 %_63.i14, label %bb12, label %bb56.i

bb28.i:                                           ; preds = %bb27.i, %bb22.i
  %sign.sroa.0.2 = phi i32 [ 0, %bb22.i ], [ %sign.sroa.0.1, %bb27.i ]
  %ix.sroa.0.1 = phi i64 [ %0, %bb22.i ], [ %28, %bb27.i ]
  %topy.i = and i32 %_10, 2047
  %24 = add nsw i32 %topy.i, -1086
  %_33.i15 = icmp ult i32 %24, -128
  br i1 %_33.i15, label %bb29.i, label %bb37.i

bb56.i:                                           ; preds = %bb23.i
  %_64.i = icmp samesign ugt i64 %_61.i13, 1075
  br i1 %_64.i, label %bb27.i, label %bb58.i

bb58.i:                                           ; preds = %bb56.i
  %_65.i = sub nuw nsw i64 1075, %_61.i13
  %_68.i = shl nuw nsw i64 1, %_65.i
  %_67.i = add nsw i64 %_68.i, -1
  %_66.i = and i64 %_67.i, %iy
  %25 = icmp eq i64 %_66.i, 0
  br i1 %25, label %bb60.i, label %bb12

bb60.i:                                           ; preds = %bb58.i
  %_69.i = and i64 %_68.i, %iy
  %26 = icmp eq i64 %_69.i, 0
  %spec.select = select i1 %26, i32 0, i32 262144
  br label %bb27.i

bb27.i:                                           ; preds = %bb60.i, %bb56.i
  %sign.sroa.0.1 = phi i32 [ 0, %bb56.i ], [ %spec.select, %bb60.i ]
  %27 = tail call double @llvm.fabs.f64(double %x)
  %28 = bitcast double %27 to i64
  br label %bb28.i

bb37.i:                                           ; preds = %bb28.i
  %29 = icmp samesign ult i64 %ix.sroa.0.1, 4503599627370496
  br i1 %29, label %bb38.i, label %bb9

bb29.i:                                           ; preds = %bb28.i
  %30 = icmp eq i64 %ix.sroa.0.1, 4607182418800017408
  %_36.i19 = icmp samesign ult i32 %topy.i, 958
  %or.cond.i = or i1 %_36.i19, %30
  br i1 %or.cond.i, label %bb12, label %bb33.i

bb38.i:                                           ; preds = %bb37.i
  %_48.i16 = fmul double %x, f0x4330000000000000
  %31 = tail call double @llvm.fabs.f64(double %_48.i16)
  %_46.i17 = bitcast double %31 to i64
  %_45.i18 = add nsw i64 %_46.i17, -234187180623265792
  br label %bb9

bb33.i:                                           ; preds = %bb29.i
  %_39.i20 = icmp samesign ugt i64 %ix.sroa.0.1, 4607182418800017408
  %32 = icmp slt i64 %iy, 0
  %_38.i21 = xor i1 %32, %_39.i20
  %..i22 = select i1 %_38.i21, double +inf, double 0.000000e+00
  br label %bb12

bb16.i:                                           ; preds = %bb15.i23
  %_52.i25 = and i64 %_11, 2047
  %33 = add nsw i64 %_52.i25, -1076
  %or.cond2.i = icmp ult i64 %33, -53
  br i1 %or.cond2.i, label %bb18.i, label %bb48.i

bb18.i:                                           ; preds = %bb51.i, %bb48.i, %bb16.i, %bb15.i23
  %x2.sroa.0.0.i = phi double [ %22, %bb15.i23 ], [ %22, %bb16.i ], [ %22, %bb48.i ], [ %38, %bb51.i ]
  %34 = fdiv double 1.000000e+00, %x2.sroa.0.0.i
  %35 = icmp slt i64 %iy, 0
  %_25.sroa.0.0.i = select i1 %35, double %34, double %x2.sroa.0.0.i
  br label %bb12

bb48.i:                                           ; preds = %bb16.i
  %_56.i = sub nuw nsw i64 1075, %_52.i25
  %_59.i26 = shl nuw nsw i64 1, %_56.i
  %_58.i27 = add nsw i64 %_59.i26, -1
  %_57.i28 = and i64 %_58.i27, %iy
  %36 = icmp ne i64 %_57.i28, 0
  %_60.i = and i64 %_59.i26, %iy
  %37 = icmp eq i64 %_60.i, 0
  %or.cond3.i = or i1 %37, %36
  br i1 %or.cond3.i, label %bb18.i, label %bb51.i

bb51.i:                                           ; preds = %bb48.i
  %38 = fneg double %22
  br label %bb18.i

bb5.i30:                                          ; preds = %bb1.i29
  %_11.i = icmp ugt i64 %ax2.i, -9007199254740992
  %_12.i = icmp samesign ugt i64 %ay2.i, -9007199254740992
  %or.cond1.i = or i1 %_11.i, %_12.i
  br i1 %or.cond1.i, label %bb8.i, label %bb7.i31

bb8.i:                                            ; preds = %bb5.i30
  %_13.i32 = fadd double %x, %y
  br label %bb12

bb7.i31:                                          ; preds = %bb5.i30
  %39 = icmp eq i64 %ax2.i, 9214364837600034816
  br i1 %39, label %bb12, label %bb10.i

bb10.i:                                           ; preds = %bb7.i31
  %_16.i = icmp ult i64 %ax2.i, 9214364837600034816
  %40 = icmp slt i64 %iy, 0
  %_15.i = xor i1 %40, %_16.i
  %41 = fmul double %y, %y
  %_14.sroa.0.0.i = select i1 %_15.i, double 0.000000e+00, double %41
  br label %bb12

bb12:                                             ; preds = %bb7.i31, %bb23.i, %bb58.i, %bb33.i, %bb18.i, %bb10.i, %bb1.i29, %bb8.i, %bb29.i, %bb11.i, %bb11.i.i, %bb1.i.i, %bb15.i, %bb6.i, %bb1.i
  %result.sroa.0.0 = phi double [ %14, %bb11.i.i ], [ %.4.i, %bb6.i ], [ %..i, %bb1.i ], [ %8, %bb15.i ], [ %16, %bb11.i ], [ %10, %bb1.i.i ], [ 1.000000e+00, %bb7.i31 ], [ +qnan, %bb23.i ], [ +qnan, %bb58.i ], [ %..i22, %bb33.i ], [ %_25.sroa.0.0.i, %bb18.i ], [ %_14.sroa.0.0.i, %bb10.i ], [ 1.000000e+00, %bb1.i29 ], [ %_13.i32, %bb8.i ], [ 1.000000e+00, %bb29.i ]
  ret double %result.sroa.0.0
}